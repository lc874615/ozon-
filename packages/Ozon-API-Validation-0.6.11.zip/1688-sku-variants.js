function supplierContentsQuantity(name,unitText=''){
 const text=String(name)+' '+String(unitText),found=[];
 for(const m of text.matchAll(/(?:^|[^\d.])(\d+)\s*(?:件|个|把|只|张|支|条|枚|双|对)(?:\s*(?:装|套装|组合|\/套|每套))?/g)){
  const n=Number(m[1]);if(Number.isSafeInteger(n)&&n>0)found.push(n);
 }
 const distinct=[...new Set(found)];
 return distinct.length>1?{value:null,basis:'conflicting_explicit_quantities'}:distinct.length?{value:distinct[0],basis:'sku_name_or_unit_explicit'}:{value:1,basis:'user_default_one'};
}
function collect1688SkuVariants(){
 const offer=location.hostname==='detail.1688.com'&&location.pathname.match(/^\/offer\/(\d+)\.html$/)?.[1];
 if(!offer)return {status:'detail_page_required'};
 const safeImage=u=>{try{const x=new URL(u,location.href);return x.protocol==='https:'&&/(^|\.)(alicdn\.com|1688\.com)$/.test(x.hostname)?x.href:null;}catch{return null;}};
 const rows=[];const seen=new Set();
 const inputs=[...document.querySelectorAll('input.ant-input-number-input,input[role="spinbutton"]')].filter(e=>e.getClientRects().length);
 for(const input of inputs){
  let row=null,p=input.parentElement;
  for(let depth=0;p&&depth<12;depth++,p=p.parentElement){
   if(p.querySelectorAll('input.ant-input-number-input,input[role="spinbutton"]').length!==1)break;
   if(/sku|spec|prop|item/i.test(p.className||'')&&p.querySelector('img')&&(p.innerText||'').trim().length<1500)row=p;
  }
  if(!row||seen.has(row))continue;seen.add(row);
  let sku=null;for(const e of [row,...row.querySelectorAll('[data-sku-id],[data-skuid],[data-sku]')])for(const a of ['data-sku-id','data-skuid','data-sku']){const v=e.getAttribute(a);if(/^\d+$/.test(v||'')){if(sku&&sku!==v){sku=null;break;}sku=v;}}
  const labels=[...row.querySelectorAll('[title],img[alt]')].map(e=>e.getAttribute('title')||e.getAttribute('alt')).filter(Boolean).map(s=>s.trim()).filter(s=>s.length<=200);
  const images=[...new Set([...row.querySelectorAll('img')].map(i=>safeImage(i.currentSrc||i.getAttribute('src')||i.getAttribute('data-src'))).filter(Boolean))];
  rows.push({sku_id:sku,control_index:inputs.indexOf(input),labels:[...new Set(labels)],specification_text:(row.innerText||'').trim().slice(0,1000),images,quantity_basis:'requires_sku_name_not_price_or_stock',identity_verified:!!sku,match_verified:false});
 }
 return {status:'supplier_variants_observed',offer_id:offer,variants:rows,quantity_control_count:inputs.length,all_variants_verified:false,completeness:'rendered_rows_only_hidden_or_unloaded_variants_not_verified',profit_eligible:false};
}
