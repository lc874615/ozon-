/* Observe only the site's own calculatePrice XHR. No signed URL, headers,
   buyer/seller account identifiers or address values are retained or replayed. */
function normalize1688ObservedQuote(request,response){
 const money=v=>{const s=String(v);if(!/^\d+(?:\.\d{1,2})?$/.test(s))throw Error('invalid money');const [a,b='']=s.split('.');const n=Number(a)*100+Number(b.padEnd(2,'0'));if(!Number.isSafeInteger(n))throw Error('money range');return n;};
 const fmt=v=>(v/100).toFixed(2);
 try{
  if(!Array.isArray(response.ret)||!response.ret.some(x=>String(x).startsWith('SUCCESS')))throw Error('quote not successful');
  const lines=typeof request.skuCalParams==='string'?JSON.parse(request.skuCalParams):request.skuCalParams;
  if(!Array.isArray(lines)||lines.length!==1)throw Error('single SKU quote required');
  const l=lines[0],offer=String(request.offerId),sku=String(l.skuId),q=Number(l.number);
  if(!/^\d+$/.test(offer)||!/^\d+$/.test(sku)||!Number.isSafeInteger(q)||q<1)throw Error('invalid identity or quantity');
  const d=response.data,final=money(d.totalFinalPrice),original=money(d.totalOriginalPrice),discount=money(d.totalDiscount);
  if(original-final!==discount)throw Error('inconsistent discount');
  return {status:'quantity_quote_read',offer_id:offer,sku_id:sku,purchase_quantity:q,currency:'CNY',goods_total_cny:fmt(final),goods_original_total_cny:fmt(original),order_discount_cny:fmt(discount),free_shipping_for_this_quote:d.freePostage===true,domestic_freight_cny:d.freePostage===true?'0.00':null,observed_at:new Date().toISOString(),source:'normal_page_calculatePrice_response',sales_unit_quantity:{value:1,verified:false,basis:'user_default_when_quantity_not_parsed'},profit_eligible:false};
 }catch{return {status:'quote_unverified'};}
}
function readOrWatch1688Quote(){
 const offer=location.hostname==='detail.1688.com'&&location.pathname.match(/^\/offer\/(\d+)\.html$/)?.[1];
 if(!offer)return {status:'detail_page_required'};
 const key='__ozonSupplierQuoteObservationV1';
 if(!window[key]){
  const state={quotes:[],last_status:'waiting_for_normal_page_quote'};window[key]=state;
  const originalOpen=XMLHttpRequest.prototype.open,originalSend=XMLHttpRequest.prototype.send;
  const requests=new WeakMap();
  XMLHttpRequest.prototype.open=function(method,url,...rest){
   requests.delete(this);
   try{const u=new URL(String(url),location.href);if(u.hostname.endsWith('.1688.com')&&u.pathname.toLowerCase().includes('/mtop.1688.handpriceservice.calculateprice/'))requests.set(this,{data:u.searchParams.get('data')});}catch{}
   return originalOpen.call(this,method,url,...rest);
  };
  XMLHttpRequest.prototype.send=function(body){
   const meta=requests.get(this);
   if(meta){
    let request;
    try{const raw=typeof body==='string'?new URLSearchParams(body).get('data'):body instanceof URLSearchParams?body.get('data'):body instanceof FormData?body.get('data'):null;const parsed=JSON.parse(raw||meta.data||'{}');request={offerId:parsed.offerId,skuCalParams:parsed.skuCalParams};}catch{}
    if(request)this.addEventListener('load',()=>{try{
     const response=this.responseType==='json'?this.response:JSON.parse(this.responseText);
     const quote=normalize1688ObservedQuote(request,response);state.last_status=quote.status;
     if(quote.status==='quantity_quote_read'&&quote.offer_id===offer){state.quotes=state.quotes.filter(x=>!(x.offer_id===quote.offer_id&&x.sku_id===quote.sku_id&&x.purchase_quantity===quote.purchase_quantity));state.quotes.push(quote);state.quotes=state.quotes.slice(-20);}
    }catch{state.last_status='quote_unverified';}},{once:true});
   }
   return originalSend.call(this,body);
  };
 }
 return {status:window[key].quotes.length?'supplier_quotes_observed':'quote_observer_ready',offer_id:offer,quotes:window[key].quotes.filter(x=>x.offer_id===offer),last_status:window[key].last_status};
}
async function automaticallyRead1688Quote(target){
 const observed=readOrWatch1688Quote();if(observed.status==='detail_page_required')return observed;
 const sku=String(target.sku_id||''),qty=target.purchase_quantity;
 if(!/^\d+$/.test(sku)||!Number.isSafeInteger(qty)||qty<1)return {status:'quote_target_missing',message:'缺少供应商SKU或明确的Ozon套装数量，未修改页面'};
 // Only a quantity field inside a row explicitly bound to the target SKU.
 const rows=[...document.querySelectorAll('[data-sku-id],[data-skuid],[data-sku]')].filter(e=>['data-sku-id','data-skuid','data-sku'].some(k=>e.getAttribute(k)===sku));
 const inputs=[...new Set(rows.flatMap(r=>[...r.querySelectorAll('input')]))].filter(e=>!e.disabled&&!e.readOnly&&e.getClientRects().length&&(/number/i.test(e.type)||e.getAttribute('role')==='spinbutton'||/数量|购买件数|采购件数/.test([e.getAttribute('aria-label'),e.getAttribute('placeholder')].join(' '))));
 if(inputs.length!==1)return {status:'sku_quantity_control_unresolved',message:'未定位到唯一绑定SKU '+sku+' 的数量框；未输入或取错规格。需要采集该页SKU控件结构后补适配。',diagnostics:{sku_bound_row_count:rows.length,quantity_input_count:inputs.length}};
 const input=inputs[0];const max=input.getAttribute('max'),min=input.getAttribute('min');
 if((max!==null&&max!==''&&qty>Number(max))||(min!==null&&min!==''&&qty<Number(min)))return {status:'quantity_out_of_range',message:'目标数量不满足当前SKU数量限制'};
 const stamp=Date.now();const setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value')?.set;
 if(!setter)return {status:'quantity_setter_unavailable'};
 setter.call(input,String(qty));input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));input.blur();
 for(let i=0;i<32;i++){
  await new Promise(resolve=>setTimeout(resolve,250));
  const result=readOrWatch1688Quote();const quotes=(result.quotes||[]).filter(q=>q.sku_id===sku&&q.purchase_quantity===qty&&Date.parse(q.observed_at)>=stamp);
  if(quotes.length)return {...result,quotes,automatic_quantity_input:true};
 }
 return {status:'automatic_quote_not_observed',message:'已输入目标数量，但未收到对应SKU、数量的新报价；未重复请求，也未使用旧报价'};
}
