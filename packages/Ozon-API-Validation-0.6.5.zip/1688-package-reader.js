function normalizeSupplierPackage(attributes){
 const values={},evidence=[],conflicts=[];
 const add=(key,value,unit,label,raw)=>{if(!Number.isFinite(value)||value<=0)return;if(values[key]!==undefined&&Math.abs(values[key]-value)>0.001)conflicts.push(key);else values[key]=value;evidence.push({key,value,unit,label,raw});};
 for(const a of attributes){const label=String(a.name||'').replace(/\s+/g,''),raw=String(a.value||'').trim();
  if(/净重|商品重量|产品重量|裸重/.test(label))continue;
  const units=(label+' '+raw).toLowerCase();
  if(/毛重|含包装重量|包装重量/.test(label)){const match=raw.match(/^\s*(\d+(?:\.\d+)?)\s*(kg|g|千克|公斤|克)?\s*$/i);if(match){const u=match[2]||(/kg|千克|公斤/.test(units)?'kg':/(?:\bg\b|克)/.test(units)?'g':null);if(u)add('gross_weight_g',Number(match[1])*(/kg|千克|公斤/i.test(u)?1000:1),'g',label,raw);}continue;}
  if(!/包装|外箱|装箱/.test(label))continue;
  const factor=/mm|毫米/.test(units)?1:/cm|厘米/.test(units)?10:null;if(factor===null)continue;
  const combined=raw.match(/^\s*(\d+(?:\.\d+)?)\s*[xX×*]\s*(\d+(?:\.\d+)?)\s*[xX×*]\s*(\d+(?:\.\d+)?)/);
  if(combined&&/尺寸|长宽高/.test(label)){['length_mm','width_mm','height_mm'].forEach((k,i)=>add(k,Number(combined[i+1])*factor,'mm',label,raw));continue;}
  const key=/长/.test(label)?'length_mm':/宽/.test(label)?'width_mm':/高/.test(label)?'height_mm':null;
  const single=raw.match(/^\s*(\d+(?:\.\d+)?)\s*(?:mm|cm|毫米|厘米)?\s*$/i);if(key&&single)add(key,Number(single[1])*factor,'mm',label,raw);
 }
 const missing=['length_mm','width_mm','height_mm','gross_weight_g'].filter(k=>values[k]===undefined);
 return {status:conflicts.length?'package_conflict':missing.length?'package_missing':'package_fields_read',values,evidence,missing,conflicts,packaging_basis_verified:!conflicts.length&&!missing.length};
}
async function readCurrent1688Package(){
 const result=await read1688DecisionAttributes();if(result.status!=='supplier_attributes_read')return result;
 return {status:'supplier_package_observed',offer_id:result.offer_id,attributes:result.attributes,packaging:normalizeSupplierPackage(result.attributes),selected_sku_identity_verified:false,source:'decisionAttrService',scope:'offer_attributes_not_selected_sku_verified'};
}
