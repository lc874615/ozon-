async function read1688DecisionAttributes(){
 if(location.hostname!=='detail.1688.com')return {status:'detail_page_required'};
 const offerId=location.pathname.match(/^\/offer\/(\d+)\.html$/)?.[1];if(!offerId)return {status:'offer_identity_missing'};
 if(typeof window.lib?.mtop?.request!=='function')return {status:'normal_page_sdk_unavailable'};
 let timer;try{
  const r=await Promise.race([window.lib.mtop.request({api:'mtop.1688.mmga.offerdetail.service',v:'1.0',type:'POST',dataType:'json',timeout:15000,data:{mmgaRequest:JSON.stringify({serviceName:'decisionAttrService',offerId})}}),new Promise((_,reject)=>timer=setTimeout(()=>reject(Error('timeout')),16000))]);
  if(!Array.isArray(r.ret)||!r.ret.some(x=>String(x).startsWith('SUCCESS')))return {status:'attributes_request_rejected'};
  const rows=r.data?.data?.offerDecisionAttrs;const attributes=Array.isArray(rows)?rows.filter(x=>typeof x.property==='string'&&['string','number'].includes(typeof x.value)).map(x=>({name:x.property,value:String(x.value)})):[];
  return {status:attributes.length?'supplier_attributes_read':'attributes_missing',offer_id:offerId,attributes,sku_price_verified:false,quantity_verified:false,freight_verified:false};
 }catch{return {status:'attributes_request_failed'};}finally{clearTimeout(timer);}
}
