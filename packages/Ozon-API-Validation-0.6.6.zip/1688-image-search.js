// Run in the existing 1688 image-search page MAIN world using its normal SDK.
async function read1688ImageSearch(){
 if(!/(^|\.)1688\.com$/.test(location.hostname))return {status:'invalid_context'};
 const query=new URL(location.href).searchParams;const imageId=query.get('imageId');
 if(!imageId)return {status:'image_context_missing',reason:'当前页面网址没有imageId，不能猜测上传参数'};
 const sdk=window.lib?.mtop;
 if(typeof sdk?.request!=='function')return {status:'normal_page_sdk_unavailable'};
 const failure=(error,status='image_request_failed')=>{
  const raw=Array.isArray(error?.ret)?error.ret:[];
  const codes=raw.map(x=>String(x).split('::')[0]).filter(x=>/^[A-Z0-9_]{1,100}$/.test(x)).slice(0,8);
  const cause=codes.some(x=>/TOKEN|SESSION|LOGIN/.test(x))?'会话或登录校验失败':codes.some(x=>/LIMIT|TRAFFIC|FREQUENCY/.test(x))?'请求频率或访问限制':codes.some(x=>/SIGN|APPKEY|PARAM|API|DATA/.test(x))?'接口参数或签名环境不匹配':'尚未分类的SDK失败';
  return {status,reason:cause+'；未自动重试',diagnostics:{sdk_error_codes:codes,error_kind:error?.message==='timeout'?'timeout':raw.length?'sdk_rejection':'exception',request_method:'GET',response_type:'jsonp',api:'mtop.relationrecommend.wirelessrecommend.recommend',method:'imageOfferSearchService'}};
 };
 let timer;
 try{
  const payload=await Promise.race([sdk.request({api:'mtop.relationrecommend.wirelessrecommend.recommend',v:'2.0',type:'GET',dataType:'jsonp',timeout:15000,data:{appId:32517,params:JSON.stringify({beginPage:1,pageSize:60,method:'imageOfferSearchService',searchScene:'pcImageSearch',appName:'pctusou',tab:'imageSearch',imageId})}}),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('timeout')),16000)})]);
  const ret=payload?.ret||[];if(ret.length&&!ret.some(v=>String(v).startsWith('SUCCESS')))return failure(payload,'image_request_rejected');
  const offers=new Map();
  const walk=(x,depth=0)=>{if(!x||typeof x!=='object'||depth>20)return;
   if(x.cellType==='image_search_offer'&&x.data){const d=x.data,id=String(d.offerId||'');if(/^\d+$/.test(id))offers.set(id,{offer_id:id,title:d.title||'',image:d.offerPicUrl||'',url:'https://detail.1688.com/offer/'+id+'.html',candidate_sku_id:String(d.skuId||''),search_moq_labels:(d.afterPriceList||[]).filter(a=>a.matKey==='quantity_begin').map(a=>a.text),free_shipping_tag_observed:(d.tags||[]).some(a=>a.text==='包邮'),cost_verified:false,discovery_method:'1688_image_search',match_verified:false});}
   for(const v of Object.values(x).slice(0,300))if(v&&typeof v==='object')walk(v,depth+1);
  };walk(payload);
  return {status:'image_candidates_read',offers:[...offers.values()],image_binding_verified:false,pagination_complete:false};
 }catch(error){return failure(error);}finally{clearTimeout(timer);}
}
