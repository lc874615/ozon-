function normalizeSupplierPackage(attributes){
 const values={},evidence=[],conflicts=[];
 const add=(key,value,unit,label,raw)=>{if(!Number.isFinite(value)||value<=0)return;if(values[key]!==undefined&&Math.abs(values[key]-value)>0.001)conflicts.push(key);else values[key]=value;evidence.push({key,value,unit,label,raw});};
 for(const a of attributes){const label=String(a.name||'').replace(/\s+/g,''),raw=String(a.value||'').trim();
  if(/净重|商品重量|产品重量|裸重/.test(label))continue;
  const units=(label+' '+raw).toLowerCase();
  if(/毛重|含包装重量|包装重量/.test(label)){const match=raw.match(/^\s*(\d+(?:\.\d+)?)\s*(kg|g|千克|公斤|克)?\s*$/i);if(match){const u=match[2]||(/kg|千克|公斤/.test(units)?'kg':/(?:\bg\b|克)/.test(units)?'g':null);if(u)add('gross_weight_g',Number(match[1])*(/kg|千克|公斤/i.test(u)?1000:1),'g',label,raw);}continue;}
  if(!/包装|外箱|装箱/.test(label))continue;
  const factor=/mm|毫米/.test(units)?1:/cm|厘米/.test(units)?10:null;if(factor===null)continue;
  const combined=raw.match(/^\s*(\d+(?:\.\d+)?)\s*[xX×*]\s*(\d+(?:\.\d+)?)\s*[xX×*]\s*(\d+(?:\.\d+)?)/);
  if(combined&&/尺寸|长宽高/.test(label)){['length_mm','width_mm','height_mm'].forEach((k,i)=>add(k,Number(combined[i+1])*factor,'mm',label,raw));continue;}
  const key=/长/.test(label)?'length_mm':/宽/.test(label)?'width_mm':/高/.test(label)?'height_mm':null;
  const single=raw.match(/^\s*(\d+(?:\.\d+)?)\s*(?:mm|cm|毫米|厘米)?\s*$/i);if(key&&single)add(key,Number(single[1])*factor,'mm',label,raw);
 }
 const missing=['length_mm','width_mm','height_mm','gross_weight_g'].filter(k=>values[k]===undefined);
 return {status:conflicts.length?'package_conflict':missing.length?'package_missing':'package_fields_read',values,evidence,missing,conflicts,packaging_basis_verified:!conflicts.length&&!missing.length};
}
// Read only explicit packaging tables; never scan unrelated page/account text.
function parse1688PackageRows(headers, rows){
 const h=headers.map(x=>String(x).replace(/\s+/g,''));
 const axis=['长','宽','高'].map(label=>h.findIndex(x=>x.startsWith(label)&&/cm|厘米|mm|毫米/i.test(x)));
 const weight=h.findIndex(x=>/^重量|毛重|包装重量/.test(x)&&/kg|公斤|千克|g|克/i.test(x));
 if(axis.includes(-1)||weight<0)return [];
 return rows.map((cells,index)=>{
  const values={};
  axis.forEach((col,i)=>{const n=Number(String(cells[col]??'').trim());values[['length_mm','width_mm','height_mm'][i]]=n*(/mm|毫米/i.test(h[col])?1:10);});
  values.gross_weight_g=Number(String(cells[weight]??'').trim())*(/kg|公斤|千克/i.test(h[weight])?1000:1);
  if(!Object.values(values).every(n=>Number.isFinite(n)&&n>0))return null;
  const volumeCol=h.findIndex(x=>/^体积/.test(x)&&/cm|厘米/i.test(x));
  if(volumeCol>=0){const reported=Number(cells[volumeCol]);if(!Number.isFinite(reported)||Math.abs(reported-values.length_mm*values.width_mm*values.height_mm/1000)>0.01)return null;}
  const specCols=h.map((x,i)=>/规格|颜色|型号|sku/i.test(x)?i:-1).filter(i=>i>=0);
  return {row_index:index,values,specifications:specCols.map(i=>({name:h[i],value:String(cells[i]||'').slice(0,160)})),quantity_basis:'per_item',source:'packaging_section_table',packaging_basis_verified:true};
 }).filter(Boolean);
}
function read1688PackagingTables(){
 const rows=[];
 for(const table of document.querySelectorAll('table,[role="table"]')){
  let section=table,verified=false;
  for(let depth=0;section&&depth<5;depth++,section=section.parentElement){
   const text=section.innerText||'';
   if(text.length<15000&&/包装信息/.test(text)&&/商品件重尺/.test(text)){verified=true;break;}
  }
  if(!verified)continue;
  const tr=[...table.querySelectorAll('tr,[role="row"]')];
  const cells=tr.map(r=>[...r.querySelectorAll('th,td,[role="columnheader"],[role="cell"]')].map(c=>c.innerText?.trim()||''));
  const hi=cells.findIndex(r=>r.some(x=>/^长.*(?:cm|mm|厘米|毫米)/i.test(x.replace(/\s+/g,''))));
  if(hi<0)continue;
  rows.push(...parse1688PackageRows(cells[hi],cells.slice(hi+1)));
 }
 return rows;
}
async function readCurrent1688Package(){
 const offerId=location.hostname==='detail.1688.com'&&location.pathname.match(/^\/offer\/(\d+)\.html$/)?.[1];
 if(!offerId)return {status:'detail_page_required'};
 const rows=read1688PackagingTables();
 // Attribute failure must not discard a readable packaging table.
 const result=await read1688DecisionAttributes();
 const fallback=normalizeSupplierPackage(result.attributes||[]);
 const packaging=rows.length?{status:'package_rows_read_mapping_required',values:{},rows,missing:[],conflicts:[],packaging_basis_verified:true,selected_sku_identity_verified:false,selection_required:true,selection_policy:'exact_sku_row_or_verified_single_row_color_only_inheritance'}:fallback;
 return {status:'supplier_package_observed',offer_id:offerId,attributes:result.attributes||[],attribute_read_status:result.status,packaging,selected_sku_identity_verified:false,source:rows.length?'packaging_section_table':'decisionAttrService',scope:'offer_packaging_rows_not_selected_sku_verified',sales_unit_quantity:{value:1,verified:false,basis:'user_default_when_quantity_not_parsed'}};
}
