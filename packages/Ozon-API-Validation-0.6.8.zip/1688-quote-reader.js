/* Observe only the site's own calculatePrice XHR. No signed URL, headers,
   buyer/seller account identifiers or address values are retained or replayed. */
function normalize1688ObservedQuote(request,response){
 const money=v=>{const s=String(v);if(!/^\d+(?:\.\d{1,2})?$/.test(s))throw Error('invalid money');const [a,b='']=s.split('.');const n=Number(a)*100+Number(b.padEnd(2,'0'));if(!Number.isSafeInteger(n))throw Error('money range');return n;};
 const fmt=v=>(v/100).toFixed(2);
 try{
  if(!Array.isArray(response.ret)||!response.ret.some(x=>String(x).startsWith('SUCCESS')))throw Error('quote not successful');
  const lines=typeof request.skuCalParams==='string'?JSON.parse(request.skuCalParams):request.skuCalParams;
  if(!Array.isArray(lines)||lines.length!==1)throw Error('single SKU quote required');
  const l=lines[0],offer=String(request.offerId),sku=String(l.skuId),q=Number(l.number);
  if(!/^\d+$/.test(offer)||!/^\d+$/.test(sku)||!Number.isSafeInteger(q)||q<1)throw Error('invalid identity or quantity');
  const d=response.data,final=money(d.totalFinalPrice),original=money(d.totalOriginalPrice),discount=money(d.totalDiscount);
  if(original-final!==discount)throw Error('inconsistent discount');
  return {status:'quantity_quote_read',offer_id:offer,sku_id:sku,purchase_quantity:q,currency:'CNY',goods_total_cny:fmt(final),goods_original_total_cny:fmt(original),order_discount_cny:fmt(discount),free_shipping_for_this_quote:d.freePostage===true,domestic_freight_cny:d.freePostage===true?'0.00':null,observed_at:new Date().toISOString(),source:'normal_page_calculatePrice_response',sales_unit_quantity:{value:1,verified:false,basis:'user_default_when_quantity_not_parsed'},profit_eligible:false};
 }catch{return {status:'quote_unverified'};}
}
function readOrWatch1688Quote(){
 const offer=location.hostname==='detail.1688.com'&&location.pathname.match(/^\/offer\/(\d+)\.html$/)?.[1];
 if(!offer)return {status:'detail_page_required'};
 const key='__ozonSupplierQuoteObservationV1';
 if(!window[key]){
  const state={quotes:[],last_status:'waiting_for_normal_page_quote'};window[key]=state;
  const originalOpen=XMLHttpRequest.prototype.open,originalSend=XMLHttpRequest.prototype.send;
  const requests=new WeakMap();
  XMLHttpRequest.prototype.open=function(method,url,...rest){
   requests.delete(this);
   try{const u=new URL(String(url),location.href);if(u.hostname.endsWith('.1688.com')&&u.pathname.toLowerCase().includes('/mtop.1688.handpriceservice.calculateprice/'))requests.set(this,{data:u.searchParams.get('data')});}catch{}
   return originalOpen.call(this,method,url,...rest);
  };
  XMLHttpRequest.prototype.send=function(body){
   const meta=requests.get(this);
   if(meta){
    let request;
    try{const raw=typeof body==='string'?new URLSearchParams(body).get('data'):body instanceof URLSearchParams?body.get('data'):body instanceof FormData?body.get('data'):null;const parsed=JSON.parse(raw||meta.data||'{}');request={offerId:parsed.offerId,skuCalParams:parsed.skuCalParams};}catch{}
    if(request)this.addEventListener('load',()=>{try{
     const response=this.responseType==='json'?this.response:JSON.parse(this.responseText);
     const quote=normalize1688ObservedQuote(request,response);state.last_status=quote.status;
     if(quote.status==='quantity_quote_read'&&quote.offer_id===offer){state.quotes=state.quotes.filter(x=>!(x.offer_id===quote.offer_id&&x.sku_id===quote.sku_id&&x.purchase_quantity===quote.purchase_quantity));state.quotes.push(quote);state.quotes=state.quotes.slice(-20);}
    }catch{state.last_status='quote_unverified';}},{once:true});
   }
   return originalSend.call(this,body);
  };
 }
 return {status:window[key].quotes.length?'supplier_quotes_observed':'quote_observer_ready',offer_id:offer,quotes:window[key].quotes.filter(x=>x.offer_id===offer),last_status:window[key].last_status};
}
