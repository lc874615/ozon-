// Persistent single owned inactive search tab. Returns true while handling search.
async function advanceAutomaticImageSearch(job,key){
 const storage=chrome.storage.local;
 let state=(await storage.get('automaticImageSearchV1')).automaticImageSearchV1||{};
 const image=job.images?.[0],identity=job.ozon_sku+'|'+image;
 const post=async(path,data)=>{const r=await fetch('http://127.0.0.1:8765'+path,{method:'POST',headers:{'Content-Type':'application/json','X-Pairing-Key':key},body:JSON.stringify({...data,verification_reset:job.verification_reset}),signal:AbortSignal.timeout(10000)});if(!r.ok)throw Error('workbench_http_'+r.status);return r.json();};
 const save=async()=>{state.updated_at=new Date().toISOString();await storage.set({automaticImageSearchV1:state});try{await post('/api/image-search-progress',{ozon_sku:job.ozon_sku,phase:state.phase,reason:state.reason||'',source_image:image});}catch{}};
 const completed=(await storage.get('automaticImageSearchCompletedV1')).automaticImageSearchCompletedV1||{};
 if(completed[identity]){if(state.identity===identity&&state.tab_id){try{await chrome.tabs.remove(state.tab_id);delete state.tab_id;delete state.tab_close_pending;state.tab_closed=true;await save();}catch{}}return false;}
 if(!image){state={...state,identity,ozon_sku:job.ozon_sku,phase:'failed',reason:'ozon_main_image_missing'};await save();return true;}
 if(state.identity!==identity){
  // Do not reset another pending job's tab or associate its results to this SKU.
  if(state.identity&&!['done','failed'].includes(state.phase))return true;
  state={identity,ozon_sku:job.ozon_sku,source_image:image,tab_id:state.tab_id,phase:'opening',started_at:Date.now(),resume:job.crawl_resume_request};await save();
 }
 if(state.phase==='failed'){
  if(state.resume===job.crawl_resume_request){await save();return true;}
  const reusePreview=state.reason==='image_search_result_timeout'&&state.submitted_at&&state.tab_id;
  state={...state,phase:reusePreview?'waiting_search_results':'opening',reason:'',started_at:Date.now(),resume:job.crawl_resume_request};
  if(reusePreview){state.submitted_at=Date.now();delete state.confirmed_at;}await save();
 }
 try{
  let tab;if(state.tab_id)try{tab=await chrome.tabs.get(state.tab_id);}catch{}
  if(state.phase==='opening'){
   if(tab?.active){state.reason='search_worker_tab_active';await save();return true;}
   const url='https://air.1688.com/kapp/1688-search/pc-image-search/?tab=imageSearch';
   tab=tab?await chrome.tabs.update(tab.id,{url,active:false}):await chrome.tabs.create({url,active:false});
   state.tab_id=tab.id;state.phase='waiting_upload_control';state.started_at=Date.now();await save();return true;
  }
  if(!tab)throw Error('search_tab_closed');
  const u=new URL(tab.url||'about:blank');
  if(/(?:^|\.)(?:login|passport|punish)\./i.test(u.hostname))throw Error('login_or_verification_required');
  if(!/(^|\.)1688\.com$/.test(u.hostname)||tab.status!=='complete'){if(Date.now()-state.started_at>60000)throw Error('search_navigation_timeout');return true;}
  await chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',files:['1688-image-upload.js']});
  const inspect=(await chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',func:()=>inspect1688ImageUpload()}))[0]?.result;
  state.page_probe=inspect;state.page_path=u.pathname;
  if(inspect?.status==='login_or_verification_required')throw Error(inspect.status);
  if(state.phase==='waiting_upload_control'){
   if(tab.pendingUrl||!u.pathname.includes('/pc-image-search/')||u.searchParams.has('imageId')){if(Date.now()-state.started_at>60000)throw Error('search_navigation_timeout');return true;}
   const ready=(await chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',func:()=>prepare1688ImageUpload()}))[0]?.result;
   if(ready?.status!=='upload_control_ready'){
    state.control_status=ready?.status||'no_control_response';await save();if(Date.now()-state.started_at>30000)throw Error(state.control_status);return true;
   }
   const src=new URL(image);if(src.protocol!=='https:'||!/(^|\.)ozonstatic\.(?:cn|ru|com)$/.test(src.hostname))throw Error('unsupported_ozon_image_host');
   const response=await fetch(src.href,{credentials:'omit',signal:AbortSignal.timeout(20000)});if(!response.ok)throw Error('ozon_image_fetch_failed');
   const type=(response.headers.get('content-type')||'').split(';')[0];if(!/^image\/(jpeg|png|webp)$/.test(type))throw Error('unsupported_image_type');
   const bytes=new Uint8Array(await response.arrayBuffer());if(!bytes.length||bytes.length>10000000)throw Error('image_size_limit');
   let binary='';for(let n=0;n<bytes.length;n+=8192)binary+=String.fromCharCode(...bytes.subarray(n,n+8192));
   // Persist before dispatch: never silently upload twice after worker interruption.
   state.phase='waiting_search_results';state.submitted_at=Date.now();await save();
   const uploaded=(await chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',func:p=>submit1688SearchImage(p),args:[{base64:btoa(binary),type,name:'ozon-'+job.ozon_sku+'.'+(type==='image/jpeg'?'jpg':type.split('/')[1])}]}))[0]?.result;
   if(uploaded?.status!=='image_submitted')throw Error(uploaded?.status||'upload_dispatch_failed');return true;
  }
  if(state.phase==='waiting_search_results'){
   if(!inspect?.image_id){
    const confirmation=(await chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',func:token=>confirm1688UploadedImageSearch(token),args:[String(state.submitted_at)]}))[0]?.result;
    state.confirmation_status=confirmation?.status||'no_confirmation_response';
    if(confirmation?.status==='login_or_verification_required')throw Error(confirmation.status);
    if(confirmation?.status==='search_confirmation_ambiguous')throw Error(confirmation.status);
    if(confirmation?.status==='search_confirmation_clicked'){state.confirmed_at=Date.now();}
    await save();if(Date.now()-(state.confirmed_at||state.submitted_at)>60000)throw Error('image_search_result_timeout');return true;
   }
   await chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',files:['1688-image-search.js']});
   const result=(await chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',func:()=>read1688ImageSearch()}))[0]?.result;
   if(result?.status==='normal_page_sdk_unavailable'&&Date.now()-state.submitted_at<60000)return true;
   if(result?.status!=='image_candidates_read')throw Error(result?.status||'image_search_read_failed');
   if(!result.offers?.length)throw Error('image_search_empty');
   state.result=result;state.image_id=inspect.image_id;state.phase='syncing_search_results';await save();
  }
  if(state.phase==='syncing_search_results'){
   await post('/api/supplier-candidates',{ozon_sku:job.ozon_sku,...state.result,auto_uploaded_source_image:image,image_binding_verified:true});
   completed[identity]={at:new Date().toISOString(),image_id:state.image_id};await storage.set({automaticImageSearchCompletedV1:completed});delete state.result;state.phase='done';state.reason='';await save();
   if(state.tab_id){try{await chrome.tabs.remove(state.tab_id);delete state.tab_id;state.tab_closed=true;}catch{state.tab_close_pending=true;}await save();}
   return true;
  }
 }catch(e){
  if(state.phase==='syncing_search_results'&&(e instanceof TypeError||/Timeout|Abort/.test(e?.name||''))){state.reason='local_workbench_unavailable';}
  else{state.phase='failed';state.reason=String(e.message||'image_search_failed').slice(0,120);}
  await save();
 }
 return true;
}
