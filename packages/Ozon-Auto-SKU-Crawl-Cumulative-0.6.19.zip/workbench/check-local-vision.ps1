$ErrorActionPreference = 'Stop'
$gpu = Get-Command nvidia-smi -ErrorAction SilentlyContinue
if ($gpu) { & $gpu.Source --query-gpu=name,memory.total,driver_version --format=csv }
else { Write-Host 'nvidia-smi not found. Check NVIDIA driver installation.' }
try {
    $models = Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/tags' -TimeoutSec 5
    $models.models | Select-Object name,size | Format-Table
    $running = Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/ps' -TimeoutSec 5
    $running.models | Select-Object name,size,size_vram | Format-Table
    Write-Host 'API is reachable. This does not prove image matching accuracy.'
} catch { Write-Host 'Local Ollama API is not reachable. Start Ollama and rerun.'; exit 1 }
