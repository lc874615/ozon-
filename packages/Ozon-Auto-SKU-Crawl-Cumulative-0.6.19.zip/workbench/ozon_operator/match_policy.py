"""Explicit matching policy; never substitutes rules for visual observations."""
from decimal import Decimal,InvalidOperation
DEFAULT_POLICY={'version':2,'color':'same_family_lighting_only','dimension_tolerance_percent':'2','material':'compare_parameters','labels':'ignore_text_parameters','unclear_details':'overall_similarity_accepted','pack_quantity':'allow_ceil_procurement','automatic_vision_connected':False}
OPTIONS={'color':['same_family_lighting_only','near_exact'],'material':['compare_parameters','documented','appearance_accepted'],'labels':['ignore_text_parameters','product_parameters_ignore_marketing','all_visible_text'],'unclear_details':['hold','overall_similarity_accepted'],'pack_quantity':['allow_ceil_procurement','exact_pack_quantity']}
def validate_policy(data):
 result=dict(DEFAULT_POLICY)
 for key,options in OPTIONS.items():
  if data.get(key)not in options:raise ValueError('invalid '+key)
  result[key]=data[key]
 try:
  n=Decimal(str(data['dimension_tolerance_percent']))
  if not n.is_finite()or not 0<=n<=2:raise ValueError('dimension tolerance')
 except (KeyError,InvalidOperation):raise ValueError('dimension tolerance')
 result['dimension_tolerance_percent']=str(n)
 return result

def evaluate_dimensions(pairs,tolerance_percent):
 pending=[];rejected=[]
 if not isinstance(pairs,list)or not pairs:return {'pending':['corresponding_product_dimensions_missing'],'rejected':[]}
 tolerance=Decimal(str(tolerance_percent))/100
 for pair in pairs:
  name=str(pair.get('name','dimension'))
  try:
   a,b=Decimal(str(pair['ozon_mm'])),Decimal(str(pair['supplier_mm']))
   if not a.is_finite()or not b.is_finite()or min(a,b)<=0 or pair.get('basis')!='product' or not pair.get('evidence'):raise ValueError()
   if abs(a-b)/a>tolerance:rejected.append(name)
  except (KeyError,TypeError,ValueError,InvalidOperation):pending.append(name)
 return {'pending':pending,'rejected':rejected}

def current_policy():
 from pathlib import Path
 import json
 path=Path(__file__).resolve().parents[1]/'data'/'match-policy.json'
 if not path.exists():return dict(DEFAULT_POLICY)
 old=json.loads(path.read_text(encoding='utf-8'))
 if old.get('version',1)<2:
  from datetime import datetime,timezone
  history=path.parent/'policy-history';history.mkdir(exist_ok=True)
  (history/(datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%f')+'-before-user-policy-v2.json')).write_bytes(path.read_bytes())
  confirmed=dict(DEFAULT_POLICY);confirmed['basis']='user_confirmed_six_answers_2026_10_30'
  path.write_text(json.dumps(confirmed,ensure_ascii=False,indent=2),encoding='utf-8')
  return confirmed
 return validate_policy(old)
