"""Sanitized page quote intake; quote observation does not approve a visual match."""
import re
from .supplier_variants import purchase_quantity
from decimal import Decimal,InvalidOperation
from datetime import datetime,timezone

def normalize_quote(q, offer_id):
 def money(key):
  v=Decimal(str(q[key]))
  if not v.is_finite() or v<0 or v*100!=(v*100).to_integral_value():raise ValueError('invalid money')
  return v
 try:
  if q.get('status')!='quantity_quote_read' or str(q.get('offer_id'))!=str(offer_id):raise ValueError('quote offer mismatch')
  sku=str(q['sku_id']);qty=q['purchase_quantity']
  if not re.fullmatch(r'\d+',sku)or type(qty)is not int or qty<1 or q.get('currency')!='CNY':raise ValueError('invalid quote identity or quantity')
  final=money('goods_total_cny');original=money('goods_original_total_cny');discount=money('order_discount_cny')
  if original-final!=discount:raise ValueError('discount inconsistent')
  free=q.get('free_shipping_for_this_quote')is True
  return {'offer_id':str(offer_id),'sku_id':sku,'purchase_quantity':qty,'currency':'CNY','goods_total_cny':str(final),'goods_original_total_cny':str(original),'order_discount_cny':str(discount),'domestic_freight_cny':'0.00'if free else None,'free_shipping_for_this_quote':free,'received_at':datetime.now(timezone.utc).isoformat(),'source':'normal_page_calculatePrice_response','sales_unit_quantity':{'value':1,'basis':'user_default_one'},'profit_eligible':False}
 except (KeyError,TypeError,ValueError,InvalidOperation)as e:raise ValueError('invalid supplier quote')from e

def merge_quotes(task,offer_id,quotes):
 matches=[o for o in task.get('supplier_offers',[])if str(o.get('offer_id'))==str(offer_id)]
 if len(matches)!=1:raise ValueError('供应商必须唯一对应当前Ozon SKU的图搜候选')
 if not isinstance(quotes,list)or not 1<=len(quotes)<=20:raise ValueError('invalid quote count')
 clean=[normalize_quote(q,offer_id)for q in quotes];offer=matches[0]
 existing={(q['sku_id'],q['purchase_quantity']):q for q in offer.get('quantity_quotes',[])}
 for q in clean:existing[(q['sku_id'],q['purchase_quantity'])]=q
 offer['quantity_quotes']=list(existing.values())[-100:]
 required=task.get('units_per_sales_sku')
 if type(required)is not int or required<1:required=None
 supplier_units=offer.get('sales_unit_quantity',{}).get('value',1)
 if required is not None:
  try:required=purchase_quantity(required,supplier_units)
  except ValueError:required=None
 matching=[q for q in offer['quantity_quotes']if q['purchase_quantity']==required and q['sku_id']==str(offer.get('selected_sku_id',''))]
 offer['quote_status']='quantity_quote_available_needs_sku_match'if matching else 'required_quantity_quote_missing'
 return {'accepted':len(clean),'required_purchase_quantity':required,'matching_quote_count':len(matching),'profit_eligible':False}
