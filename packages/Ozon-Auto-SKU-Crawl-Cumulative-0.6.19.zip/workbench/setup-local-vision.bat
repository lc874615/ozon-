@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup-local-vision.ps1"
if errorlevel 1 echo Local vision setup failed. Read the error above; do not assume installation completed.
pause
