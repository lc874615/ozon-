$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
Write-Host 'Preparing local vision: Ollama + qwen2.5vl:3b'
Write-Host 'First setup downloads Ollama and a model of about 3.2 GB. Inference stays local.'
$ollamaCommand = Get-Command ollama -ErrorAction SilentlyContinue
$ollamaPath = if ($ollamaCommand) { $ollamaCommand.Source } else { Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama.exe' }
if (-not (Test-Path $ollamaPath)) {
    $installer = Join-Path $env:TEMP 'Ozon-OllamaSetup.exe'
    Write-Host 'Downloading the official Windows installer...'
    Invoke-WebRequest -Uri 'https://ollama.com/download/OllamaSetup.exe' -OutFile $installer -UseBasicParsing
    $signature = Get-AuthenticodeSignature -FilePath $installer
    if ($signature.Status -ne 'Valid') { throw 'Installer signature is not valid. Installation stopped.' }
    Write-Host ('Verified signer: ' + $signature.SignerCertificate.Subject)
    Start-Process -FilePath $installer -Wait
    if (-not (Test-Path $ollamaPath)) {
        $ollamaCommand = Get-Command ollama -ErrorAction SilentlyContinue
        if ($ollamaCommand) { $ollamaPath = $ollamaCommand.Source }
    }
    if (-not (Test-Path $ollamaPath)) { throw 'Ollama installation not found. Complete installation and run setup again.' }
}
$localApi = 'http://127.0.0.1:11434'
try { $null = Invoke-RestMethod -Uri "$localApi/api/tags" -TimeoutSec 3 }
catch {
    $env:OLLAMA_HOST = '127.0.0.1:11434'
    Start-Process -FilePath $ollamaPath -ArgumentList 'serve' -WindowStyle Minimized
    $ready = $false
    for ($attempt = 0; $attempt -lt 20; $attempt++) {
        Start-Sleep -Seconds 1
        try { $null = Invoke-RestMethod -Uri "$localApi/api/tags" -TimeoutSec 2; $ready = $true; break } catch {}
    }
    if (-not $ready) { throw 'Local Ollama API did not start. Check Ollama logs.' }
}
Write-Host 'Downloading/verifying model. Existing model blobs will be reused.'
& $ollamaPath pull 'qwen2.5vl:3b'
if ($LASTEXITCODE -ne 0) { throw 'Model download failed. Rerun setup to resume.' }
$showBody = @{ model = 'qwen2.5vl:3b' } | ConvertTo-Json
$show = Invoke-RestMethod -Uri "$localApi/api/show" -Method Post -ContentType 'application/json' -Body $showBody -TimeoutSec 15
if ($show.capabilities -notcontains 'vision') { throw 'Downloaded model did not report vision capability.' }
$dataPath = Join-Path $PSScriptRoot 'data'
New-Item -ItemType Directory -Force -Path $dataPath | Out-Null
@{ provider = 'ollama'; model = 'qwen2.5vl:3b'; base_url = $localApi; real_product_validation_passed = $false } | ConvertTo-Json | Set-Content -Encoding UTF8 -Path (Join-Path $dataPath 'local-vision.json')
Write-Host 'Local model is installed and API is reachable. Product matching accuracy is NOT yet validated.'
Write-Host 'Close the old workbench and run start.bat. Then run the local image comparison test.'
