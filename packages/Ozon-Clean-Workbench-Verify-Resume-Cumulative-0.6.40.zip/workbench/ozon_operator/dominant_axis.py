"""Select one evidenced differentiating SKU axis; uncertain cases never exclude."""
import re,hashlib,json
from .parameter_prefilter import facts,material,compatible
from .appearance_terms import color,COLORS
from .attribute_integrity import effective_dimensions,image_reference,effective_capacity

def volume_ml(text):
 m=re.fullmatch(r'\s*(\d+(?:[.,]\d+)?)\s*(ml|мл|毫升|l|л|升)\s*',str(text),re.I)
 return float(m.group(1).replace(',','.'))*(1000 if m.group(2).lower()in ('l','л','升')else 1)if m else None

def classify(name,values):
 n=name.lower()
 if all(volume_ml(v)is not None for v in values):return 'capacity'
 if any(any(re.search(pattern,str(v),re.I)for pattern in COLORS.values())for v in values):return 'color'
 if all(material(v)is not None for v in values):return 'material'
 if re.search(r'尺寸|大小|规格|长度|宽度|高度|深度|размер|высот|ширин|глубин|длин|size',n)and any(re.search(r'\d',v)for v in values):return 'dimensions'
 return 'unknown'

def choose_axis(offer,task):
 variations={}
 for v in offer.get('detail_variants',[]):
  for name,value in (v.get('specs')or{}).items():variations.setdefault(name,set()).add(str(value))
 axes=[{'name':name,'kind':classify(name,values),'values':sorted(values),'value_count':len(values)}for name,values in variations.items()if len(values)>1 or classify(name,values)=='color']
 title=str(task.get('title','')).lower();types=' '.join(str(a.get('value',''))for a in task.get('attributes',[])if a.get('name')in ('Тип','产品类型','产品类别')).lower();purpose=title+' '+types
 priority='capacity'if re.search(r'杯|瓶|壶|罐|桶|круж|бутыл|кувшин|термос|container|bottle',purpose)else'dimensions'if re.search(r'床|桌|地毯|窗帘|матрас|ков[её]р|штор|стол|bed|curtain',purpose)else'color'
 chosen=[a for a in axes if a['kind']==priority]
 if len(chosen)>1 and priority=='color':
  scores={a['name']:(sum(any(re.search(p,v,re.I)for p in COLORS.values())for v in a['values'])/len(a['values']),len({k for v in a['values']for k,p in COLORS.items()if re.search(p,v,re.I)}))for a in chosen}
  best=max(scores.values());chosen=[a for a in chosen if scores[a['name']]==best]
 if len(chosen)==1:return {**chosen[0],'status':'selected','basis':'actual_value_color_content'if chosen[0]['kind']=='color'else'product_purpose_primary_axis','other_axes_not_filtered':True}
 recognized=[a for a in axes if a['kind']!='unknown']
 if len(recognized)==1:return {**recognized[0],'status':'selected','basis':'only_recognized_varying_axis','other_axes_not_filtered':True}
 return {'status':'uncertain','kind':None,'name':None,'basis':'multiple_or_no_evidenced_axes','axes':axes,'other_axes_not_filtered':True}

def color_reference(task):
 ref=image_reference(task);out={}
 for a in task.get('attributes',[]):
  name=str(a.get('name','')).strip().lower();value=a.get('value','')
  role='body_color'if name in ('颜色','主体颜色','椅身颜色','цвет','цвет товара','цвет обивки','body color')else'leg_color'if name in ('椅腿颜色','支架颜色','цвет ножек','leg color')else None
  c=color(value)
  if role and c:
   if role in out and out[role]!=c:out[role]=None
   elif role not in out:out[role]=c
 for key in ('body_color','leg_color'):
  if ref.get(key)in ('grey','black','white','pink','blue','green','purple','brown','gold','silver'):out[key]=ref[key]
 return out

def prepare_context(task):
 colors=color_reference(task);palette=set();color_values={}
 for a in task.get('attributes',[]):
  name=str(a.get('name','')).strip().lower()
  if name not in ('颜色','主体颜色','椅身颜色','цвет','цвет товара','цвет обивки','body color'):continue
  text=str(a.get('value',''));color_values.setdefault(name,set()).add(text)
  palette.update(k for k,pattern in COLORS.items()if re.search(pattern,text,re.I))
 if any(len(values)>1 for values in color_values.values()):palette.clear()
 ref=image_reference(task)
 if not palette and ref and ref.get('body_color')in COLORS:palette={ref['body_color']}
 dimensions=effective_dimensions(task);capacity=effective_capacity(task);materials=facts(task.get('attributes',[]))
 signature=hashlib.sha256(json.dumps([task.get('attributes'),ref],ensure_ascii=False,sort_keys=True).encode()).hexdigest()
 return {'colors':colors,'palette':sorted(palette),'dimensions':dimensions,'capacity':capacity,'materials':materials,'signature':signature,'memo':{}}

def reference_status(axis,context):
 if axis.get('status')!='selected':return '主差异未确定，暂不排除'
 kind=axis.get('kind')
 if kind=='color':return '任一色系命中即通过颜色关：'+', '.join(context['palette'])if context['palette']else'等待明确颜色参照'
 if kind=='dimensions':return '可比产品尺寸已就绪'if context['dimensions']else'尺寸缺失或冲突，暂不排除'
 if kind=='capacity':return '容量参照已就绪'if context['capacity']else'容量参照缺失或冲突，暂不排除'
 return '仅在同部位材质明确时排除'

def conflict(task,v,context=None):
 context=context or prepare_context(task)
 axis=v.get('prefilter_axis')or{}
 value=(v.get('specs')or{}).get(axis.get('name'))
 key=(axis.get('kind'),axis.get('name'),str(value),tuple(axis.get('values',[])))
 if key not in context['memo']:context['memo'][key]=_conflict(task,v,context)
 return context['memo'][key]

def _conflict(task,v,context):
 axis=v.get('prefilter_axis')or{}
 if axis.get('status')!='selected':return None
 name=axis['name'];value=(v.get('specs')or{}).get(name)
 if value is None:return None
 kind=axis['kind']
 if kind=='color':
  supplied={k for k,pattern in COLORS.items()if re.search(pattern,str(value),re.I)}
  expected=set(context['palette'])
  if expected and supplied and not expected.intersection(supplied):return {'field':'color_palette','ozon':sorted(expected),'supplier':sorted(supplied),'reason':'颜色筛选：未包含Ozon允许的任一色系'}
 elif kind=='capacity':
  target=context['capacity'];actual=volume_ml(value)
  if target and actual and abs(target-actual)/target>.02:return {'field':'capacity_ml','ozon':target,'supplier':actual,'reason':'主差异为容量，明确容量不一致'}
 elif kind=='dimensions':
  reference=context['dimensions'];supplier=facts([],v.get('specs',{}))
  for key,expected in reference.items():
   actual=supplier.get(key)
   if actual and abs(expected-actual)/expected>.02:return {'field':key,'ozon':expected,'supplier':actual,'reason':'主差异为产品尺寸，同含义数值差异超过2%'}
 elif kind=='material':
  kinds={material(v)for v in axis.get('values',[])}
  role='frame_material'if kinds and kinds<={'wood','metal','plastic'}else'upholstery_material'if kinds and kinds<={'fabric','velvet','linen','leather','pu','real_leather'}else None
  actual=material(value);reference=context['materials'].get(role)if role else None
  if actual and reference and not compatible(actual,reference):return {'field':'upholstery_material','ozon':reference,'supplier':actual,'reason':'主差异为面料，明确材质不一致'}
 return None

def color_screening(value,context):
 found={k for k,p in COLORS.items()if re.search(p,str(value),re.I)}
 allowed=set(context['palette'])
 return {'result':'通过'if found&allowed else'不符'if found and allowed else None,'observed_colors':sorted(found),'allowed_colors':sorted(allowed),'scope':'color_only_not_final_visual_or_profit'}
