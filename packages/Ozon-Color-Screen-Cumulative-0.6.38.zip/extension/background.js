importScripts('1688-attention.js','1688-detail-fetch.js','automatic-image-search.js','selection-filters.js','packaging-reader.js','api-batch-collector.js');
let busy=false,control='run';
async function controlGate(id){
 if(control==='stop')throw new Error('USER_TERMINATED');
 if(control==='pause'){await saveJob(id,{status:'paused',stage:'用户暂停，进度保留'});while(control==='pause')await new Promise(r=>setTimeout(r,250));if(control==='stop')throw new Error('USER_TERMINATED');await saveJob(id,{status:'running',stage:'继续采集'});}
}

function describeTab(t){
 let host=null,route='other',sku=null;try{const u=new URL(t.url);host=u.hostname;sku=u.pathname.match(/-(\d+)\/?$/)?.[1]||u.pathname.match(/^\/product\/(\d+)\/?$/)?.[1]||null;route=u.pathname.startsWith('/product/')?'product':u.pathname.startsWith('/search')?'search':u.pathname.startsWith('/app/')?'seller_app':'other';}catch{}
 return {id:t.id,active:!!t.active,status:t.status,host,route,product_sku:sku};
}
function chooseTab(tabs,seeds=[]){const ready=tabs.filter(t=>t.status==='complete');return ready.find(t=>t.active&&seeds.includes(describeTab(t).product_sku))||ready.find(t=>seeds.includes(describeTab(t).product_sku))||ready.find(t=>t.active)||ready.sort((a,b)=>(b.lastAccessed||0)-(a.lastAccessed||0))[0];}
function inspectPageEnvironment(){
 const text=(document.body?.innerText||'').slice(0,12000),ua=navigator.userAgent;
 return {origin:location.origin,ready_state:document.readyState,visibility:document.visibilityState,secure_context:isSecureContext,online:navigator.onLine,cookies_enabled:navigator.cookieEnabled,fetch_available:typeof fetch==='function',chromium_major:ua.match(/(?:Chrome|Chromium)\/(\d+)/)?.[1]||null,language:navigator.language,challenge_text_detected:/подтвердите.{0,30}(?:человек|робот)|доступ ограничен|验证码|access denied|verify you are human/i.test(text),execution_world:'ISOLATED',credentials_mode:'include',custom_request_headers:false,cookie_values_read:false,network_requests:0};
}
async function requestEnvironment(seeds=[]){
 const buyerTabs=await chrome.tabs.query({url:['https://www.ozon.ru/*','https://ozon.ru/*']}),sellerTabs=await chrome.tabs.query({url:['https://seller.ozon.ru/*','https://seller.ozonru.cn/*']});
 const buyer=chooseTab(buyerTabs,seeds),seller=chooseTab(sellerTabs);
 const report={captured_at:new Date().toISOString(),network_requests:0,selection_policy:'active_matching_seed_then_matching_seed_then_active_then_recent_complete',buyer_candidates:buyerTabs.map(describeTab),seller_candidates:sellerTabs.map(describeTab),selected_buyer:buyer?describeTab(buyer):null,selected_seller:seller?describeTab(seller):null};
 for(const [name,tab]of [['buyer',buyer],['seller',seller]])if(tab){try{report[name]=(await chrome.scripting.executeScript({target:{tabId:tab.id},world:'ISOLATED',func:inspectPageEnvironment}))[0]?.result||{status:'empty_environment'};}catch{report[name]={status:'environment_injection_failed'};}}
 return {buyer,seller,report};
}
let syncBusy=false;
async function flushLocalQueue(){
 if(syncBusy)return {status:'sync_busy'};syncBusy=true;
 try{const {workbenchKey:key}=await chrome.storage.local.get('workbenchKey');if(!key)return {status:'not_paired'};
  let sent=0;while(true){const q=(await chrome.storage.local.get('workbenchQueue')).workbenchQueue||[];if(!q.length)break;
   const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),5000);
   try{const response=await fetch('http://127.0.0.1:8765/api/import',{method:'POST',headers:{'Content-Type':'application/json','X-Pairing-Key':key},signal:controller.signal,body:JSON.stringify({job:{result:{results:[q[0]]}}})});if(!response.ok)throw new Error('HTTP '+response.status);await response.json();
    const latest=(await chrome.storage.local.get('workbenchQueue')).workbenchQueue||[];await chrome.storage.local.set({workbenchQueue:latest.filter(x=>x.sku!==q[0].sku),workbenchSyncStatus:{status:'synced',at:new Date().toISOString()}});sent++;
   }catch{await chrome.storage.local.set({workbenchSyncStatus:{status:'pending_retry',message:'工作台未连接或配对失败，数据已保留'}});return {status:'pending_retry',sent};}finally{clearTimeout(timer);}
  }return {status:'synced',sent};
 }finally{syncBusy=false;}
}
async function queueLocalResult(item){if(item.status!=='api_data_complete')return;const q=(await chrome.storage.local.get('workbenchQueue')).workbenchQueue||[];if(!q.some(x=>x.sku===item.sku))q.push(item);await chrome.storage.local.set({workbenchQueue:q});}
async function saveJob(id,update){const {apiJob:j}=await chrome.storage.local.get('apiJob');if(j?.id===id)await chrome.storage.local.set({apiJob:{...j,...update}});}
async function runValidation(id,seeds,filters,company,concurrency){
 try{
  const {buyer,seller,report}=await requestEnvironment(seeds);await saveJob(id,{request_environment:report});
  if(!buyer||!seller)throw new Error('请在同一浏览器打开正常可访问的Ozon买家页和已登录的卖家页，再启动验证');
  let operations=0;const reads=[];
  async function call(stage,tab,files,func,args){
   await controlGate(id);const start=Date.now();await saveJob(id,{stage,operations,updated_at:new Date().toISOString()});
   await chrome.scripting.executeScript({target:{tabId:tab},world:'ISOLATED',files});
   const result=(await chrome.scripting.executeScript({target:{tabId:tab},world:'ISOLATED',func,args}))[0]?.result||{status:'empty_result'};
   operations++;reads.push({stage,sku:String(args[0]),elapsed_ms:Date.now()-start,result});await saveJob(id,{operations,reads:reads.slice(-200),updated_at:new Date().toISOString()});return result;
  }
  const ports={
   variants:sku=>call('读取全部变体',buyer.id,['buyer-variants-json.js'],sku=>readBuyerVariantsJson(sku),[sku]),
   buyer:sku=>call('读取价格/送达/图片',buyer.id,['delivery-reference.js','buyer-json-reader.js'],sku=>readBuyerProductJson(sku),[sku]),
   market:sku=>call('读取销量/日期/履约',seller.id,['native-market-reader.js'],(sku,company)=>readNativeSellerMarket(sku,company),[sku,company]),
   packaging:async(sku,hint)=>{
    const key='temporaryCreationLedger',stored=(await chrome.storage.local.get(key))[key]||{},previous=stored[sku];
    if(previous)return previous.result||{status:'temporary_creation_result_unknown',creation_may_have_occurred:true};
    let companyId=company;
    if(!companyId){const info=await chrome.scripting.executeScript({target:{tabId:seller.id},func:()=>{const h=document.querySelector('header,[role="banner"]');return (h?.innerText||'').match(/\bShop\s*#?\s*(\d+)\b/i)?.[1]||'';}});companyId=info[0]?.result;}
    if(!/^\d+$/.test(String(companyId||''))||!/^\d+$/.test(String(hint||'')))return {status:'creation_precondition_failed',missing_fields:[...(!/^\d+$/.test(String(companyId||''))?['company_id']:[]),...(!/^\d+$/.test(String(hint||''))?['variant_id']:[])]};
    stored[sku]={status:'intent_recorded',started_at:new Date().toISOString()};await chrome.storage.local.set({[key]:stored});
    const result=await call('临时复制取包装（不清理）',seller.id,['temporary-package-reader.js'],(sku,company,hint)=>readTemporaryPackaging(sku,company,hint),[sku,companyId,hint]);
    const latest=(await chrome.storage.local.get(key))[key]||{};latest[sku]={...stored[sku],result};await chrome.storage.local.set({[key]:latest});return result;
   }
  };
  const {apiJob:current}=await chrome.storage.local.get('apiJob');
  const target=current.target_count||1,allResults=[],history=new Set((await chrome.storage.local.get('collectionSkuHistory')).collectionSkuHistory||[]),seenCursors=new Set();let cursor=null,passed=0,stopped=null,discovered=0;const candidateBuffer=[];
  while(passed<target){
   await controlGate(id);
   if(current.source_mode!=='manual'&&candidateBuffer.length===0){
    if(cursor&&seenCursors.has(cursor)){stopped='search_pagination_repeated';break;}if(cursor)seenCursors.add(cursor);
    const found=await call('自动搜索候选SKU',buyer.id,['search-candidates.js'],(mode,value,limit,cursor)=>discoverSearchCandidates(mode,value,limit,cursor),[current.source_mode,current.source_value,200,cursor]);
    await saveJob(id,{candidate_discovery:found});
    if(!['search_candidates_read','search_candidates_empty'].includes(found.status)){stopped=found.status;break;}
    candidateBuffer.push(...(found.skus||[]));cursor=found.next_cursor;
   }
   if(current.source_mode!=='manual')seeds=candidateBuffer.splice(0,current.candidate_limit||50);
   const result=await collectApiBatch(seeds,ports,{filters,concurrency:1,history,target:target-passed,onResult:async item=>{
    await queueLocalResult(item);
    history.add(item.sku);allResults.push(item);if(item.status==='api_data_complete')passed++;
    await chrome.storage.local.set({collectionSkuHistory:[...history]});
    await saveJob(id,{qualified_count:passed,result:{results:allResults,processed:allResults.length,discovered,paused:false},target_count:target});
   }});
   discovered+=result.discovered;
   await saveJob(id,{pending_skus:result.unprocessed,pending_source_skus:candidateBuffer,search_cursor:cursor});
   if(result.paused){stopped=result.pause_reason;break;}
   if(passed>=target)break;
   if(current.source_mode==='manual'||(!cursor&&candidateBuffer.length===0)){stopped='candidate_pool_exhausted';break;}
  }
  await flushLocalQueue();
  if(control==='stop')throw new Error('USER_TERMINATED');
  const result={results:allResults,discovered,processed:allResults.length,paused:!!stopped,pause_reason:stopped,target,qualified_count:passed,shortfall:Math.max(0,target-passed)};
  await saveJob(id,{status:stopped?'paused':'completed',stage:stopped?'未达到目标，进度已保存':'达到合格目标',result,reads,operations,qualified_count:passed,finished_at:new Date().toISOString()});
 }catch(e){await saveJob(id,{status:e.message==='USER_TERMINATED'?'terminated':'error',message:String(e.message||e).slice(0,300),finished_at:new Date().toISOString()});}finally{busy=false;}
}
chrome.runtime.onMessage.addListener((m,s,respond)=>{(async()=>{
 if(m.action==='show_1688_attention'){const n=(await chrome.storage.local.get('attention1688V1')).attention1688V1;if(n&&!n.handled)await show1688Attention({...n,force:true});return {status:n&&!n.handled?'shown':'no_pending_issue'};}
 if(m.action==='open_1688_attention_target')return await open1688AttentionTarget(false);
 if(m.action==='open_1688_attention_login')return await open1688AttentionTarget(true);
 if(m.action==='resume_1688_after_attention')return await resume1688AfterAttention();
 if(m.action==='resume_candidate_crawl'){
  if(typeof clear1688Attention==='function')await clear1688Attention();
  const {candidateCrawlV1:state={attempted:{}}}=await chrome.storage.local.get('candidateCrawlV1');state.paused=false;delete state.reason;
  await chrome.storage.local.set({candidateCrawlV1:state});crawlNextCandidate();return {status:'crawl_resumed',message:'候选详情自动抓取已继续；每次串行处理一个商品，遇验证会暂停。'};
 }
 if(m.action==='retry_missing_candidate_crawl'){
  const {candidateCrawlV1:state={attempted:{}}}=await chrome.storage.local.get('candidateCrawlV1');
  for(const [k,v]of Object.entries(state.attempted))if(['sku_images_missing','sync_rejected','detail_read_pending_no_tab'].includes(v.status))delete state.attempted[k];state.paused=false;
  await chrome.storage.local.set({candidateCrawlV1:state});crawlNextCandidate();return {status:'crawl_retry_queued',message:'已重新排队未读到图片的候选；遇验证会停止。'};
 }
 if(m.action==='check_local_vision'){
  const r=await fetch('http://127.0.0.1:8765/api/vision-status',{signal:AbortSignal.timeout(10000)});if(!r.ok)throw new Error('请运行累计更新包中的工作台');
  const d=await r.json();return {status:'vision_status',message:d.provider==='ollama'?(d.automatic_vision_connected?'本机模型API已就绪；真实图片效果与完整SKU匹配尚待验证':'本机模型未就绪，请运行setup-local-vision.bat并重启工作台'):'未配置本地模型，请先运行setup-local-vision.bat'};
 }
 if(m.action==='export_match_review_bundle'){
  await chrome.downloads.download({url:'http://127.0.0.1:8765/api/match-review-export',filename:'supplier-image-spec-review.json',saveAs:true});
  return {status:'exported',message:'已交给浏览器下载精简规格包；共享参数仅导出一次，避免大JSON转码卡顿。'};
 }
 if(m.action==='collect_supplier_variants'){
  const sku=String(m.sku||'').trim();if(!/^\d+$/.test(sku))throw new Error('请输入工作台已有的Ozon SKU');
  const tabs=(await chrome.tabs.query({})).filter(t=>{try{const u=new URL(t.url);return u.hostname==='detail.1688.com'&&/^\/offer\/\d+\.html$/.test(u.pathname)&&t.status==='complete';}catch{return false;}});
  const tab=tabs.find(t=>t.active)||(tabs.length===1?tabs[0]:null);if(!tab)throw new Error('请在当前1688详情页打开插件');
  await chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',files:['1688-sku-variants.js']});
  const result=(await chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',func:()=>collect1688FullSkuInventory()}))[0]?.result;
  if(result?.status!=='supplier_variants_observed')return result;
  const {workbenchKey:key}=await chrome.storage.local.get('workbenchKey');if(!key)throw new Error('请先配对工作台');
  const r=await fetch('http://127.0.0.1:8765/api/supplier-variants',{method:'POST',headers:{'Content-Type':'application/json','X-Pairing-Key':key},signal:AbortSignal.timeout(5000),body:JSON.stringify({ozon_sku:sku,...result,verification_reset:await currentVerificationGeneration(sku)})});const d=await r.json();if(!r.ok)throw new Error(d.error||'同步失败');
  return {status:'variants_synced',message:'已记录 '+d.accepted+' 条规格控件；有图片 '+result.variants.filter(v=>v.images.length).length+' 条、有SKU编号 '+result.variants.filter(v=>v.sku_id).length+' 条。未关联图片或编号的行不用于匹配；可导出诊断继续适配。'};
 }
 if(m.action==='collect_supplier_quote'){
  const sku=String(m.sku||'').trim();if(!/^\d+$/.test(sku))throw new Error('请输入工作台已有的Ozon SKU');
  const tabs=(await chrome.tabs.query({})).filter(t=>{try{const u=new URL(t.url);return u.hostname==='detail.1688.com'&&/^\/offer\/\d+\.html$/.test(u.pathname)&&t.status==='complete';}catch{return false;}});
  const tab=tabs.find(t=>t.active)||(tabs.length===1?tabs[0]:null);if(!tab)throw new Error('请在当前1688详情页打开插件');
  await chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',files:['1688-quote-reader.js']});
  const {workbenchKey:key}=await chrome.storage.local.get('workbenchKey');if(!key)throw new Error('请先配对工作台');
  const tasksResponse=await fetch('http://127.0.0.1:8765/api/tasks',{signal:AbortSignal.timeout(5000)});if(!tasksResponse.ok)throw new Error('无法读取工作台任务');
  const task=(await tasksResponse.json()).jobs?.find(t=>String(t.ozon_sku)===sku);
  const offerId=new URL(tab.url).pathname.match(/\/offer\/(\d+)\.html$/)?.[1];
  const offers=task?.supplier_offers?.filter(o=>String(o.offer_id)===offerId)||[];
  if(offers.length!==1)throw new Error('当前详情页未唯一对应该Ozon SKU的图搜候选');
  const offer=offers[0];
  if(!offer.selected_sku_id||offer.selected_sku_match_verified!==true)throw new Error('尚未完成详情页SKU图片、颜色、结构和图片参数核验，不能直接使用图搜SKU取价');
  const supplierUnits=offer.sales_unit_quantity?.value??1;
  const salesUnits=task.units_per_sales_sku;
  if(!Number.isSafeInteger(salesUnits)||salesUnits<1||!Number.isSafeInteger(supplierUnits)||supplierUnits<1)throw new Error('销售件数无效，停止自动报价');
  const target={sku_id:String(offer.selected_sku_id),purchase_quantity:Math.ceil(salesUnits/supplierUnits)};
  const result=(await chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',func:t=>automaticallyRead1688Quote(t),args:[target]}))[0]?.result;
  if(result?.status!=='supplier_quotes_observed')return result||{status:'empty_result'};
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),5000);
  try{const r=await fetch('http://127.0.0.1:8765/api/supplier-quotes',{method:'POST',headers:{'Content-Type':'application/json','X-Pairing-Key':key},signal:controller.signal,body:JSON.stringify({ozon_sku:sku,...result,verification_reset:await currentVerificationGeneration(sku)})});const data=await r.json();if(!r.ok)throw new Error(data.error||'报价同步失败');return {status:'supplier_quotes_synced',message:'已同步 '+data.accepted+' 条SKU数量报价；匹配数量 '+data.required_purchase_quantity+'；'+(data.matching_quote_count?'存在对应数量报价，仍需图片与规格核验':'尚无对应数量报价')};}finally{clearTimeout(timer);}
 }
 if(m.action==='collect_supplier_package'){
  const sku=String(m.sku||'').trim();if(!/^\d+$/.test(sku))throw new Error('请输入工作台已有的Ozon SKU');
  const tabs=(await chrome.tabs.query({})).filter(t=>{try{const u=new URL(t.url);return u.hostname==='detail.1688.com'&&/^\/offer\/\d+\.html$/.test(u.pathname)&&t.status==='complete';}catch{return false;}});
  const tab=tabs.find(t=>t.active)|| (tabs.length===1?tabs[0]:null);if(!tab)throw new Error('请在当前1688候选详情页打开插件，避免选错供应商');
  await chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',files:['1688-decision-attributes.js','1688-package-reader.js']});
  const result=(await chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',func:()=>readCurrent1688Package()}))[0]?.result;
  if(result?.status!=='supplier_package_observed')return result||{status:'empty_result'};
  const {workbenchKey:key}=await chrome.storage.local.get('workbenchKey');if(!key)throw new Error('请先配对工作台');
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),5000);try{const r=await fetch('http://127.0.0.1:8765/api/supplier-package',{method:'POST',headers:{'Content-Type':'application/json','X-Pairing-Key':key},signal:controller.signal,body:JSON.stringify({ozon_sku:sku,...result,verification_reset:await currentVerificationGeneration(sku)})});const response=await r.json();if(!r.ok)throw new Error(response.error||'同步失败');return {status:'supplier_package_synced',message:result.packaging.applies_to_all_offer_skus?'包装已同步：单行数据适用于该商品全部SKU':result.packaging.rows?.length?'已读取包装表 '+result.packaging.rows.length+' 行，待匹配对应SKU':result.packaging.missing.length?'属性已同步，包装缺失：'+result.packaging.missing.join(', '):'包装字段已同步，仍需确认对应SKU',packaging:result.packaging};}finally{clearTimeout(timer);}
 }
 if(m.action==='export_supplier_diagnostics'){
  const {supplierApiDiagnostics=[],supplierRequestShapes=[],candidateCrawlV1=null,automaticImageSearchV1=null}=await chrome.storage.local.get(['supplierApiDiagnostics','supplierRequestShapes','candidateCrawlV1','automaticImageSearchV1']);
  let automatic_image_search=automaticImageSearchV1?Object.fromEntries(Object.entries(automaticImageSearchV1).filter(([k])=>!['result','identity','resume'].includes(k))):{phase:'not_started'};
  if(automaticImageSearchV1?.tab_id)try{
   const searchTab=await chrome.tabs.get(automaticImageSearchV1.tab_id);const url=new URL(searchTab.url);
   automatic_image_search.tab={id:searchTab.id,status:searchTab.status,active:!!searchTab.active,host:url.hostname,path:url.pathname,has_image_id:url.searchParams.has('imageId')};
   if(/(^|\.)1688\.com$/.test(url.hostname)){
    await chrome.scripting.executeScript({target:{tabId:searchTab.id},world:'MAIN',files:['1688-image-upload.js']});
    automatic_image_search.live_page_probe=(await chrome.scripting.executeScript({target:{tabId:searchTab.id},world:'MAIN',func:()=>inspect1688ImageUpload()}))[0]?.result;
   }
  }catch{automatic_image_search.tab_probe_status='unavailable';}
  let sku_controls={status:'detail_tab_unavailable'},sku_variants=null;
  let vision_performance={status:'workbench_performance_unavailable'};try{const r=await fetch('http://127.0.0.1:8765/api/vision-performance',{signal:AbortSignal.timeout(8000)});if(r.ok)vision_performance=await r.json();}catch{}
  const detailTabs=(await chrome.tabs.query({})).filter(t=>{try{const u=new URL(t.url);return u.hostname==='detail.1688.com'&&/^\/offer\/\d+\.html$/.test(u.pathname)&&t.status==='complete';}catch{return false;}});
  const detail=detailTabs.find(t=>t.id===candidateCrawlV1?.worker_tab_id)||detailTabs.find(t=>t.active)||(detailTabs.length===1?detailTabs[0]:null);
  if(detail){await chrome.scripting.executeScript({target:{tabId:detail.id},world:'MAIN',files:['1688-sku-controls.js','1688-sku-variants.js']});sku_controls=(await chrome.scripting.executeScript({target:{tabId:detail.id},world:'MAIN',func:()=>inspect1688SkuControls()}))[0]?.result;sku_variants=(await chrome.scripting.executeScript({target:{tabId:detail.id},world:'MAIN',func:()=>window.__ozonLastDirectSkuInventory||collect1688FullSkuInventory()}))[0]?.result;}

  await chrome.downloads.download({url:'data:application/json;charset=utf-8,'+encodeURIComponent(JSON.stringify({version:chrome.runtime.getManifest().version,request_metadata_only:true,headers_captured:false,response_bodies_captured:false,requests:supplierApiDiagnostics,request_shapes:supplierRequestShapes,sku_controls,sku_variants,candidate_crawl:candidateCrawlV1,automatic_image_search,vision_performance},null,2)),filename:'1688-detail-request-diagnostics.json',saveAs:true});return {status:'exported'};
 }
 if(m.action==='collect_1688_candidates'){
  const sku=String(m.sku||'').trim();if(!/^\d+$/.test(sku))throw new Error('请输入候选要关联的Ozon SKU');
  const tabs=(await chrome.tabs.query({})).filter(t=>{try{return /(^|\.)1688\.com$/.test(new URL(t.url).hostname);}catch{return false;}});
  const imageTabs=tabs.filter(t=>{try{return /image[_-]?search|pc-image-search/i.test(new URL(t.url).pathname);}catch{return false;}});
  const tab=imageTabs.find(t=>t.status==='complete'&&t.active)||imageTabs.find(t=>t.status==='complete');
  if(!tab)return {status:'image_tab_not_ready',message:!tabs.length?'未识别到1688标签页；请确认扩展已获1688网站访问权限，并在该浏览器的图搜页打开插件。':!imageTabs.length?'已识别到1688页面，但路径不符合已知图搜页；请使用下方连接诊断。':'识别到图搜页，但尚未加载完成或已休眠；切换到图搜页待加载完成后重试。',diagnostics:{site_tabs:tabs.map(t=>{let u;try{u=new URL(t.url);}catch{}return {host:u?.hostname,path:u?.pathname,status:t.status,active:!!t.active};}),image_tabs:imageTabs.length}};
  await chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',files:['1688-image-search.js']});
  const result=(await chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',func:()=>read1688ImageSearch()}))[0]?.result;
  if(result?.status!=='image_candidates_read')return result||{status:'empty_result'};
  const {workbenchKey:key}=await chrome.storage.local.get('workbenchKey');if(!key)throw new Error('请先配对本地工作台');
  const c=new AbortController(),timer=setTimeout(()=>c.abort(),5000);try{const r=await fetch('http://127.0.0.1:8765/api/supplier-candidates',{method:'POST',headers:{'Content-Type':'application/json','X-Pairing-Key':key},signal:c.signal,body:JSON.stringify({ozon_sku:sku,...result,verification_reset:await currentVerificationGeneration(sku)})});if(!r.ok)throw new Error('工作台接收失败 HTTP '+r.status);const accepted=await r.json();crawlNextCandidate();return {status:'candidates_synced',...accepted};}finally{clearTimeout(timer);}
 }
 if(m.action==='pair_workbench'){
  const key=String(m.key||'').trim();if(!/^[A-Za-z0-9_-]{30,100}$/.test(key))throw new Error('请输入工作台显示的配对码');await chrome.storage.local.set({workbenchKey:key});return await flushLocalQueue();
 }
 if(m.action==='sync_workbench')return await flushLocalQueue();
 if(['pause','resume','terminate'].includes(m.action)){
  if(!busy)return {status:'error',message:'当前没有可控制的运行任务；已中断任务不会自动重放'};
  if(m.action==='pause'){control='pause';const j=(await chrome.storage.local.get('apiJob')).apiJob;await saveJob(j.id,{status:'pausing',stage:'等待当前请求完成后暂停'});}
  if(m.action==='resume'){control='run';}
  if(m.action==='terminate'){control='stop';const j=(await chrome.storage.local.get('apiJob')).apiJob;await saveJob(j.id,{status:'terminating',stage:'等待当前请求完成后终止'});}
  return {status:'control_requested'};
 }
 if(m.action==='environment'){
  if(busy)throw new Error('请等待当前验证暂停或结束后检查环境');
  const seeds=String(m.skus||'').split(/[\s,，;；]+/).filter(x=>/^\d+$/.test(x));const {report}=await requestEnvironment(seeds);
  await chrome.storage.local.set({apiEnvironment:report});await chrome.downloads.download({url:'data:application/json;charset=utf-8,'+encodeURIComponent(JSON.stringify({version:chrome.runtime.getManifest().version,request_environment:report},null,2)),filename:'ozon-request-environment.json',saveAs:true});return {status:'environment_exported'};
 }
 if(m.action==='status'||m.action==='status_summary'){
  let j=(await chrome.storage.local.get('apiJob')).apiJob;
  if(j&&!busy&&['running','pausing','terminating'].includes(j.status)){j={...j,status:'interrupted',message:'任务执行进程已结束；进度和账本保留，不能恢复旧任务，可启动新任务'};await chrome.storage.local.set({apiJob:j});}
  if(m.action==='status_summary'){const counts={};for(const item of j?.result?.results||[])counts[item.status]=(counts[item.status]||0)+1;return {...Object.fromEntries(Object.entries(j||{status:'idle'}).filter(([k])=>!['reads','result','request_environment','candidate_discovery','pending_skus'].includes(k))),result:j?.result?{processed:j.result.processed,discovered:j.result.discovered,pause_reason:j.result.pause_reason}:null,summary_counts:counts,runtime_can_control:busy};}
  return {...(j||{status:'idle'}),runtime_can_control:busy};
 }
 if(m.action==='export'){
  const {apiJob}=await chrome.storage.local.get('apiJob');if(!apiJob)throw new Error('尚无诊断');
  const compactJob={...apiJob,reads:(apiJob.reads||[]).map(r=>({...r,result:Object.fromEntries(Object.entries(r.result||{}).filter(([k])=>['status','http_status','diagnostics','price_diagnostics','temporary_bundle_id','identity_verified','cleanup_performed','missing_fields','response_metadata'].includes(k)))}))};
  const report={version:chrome.runtime.getManifest().version,exported_at:new Date().toISOString(),mode:'API_ONLY_LOCAL_VALIDATION',credentials_exported:false,product_creation:true,creation_scope:"temporary_copy_only",cleanup_performed:false,job:compactJob};
  await chrome.downloads.download({url:'data:application/json;charset=utf-8,'+encodeURIComponent(JSON.stringify(report,null,2)),filename:'ozon-api-validation.json',saveAs:true});return {status:'exported'};
 }
 if(m.action==='start'){
  if(busy)throw new Error('已有API验证运行，请等待当前测试结束');
  const seeds=[...new Set(String(m.skus||'').split(/[\s,，;；]+/).filter(Boolean))];if((!m.source_mode||m.source_mode==='manual')&&(!seeds.length||seeds.length>5||seeds.some(s=>!/^\d+$/.test(s))))throw new Error('请输入1至5个纯数字SKU，每行一个');
  const filters=parseFilterSettings(m.filters||{}),concurrency=Number(m.concurrency||1);if(concurrency!==1)throw new Error('临时复制测试仅允许并发1');
  const company=String(m.company||'').trim();if(company&&!/^\d+$/.test(company))throw new Error('Shop编号应为纯数字，不是API Key');
  if(m.source_mode&&!['manual','keyword','category'].includes(m.source_mode))throw new Error('候选来源无效');if(m.source_mode&&m.source_mode!=='manual'&&!String(m.source_value||'').trim())throw new Error('请输入关键词或类目地址');
  const targetCount=Number(m.target_count||1);if(!Number.isInteger(targetCount)||targetCount<1||targetCount>100)throw new Error('测试版合格目标须为1–100');
  const id=crypto.randomUUID();busy=true;control='run';await chrome.storage.local.set({apiJob:{id,target_count:targetCount,qualified_count:0,source_mode:m.source_mode||'manual',source_value:String(m.source_value||'').trim(),candidate_limit:Math.max(1,Math.min(50,Number(m.candidate_limit)||50)),status:'running',started_at:new Date().toISOString(),seeds,filters,concurrency,stage:'准备账号读取',operations:0,reads:[]}});
  runValidation(id,seeds,filters,company,concurrency);return {status:'started'};
 }
 throw new Error('Unsupported action');
})().then(respond,e=>respond({status:'error',message:String(e.message||e)}));return true;});
async function markInterrupted(){busy=false;const {apiJob}=await chrome.storage.local.get('apiJob');if(apiJob?.status==='running')await chrome.storage.local.set({apiJob:{...apiJob,status:'interrupted',message:'浏览器或扩展重启，保留部分诊断；不会自动重放请求'}});}
chrome.runtime.onStartup.addListener(markInterrupted);chrome.runtime.onInstalled.addListener(markInterrupted);

function inspect1688Login(){
 const visible=e=>e.getClientRects().length>0;
 const links=[...document.querySelectorAll('a[href]')].filter(visible);
 const logout=links.some(a=>{try{const u=new URL(a.href);return /(^|\.)1688\.com$/.test(u.hostname)&&/logout|signout/i.test(u.pathname);}catch{return false;}});
 const login=links.some(a=>{try{const u=new URL(a.href);return /(^|\.)1688\.com$/.test(u.hostname)&&/signin|login/i.test(u.pathname)&&/登录|登入|sign in|log in/i.test(a.innerText);}catch{return false;}});
 const form=[...document.querySelectorAll('input[type="password"]')].some(visible);
 // Inspect locally, export only boolean evidence. Never return account/order text.
 const text=(document.body?.innerText||'').slice(0,60000).replace(/\s+/g,'');
 const indicators={buyer_workbench:/买家工作台/.test(text),purchase_navigation:/已买到的货品/.test(text),order_area:/订单动态/.test(text),order_status:/待付款/.test(text)&&/待收货/.test(text)&&/待评价/.test(text)};
 const buyerWorkspace=indicators.buyer_workbench&&indicators.purchase_navigation&&indicators.order_area&&indicators.order_status;
 const confirmed=!form&&(logout||buyerWorkspace);
 return {status:confirmed?'logged_in_page':login||form?'login_required':'unknown',reason:confirmed?(buyerWorkspace?'检测到已登录买家工作台及采购/订单区域；仅在本机检查页面标志，不上传账号订单内容':'检测到可见官方退出入口；不代表API权限'):login||form?'检测到登录入口或登录表单':'未发现足以确认登录的页面标志',evidence_flags:indicators,observed_at:new Date().toISOString()};
}
async function report1688Login(){
 const {workbenchKey:key}=await chrome.storage.local.get('workbenchKey');if(!key)return;
 const tabs=await chrome.tabs.query({url:['https://*.1688.com/*','https://1688.com/*']});
 const previous=(await chrome.storage.local.get('last1688ConfirmedLogin')).last1688ConfirmedLogin;
 let status={status:'unknown',reason:'网站会话尚未确认；无需保持登录页打开',observed_at:new Date().toISOString()};
 if(!tabs.length){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),8000);
  try{const r=await fetch('https://www.1688.com/',{credentials:'include',redirect:'follow',signal:controller.signal});
   const u=new URL(r.url);if(!/(^|\.)1688\.com$/.test(u.hostname)){status.reason='检查发生非1688跳转，未确认会话';}
   else if([401,403,429].includes(r.status)){status.reason='网站会话检查受限 HTTP '+r.status+'；未重试、不判定退出';}
   else if(/signin|login\.htm/i.test(u.pathname)){status.status='login_required';status.reason='正常检查被转到登录页面';}
   else status.reason='1688首页可访问，但公开页面不足以证明账号会话有效；等待已授权身份检查接口';
  }catch{status.reason='网站检查暂时失败，未判定账号退出';}finally{clearTimeout(timer);}
  if(previous)status.reason+='；最近确认已登录：'+previous;
 }

 for(const tab of tabs.filter(t=>t.status==='complete').sort((a,b)=>Number(b.active)-Number(a.active))){try{const r=(await chrome.scripting.executeScript({target:{tabId:tab.id},func:inspect1688Login}))[0]?.result;if(r){status=r;if(r.status==='logged_in_page')break;}}catch{status={...status,status:'unknown',reason:'页面暂不可读取'};}}
 if(tabs.length&&!tabs.some(t=>t.status==='complete'))status={...status,status:'unknown',reason:'1688页面加载中或已休眠'};
 if(status.status==='logged_in_page')await chrome.storage.local.set({last1688ConfirmedLogin:status.observed_at});
 await chrome.storage.local.set({last1688LoginStatus:status});
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),4000);try{await fetch('http://127.0.0.1:8765/api/1688-status',{method:'POST',headers:{'Content-Type':'application/json','X-Pairing-Key':key},body:JSON.stringify(status),signal:controller.signal});}catch{}finally{clearTimeout(timer);}
}
chrome.alarms.create('1688-login-observation',{periodInMinutes:1});
chrome.alarms.onAlarm.addListener(a=>{if(a.name==='1688-login-observation')report1688Login();});
chrome.tabs.onUpdated.addListener((id,info,tab)=>{if(info.status==='complete'&&/^https:\/\/(?:[^/]+\.)?1688\.com\//.test(tab.url||''))report1688Login();});
chrome.tabs.onRemoved.addListener(()=>report1688Login());

// Passive API-name discovery only. Never captures headers, signed URLs or response bodies.
if(chrome.webRequest?.onCompleted)chrome.webRequest.onCompleted.addListener(async event=>{
 try{const u=new URL(event.url);let api=u.searchParams.get('api')||u.pathname.match(/\/(mtop\.[a-z0-9._]+)\//i)?.[1];if(!api||!/^mtop\.[a-z0-9._]{1,180}$/i.test(api))return;
 const list=(await chrome.storage.local.get('supplierApiDiagnostics')).supplierApiDiagnostics||[];
 const item={api,method:event.method,http_status:event.statusCode,observed_at:new Date().toISOString()};
 const next=list.filter(x=>x.api!==api);next.push(item);await chrome.storage.local.set({supplierApiDiagnostics:next.slice(-40)});
 }catch{}
},{urls:['https://*.1688.com/*']});

// Record commercial request shape only, not signed query values or raw payloads.
if(chrome.webRequest?.onBeforeRequest)chrome.webRequest.onBeforeRequest.addListener(async event=>{
 try{
  const u=new URL(event.url),api=u.searchParams.get('api')||u.pathname.match(/\/(mtop\.[a-z0-9._]+)\//i)?.[1];
  if(!api||!/^mtop\.[a-z0-9._]{1,180}$/i.test(api))return;
  let data=u.searchParams.get('data');
  if(!data&&event.requestBody?.formData)data=event.requestBody.formData.data?.[0];
  if(!data&&event.requestBody?.raw?.[0]?.bytes){const raw=new TextDecoder().decode(event.requestBody.raw[0].bytes);data=new URLSearchParams(raw).get('data');}
  let value;try{value=JSON.parse(data||'{}');}catch{return;}
  const mmga=typeof value.mmgaRequest==='string'?JSON.parse(value.mmgaRequest):value.mmgaRequest;
  const service=typeof mmga?.serviceName==='string'&&/^[a-zA-Z0-9_]{1,100}$/.test(mmga.serviceName)?mmga.serviceName:null;
  const summary={api,service,method:event.method,fields:Object.keys(value).filter(k=>!/token|sign|secret|user|member|address|cookie/i.test(k)).slice(0,30),business_fields:mmga?Object.keys(mmga).filter(k=>!/token|sign|secret|user|member|address|cookie/i.test(k)).slice(0,30):[],observed_at:new Date().toISOString()};
  const rows=(await chrome.storage.local.get('supplierRequestShapes')).supplierRequestShapes||[];
  await chrome.storage.local.set({supplierRequestShapes:[...rows.filter(x=>x.api!==api||x.service!==service),summary].slice(-60)});
 }catch{}
},{urls:['https://*.1688.com/*']},['requestBody']);

// Synchronize only already-open candidate detail pages for enabled workbench tasks.
// Does not open tabs, click variants, use image-search cover as a SKU image, or retry challenges.
let detailBridgeBusy=false;
const detailBridgeCache=new Map(),detailBridgeBlocked=new Set();
async function syncOpenCandidateDetails(){
 if(detailBridgeBusy)return;detailBridgeBusy=true;
 try{
  const {workbenchKey:key}=await chrome.storage.local.get('workbenchKey');if(!key)return;
  const get=await fetch('http://127.0.0.1:8765/api/tasks',{signal:AbortSignal.timeout(5000)});if(!get.ok)return;
  const jobs=((await get.json()).jobs||[]).filter(j=>j.automatic_visual_enabled);
  if(!jobs.length)return;
  const crawlState=(await chrome.storage.local.get('candidateCrawlV1')).candidateCrawlV1;
  const tabs=(await chrome.tabs.query({})).filter(t=>t.id!==crawlState?.worker_tab_id&&t.status==='complete'&&/^https:\/\/detail\.1688\.com\/offer\/\d+\.html(?:[?#].*)?$/.test(t.url||''));
  const post=async(path,data)=>{const r=await fetch('http://127.0.0.1:8765'+path,{method:'POST',headers:{'Content-Type':'application/json','X-Pairing-Key':key},signal:AbortSignal.timeout(5000),body:JSON.stringify(data)});if(!r.ok)throw Error('local detail sync failed');};
  for(const j of jobs){
   const matching=tabs.filter(t=>j.supplier_offers?.some(o=>String(o.offer_id)===t.url.match(/\/offer\/(\d+)\.html/)[1]));
   let synced=0,blocked=0;
   for(const tab of matching){
    const blockId=String(tab.id)+'|'+tab.url+'|'+tab.title;
    if(detailBridgeBlocked.has(blockId)){blocked++;continue;}
    if(/验证|验证码|安全检查|登录|captcha|sign.?in/i.test(tab.title||'')){detailBridgeBlocked.add(blockId);blocked++;continue;}
    try{
     await chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',files:['1688-sku-variants.js']});
     const result=(await chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',func:()=>collect1688FullSkuInventory()}))[0]?.result;
     if(result?.status!=='supplier_variants_observed')continue;
     const signature=JSON.stringify(result),cacheId=j.ozon_sku+'|'+result.offer_id;
     if(detailBridgeCache.get(cacheId)!==signature){await post('/api/supplier-variants',{ozon_sku:j.ozon_sku,...result,verification_reset:j.verification_reset});detailBridgeCache.set(cacheId,signature);}
     synced++;
    }catch{blocked++;}
   }
   await post('/api/detail-bridge-status',{ozon_sku:j.ozon_sku,open_candidate_tabs:matching.length,synced_offers:synced,state:blocked?'some_pages_blocked':matching.length?'open_details_synced':'no_open_candidate_details'});
  }
 }catch{}finally{detailBridgeBusy=false;}
}
chrome.alarms.create('1688-detail-workbench-bridge',{periodInMinutes:0.5});
chrome.alarms.onAlarm.addListener(a=>{if(a.name==='1688-detail-workbench-bridge')syncOpenCandidateDetails();});
chrome.tabs.onUpdated.addListener((id,info,tab)=>{if(info.status==='complete'&&/^https:\/\/detail\.1688\.com\/offer\//.test(tab.url||''))syncOpenCandidateDetails();});
syncOpenCandidateDetails();

// Persistent candidate crawl: one background detail page at a time, one attempt per offer.
function classify1688Navigation(tab,offerId){
 const parse=url=>{try{return new URL(url);}catch{return null;}};
 const current=parse(tab.url),pending=parse(tab.pendingUrl);
 const target=u=>u?.hostname==='detail.1688.com'&&u.pathname==='/offer/'+offerId+'.html';
 if(pending&&target(pending)&&!target(current))return 'navigation_pending';
 if(target(current))return 'target';
 if(current&&(/(?:^|\.)(?:login|passport|punish)\./i.test(current.hostname)||/\/(?:login|signin|punish|captcha)(?:[/.]|$)/i.test(current.pathname)))return 'auth_or_verification';
 return tab.status==='loading'||!current?'navigation_pending':'other_page';
}
const SKU_INVENTORY_REVISION='dominant-diagnostics-v5';
let candidateCrawlBusy=false;
async function crawlNextCandidate(burstStarted=Date.now()){
 if(candidateCrawlBusy)return;candidateCrawlBusy=true;
 let ownedTab=null,state={attempted:{},paused:false},key=null,jobs=[],current=null;
 const post=async(path,data)=>{const r=await fetch('http://127.0.0.1:8765'+path,{method:'POST',headers:{'Content-Type':'application/json','X-Pairing-Key':key},signal:AbortSignal.timeout(5000),body:JSON.stringify({...data,verification_reset:jobs.find(j=>j.ozon_sku===data.ozon_sku)?.verification_reset})});if(!r.ok){let body={};try{body=await r.json();}catch{}state.last_http_error={path,status:r.status,error:String(body.error||'unknown').slice(0,180)};const err=Error('workbench_http_'+r.status);err.endpoint=path;throw err;}};
 const save=async()=>{state.updated_at=new Date().toISOString();await chrome.storage.local.set({candidateCrawlV1:state});};
 const report=async()=>{
  if(state.paused&&typeof show1688Attention==='function')await show1688Attention({scope:'detail',reason:state.reason,ozon_sku:state.current_task,offer_id:state.current_offer,source_tab_id:state.current_tab_id,incident_id:state.offer_started_ms});
  if(!key)return;
  for(const job of jobs){
   const records=Object.entries(state.attempted).filter(([k,v])=>k.startsWith(job.ozon_sku+'|')&&v.inventory_revision===SKU_INVENTORY_REVISION).map(([,v])=>v);
   state.crawl_timing=state.crawl_timing||{};const clock=state.crawl_timing[job.ozon_sku]||{};if(records.length>=(job.supplier_offers?.length||Infinity))clock.finished_ms=Math.max(...records.map(v=>Date.parse(v.at)).filter(Number.isFinite));state.crawl_timing[job.ozon_sku]=clock;const totalReadMs=records.reduce((sum,v)=>sum+(v.duration_ms||0),0);
   try{await post('/api/candidate-crawl-progress',{ozon_sku:job.ozon_sku,phase:state.paused?'paused':current?.job.ozon_sku===job.ozon_sku?state.phase:state.phase==='all_candidates_attempted'?'all_candidates_attempted':'waiting_next_candidate',current_offer_id:current?.job.ozon_sku===job.ozon_sku?current.id:state.current_task===job.ozon_sku?state.current_offer:null,crawl_elapsed_ms:clock.started_ms?(clock.finished_ms||Date.now())-clock.started_ms:0,total_read_ms:totalReadMs,average_read_ms:records.length?Math.round(totalReadMs/records.length):0,total:job.supplier_offers?.length||0,attempted:records.length,with_images:records.filter(v=>v.status==='images_discovered_inventory_not_proven').length,missing_images:records.filter(v=>['sku_images_missing','detail_read_pending_no_tab'].includes(v.status)).length,sync_rejected:records.filter(v=>v.status==='sync_rejected').length,last_duration_ms:records.at(-1)?.duration_ms||0,excluded_missing_images:records.filter(v=>v.status==='excluded_missing_sku_images').length,last_http_error:state.last_http_error||null,transport:state.transport||'page',fast_path_status:state.fast_path_status||'',reason:state.reason||null,failed_phase:state.failed_phase||null,extension_version:chrome.runtime?.getManifest?.().version||'0.6.38',updated_at:state.updated_at});}catch(e){state.last_progress_error={code:String(e?.message||'progress_report_failed').slice(0,150),at:new Date().toISOString()};}
  }
 };
 try{
  const saved=await chrome.storage.local.get(['workbenchKey','candidateCrawlV1']);key=saved.workbenchKey;state=saved.candidateCrawlV1||state;state.attempted=state.attempted||{};
  if(!key){state.phase='not_paired';await save();return;}
  const request=await fetch('http://127.0.0.1:8765/api/tasks',{signal:AbortSignal.timeout(5000)});if(!request.ok)throw Error('tasks_http_'+request.status);
  jobs=((await request.json()).jobs||[]).filter(j=>j.automatic_visual_enabled).map(j=>({...j,supplier_offers:(j.supplier_offers||[]).slice(0,30)}));
  if(state.reason==='local_workbench_unavailable'){state.paused=false;delete state.reason;}
  state.reset_commands=state.reset_commands||{};
  for(const job of jobs){if(job.verification_reset&&state.reset_commands[job.ozon_sku]!==job.verification_reset){
   for(const k of Object.keys(state.attempted))if(k.startsWith(job.ozon_sku+'|'))delete state.attempted[k];
   const local=await chrome.storage.local.get(['candidateInventoryPending','automaticImageSearchV1','automaticImageSearchCompletedV1']);
   const updates={};
   if(local.candidateInventoryPending?.ozon_sku===job.ozon_sku)updates.candidateInventoryPending=null;
   if(local.automaticImageSearchV1?.ozon_sku===job.ozon_sku)updates.automaticImageSearchV1={phase:'done',tab_id:local.automaticImageSearchV1.tab_id};
   const completed=local.automaticImageSearchCompletedV1||{};for(const k of Object.keys(completed))if(k.startsWith(job.ozon_sku+'|'))delete completed[k];updates.automaticImageSearchCompletedV1=completed;
   await chrome.storage.local.set(updates);state.reset_commands[job.ozon_sku]=job.verification_reset;state.paused=false;delete state.reason;delete state.last_error;delete state.last_http_error;await save();
  }}
  state.resume_commands=state.resume_commands||{};
  for(const job of jobs){if(job.crawl_resume_request&&state.resume_commands[job.ozon_sku]!==job.crawl_resume_request){state.resume_commands[job.ozon_sku]=job.crawl_resume_request;if(typeof clear1688Attention==='function')await clear1688Attention();state.paused=false;delete state.reason;for(const [k,v]of Object.entries(state.attempted))if(k.startsWith(job.ozon_sku+'|')&&['detail_read_pending_no_tab','sku_images_missing'].includes(v.status))delete state.attempted[k];}}
  if(state.paused){await save();await report();return;}
  if(typeof advanceAutomaticImageSearch==='function'){for(const job of jobs){if(await advanceAutomaticImageSearch(job,key)){const search=(await chrome.storage.local.get('automaticImageSearchV1')).automaticImageSearchV1;state.current_task=job.ozon_sku;state.phase=search?.phase==='failed'?'image_search_paused':'automatic_image_search';state.reason=search?.reason||'';state.current_offer=null;state.current_tab_id=search?.tab_id;await save();await report();setTimeout(()=>crawlNextCandidate(),search?.phase==='failed'?30000:2000);return;}}}
  const pending=(await chrome.storage.local.get('candidateInventoryPending')).candidateInventoryPending;
  if(pending){
   const pendingJob=jobs.find(j=>j.ozon_sku===pending.ozon_sku&&j.supplier_offers.some(o=>String(o.offer_id)===String(pending.offer_id)));
   if(pendingJob){
    current={job:pendingJob,id:String(pending.offer_id)};state.current_task=pending.ozon_sku;state.current_offer=String(pending.offer_id);state.phase='syncing_inventory';await save();
    await post('/api/supplier-variants',pending);
    state.attempted[pending.ozon_sku+'|'+pending.offer_id]={inventory_revision:SKU_INVENTORY_REVISION,status:pending.exclude_missing_sku_images?'excluded_missing_sku_images':pending.variants?.some(v=>v.images?.length)||pending.spec_options?.some(v=>v.images?.length)||pending.shared_image_groups?.length?'images_discovered_inventory_not_proven':'sku_images_missing',transport:'saved_inventory',duration_ms:0,at:new Date().toISOString()};
    await chrome.storage.local.set({candidateInventoryPending:null});state.phase='offer_done';delete state.failed_phase;delete state.last_progress_error;delete state.last_error;delete state.last_http_error;await save();await report();return;
   }
   await chrome.storage.local.set({candidateInventoryPending:null});
  }
  for(const job of jobs){for(const offer of job.supplier_offers||[]){const id=String(offer.offer_id);if(/^\d+$/.test(id)&&(!state.attempted[job.ozon_sku+'|'+id]||state.attempted[job.ozon_sku+'|'+id].inventory_revision!==SKU_INVENTORY_REVISION)){current={job,offer,id};break;}}if(current)break;}
  if(!current){state.phase=jobs.some(j=>j.supplier_offers?.length)?'all_candidates_attempted':jobs.length?'waiting_image_search_candidates':'no_enabled_tasks';
   if(state.phase==='all_candidates_attempted'&&state.worker_tab_id){try{await chrome.tabs.remove(state.worker_tab_id);delete state.worker_tab_id;delete state.current_tab_id;state.worker_tab_closed=true;}catch{state.worker_tab_close_pending=true;}}
   await save();await report();return;}
  const {job,id}=current,cacheKey=job.ozon_sku+'|'+id;state.current_task=job.ozon_sku;state.current_offer=id;state.offer_started_ms=Date.now();state.crawl_timing=state.crawl_timing||{};if(!Object.keys(state.attempted).some(k=>k.startsWith(job.ozon_sku+'|')&&state.attempted[k].inventory_revision===SKU_INVENTORY_REVISION))state.crawl_timing[job.ozon_sku]={started_ms:Date.now()};state.navigation_trace=[];state.navigation_retry_count=0;delete state.page_probe;state.phase='loading_detail';delete state.reason;await save();await report();
  let tab=null;
  if(state.worker_tab_id){try{tab=await chrome.tabs.get(state.worker_tab_id);}catch{delete state.worker_tab_id;}}
  if(!tab){const contexts=await chrome.tabs.query({url:['https://detail.1688.com/offer/*']});tab=contexts.find(t=>t.status==='complete')||null;}
  const targetUrl='https://detail.1688.com/offer/'+id+'.html';
  let result=null;
  if(tab){
   state.current_tab_id=tab.id;state.phase='requesting_sku_data';await save();await report();
   const wait=Math.max(0,250-(Date.now()-(state.sdk_last_started_ms||0)));if(wait)await new Promise(r=>setTimeout(r,wait));state.sdk_last_started_ms=Date.now();
   try{
    const fast=(await chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',func:async offer=>typeof window.__ozonFetchSkuInventory==='function'?await window.__ozonFetchSkuInventory(offer):{status:'sku_fast_path_unavailable',observer_missing:true},args:[id]}))[0]?.result;
    state.fast_path_status=fast?.status||'no_response';
    const latest=(await chrome.storage.local.get('candidateCrawlV1')).candidateCrawlV1;
    if(latest?.paused&&/^site_http_(403|429)$/.test(latest.reason||'')){state=latest;await report();return;}
    if(fast?.status==='sku_fast_path_verification_required'){state.paused=true;state.reason='login_or_verification_required';state.failed_phase='requesting_sku_data';await save();await report();return;}
    if(fast?.status==='supplier_variants_observed'&&String(fast.offer_id)===id&&(fast.spec_options?.length||fast.variants?.some(v=>v.images?.length))){result=fast;state.transport='same_page_sdk';}
    else state.observer_bootstrap_required=!!fast?.observer_missing;
   }catch(e){state.fast_path_status='host_page_sdk_unavailable';state.observer_bootstrap_required=true;}
  }
  if(!result||!result.product_attributes?.length){
   state.phase='fetching_detail_without_tab';state.transport='background_html';delete state.current_tab_id;await save();await report();
   const fetched=await fetch1688DetailWithoutTab(id);state.background_fetch_status=fetched.status;state.response_diagnostics=fetched.response_diagnostics||null;
   if(['detail_fetch_restricted','detail_fetch_verification_required','detail_fetch_login_required'].includes(fetched.status)){
    state.paused=true;state.reason=fetched.http_status?'site_http_'+fetched.http_status:fetched.status==='detail_fetch_login_required'?'site_login_required':'site_verification_required';state.failed_phase=state.phase;await save();await report();return;
   }
   if(fetched.status==='supplier_variants_observed'&&String(fetched.offer_id)===id)result=fetched;
   else if(!result){
    state.attempted[cacheKey]={inventory_revision:SKU_INVENTORY_REVISION,status:'detail_read_pending_no_tab',read_status:fetched.status,response_diagnostics:fetched.response_diagnostics||null,transport:'background_html',duration_ms:Date.now()-state.offer_started_ms,at:new Date().toISOString()};
    state.phase='offer_done';state.reason='detail_data_missing_no_tab_opened';await save();await report();return;
   }else state.transport='same_page_sdk';
  }
  const excludeMissing=result.variants.length>0&&!result.variants.some(v=>v.images?.length)&&!result.spec_options?.length&&!result.shared_image_groups?.length&&!result.scan_limited&&result.observed_sku_map_count===result.variants.length;
  result.exclude_missing_sku_images=excludeMissing;
  state.phase='syncing_inventory';await chrome.storage.local.set({candidateInventoryPending:{ozon_sku:job.ozon_sku,...result}});await save();await report();await post('/api/supplier-variants',{ozon_sku:job.ozon_sku,...result});await chrome.storage.local.set({candidateInventoryPending:null});
  state.attempted[cacheKey]={inventory_revision:SKU_INVENTORY_REVISION,status:excludeMissing?'excluded_missing_sku_images':result.variants.some(v=>v.images.length)||result.spec_options?.some(v=>v.images?.length)||result.shared_image_groups.length?'images_discovered_inventory_not_proven':'sku_images_missing',transport:state.transport||'page',response_diagnostics:result.response_diagnostics||null,duration_ms:Date.now()-state.offer_started_ms,at:new Date().toISOString()};
  state.phase='offer_done';delete state.failed_phase;delete state.last_progress_error;delete state.last_error;delete state.last_http_error;await save();await report();
 }catch(e){
  state.paused=true;state.failed_phase=state.phase||'connecting_workbench';state.reason=/^(?:workbench_http_\d+|tasks_http_\d+|detail_load_timeout|detail_navigation_timeout|detail_url_mismatch|detail_url_unavailable|candidate_inventory_read_failed)$/.test(e?.message||'')?e.message:e?.name==='AbortError'||e?.name==='TimeoutError'?'request_timeout':e instanceof TypeError?'network_or_extension_api_failure':'candidate_read_or_extension_error';
  if(e?.message==='workbench_http_400'&&e.endpoint==='/api/supplier-variants'&&current){
   state.attempted[current.job.ozon_sku+'|'+current.id]={inventory_revision:SKU_INVENTORY_REVISION,status:'sync_rejected',duration_ms:Date.now()-(state.offer_started_ms||Date.now()),at:new Date().toISOString()};state.paused=false;state.phase='offer_sync_rejected';
  }
  if(e?.message==='workbench_http_400'&&e.endpoint==='/api/supplier-variants')await chrome.storage.local.set({candidateInventoryPending:null});
  if((e instanceof TypeError||e?.name==='AbortError'||e?.name==='TimeoutError')&&['syncing_inventory','connecting_workbench'].includes(state.failed_phase)){state.reason='local_workbench_unavailable';}
  state.last_error={name:String(e?.name||'Error'),message:String(e?.message||'unknown').replace(/https?:\/\/[^\s]+/g,'[url omitted]').slice(0,200)};
  await save();try{await report();}catch{}
 }finally{if(ownedTab!==null&&ownedTab!==state.worker_tab_id)try{await chrome.tabs.remove(ownedTab);}catch{}candidateCrawlBusy=false;if(!state.paused&&current&&['offer_done','offer_sync_rejected'].includes(state.phase)&&Date.now()-burstStarted<90000)setTimeout(()=>crawlNextCandidate(burstStarted),state.transport==='same_page_sdk'?0:750);}
}
chrome.alarms.create('1688-auto-candidate-crawl',{periodInMinutes:0.5});
chrome.alarms.onAlarm.addListener(a=>{if(a.name==='1688-auto-candidate-crawl')crawlNextCandidate();});
crawlNextCandidate();

if(chrome.webRequest?.onCompleted)chrome.webRequest.onCompleted.addListener(async event=>{
 if(![403,429].includes(event.statusCode))return;
 const {candidateCrawlV1:s}=await chrome.storage.local.get('candidateCrawlV1');
 if(!s||event.tabId!==s.current_tab_id)return;
 s.paused=true;s.failed_phase=s.phase;s.reason='site_http_'+event.statusCode;s.updated_at=new Date().toISOString();
 await chrome.storage.local.set({candidateCrawlV1:s});if(typeof show1688Attention==='function')await show1688Attention({scope:'detail',reason:s.reason,ozon_sku:s.current_task,offer_id:s.current_offer,source_tab_id:s.current_tab_id,incident_id:s.offer_started_ms});
},{urls:['https://*.1688.com/*'],types:['main_frame','xmlhttprequest']});

// Search worker restrictions are independent from detail worker restrictions.
if(chrome.webRequest?.onCompleted)chrome.webRequest.onCompleted.addListener(async event=>{
 if(![403,429].includes(event.statusCode))return;
 const {automaticImageSearchV1:s}=await chrome.storage.local.get('automaticImageSearchV1');
 if(s&&event.tabId===s.tab_id&&!['done','failed'].includes(s.phase)){s.phase='failed';s.reason='site_http_'+event.statusCode;await chrome.storage.local.set({automaticImageSearchV1:s});if(typeof show1688Attention==='function')await show1688Attention({scope:'search',reason:s.reason,ozon_sku:s.ozon_sku,source_tab_id:s.tab_id,incident_id:s.started_at});}
},{urls:['https://*.1688.com/*']});

async function currentVerificationGeneration(sku){
 const r=await fetch('http://127.0.0.1:8765/api/tasks',{signal:AbortSignal.timeout(5000)});
 if(!r.ok)throw Error('workbench_unavailable');
 return ((await r.json()).jobs||[]).find(j=>j.ozon_sku===sku)?.verification_reset;
}
