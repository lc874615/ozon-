"""Select one evidenced differentiating SKU axis; uncertain cases never exclude."""
import re
from .parameter_prefilter import facts,material,compatible
from .appearance_terms import color
from .attribute_integrity import effective_dimensions,image_reference,effective_capacity

def volume_ml(text):
 m=re.fullmatch(r'\s*(\d+(?:[.,]\d+)?)\s*(ml|мл|毫升|l|л|升)\s*',str(text),re.I)
 return float(m.group(1).replace(',','.'))*(1000 if m.group(2).lower()in ('l','л','升')else 1)if m else None

def classify(name,values):
 n=name.lower()
 if all(volume_ml(v)is not None for v in values):return 'capacity'
 if all(material(v)is not None for v in values):return 'material'
 if re.search(r'颜色|色彩|цвет|color',n):return 'color'
 if re.search(r'尺寸|大小|规格|长度|宽度|高度|深度|размер|высот|ширин|глубин|длин|size',n)and any(re.search(r'\d',v)for v in values):return 'dimensions'
 return 'unknown'

def choose_axis(offer,task):
 variations={}
 for v in offer.get('detail_variants',[]):
  for name,value in (v.get('specs')or{}).items():variations.setdefault(name,set()).add(str(value))
 axes=[{'name':name,'kind':classify(name,values),'values':sorted(values),'value_count':len(values)}for name,values in variations.items()if len(values)>1]
 title=str(task.get('title','')).lower();types=' '.join(str(a.get('value',''))for a in task.get('attributes',[])if a.get('name')in ('Тип','产品类型','产品类别')).lower();purpose=title+' '+types
 priority='capacity'if re.search(r'杯|瓶|壶|罐|桶|круж|бутыл|кувшин|термос|container|bottle',purpose)else'dimensions'if re.search(r'床|桌|地毯|窗帘|матрас|ков[её]р|штор|стол|bed|curtain',purpose)else'color'
 chosen=[a for a in axes if a['kind']==priority]
 if len(chosen)==1:return {**chosen[0],'status':'selected','basis':'product_purpose_primary_axis','other_axes_not_filtered':True}
 recognized=[a for a in axes if a['kind']!='unknown']
 if len(recognized)==1:return {**recognized[0],'status':'selected','basis':'only_recognized_varying_axis','other_axes_not_filtered':True}
 return {'status':'uncertain','kind':None,'name':None,'basis':'multiple_or_no_evidenced_axes','axes':axes,'other_axes_not_filtered':True}

def color_reference(task):
 ref=image_reference(task);out={}
 for a in task.get('attributes',[]):
  name=str(a.get('name','')).strip().lower();value=a.get('value','')
  role='body_color'if name in ('颜色','主体颜色','椅身颜色','цвет','цвет товара','цвет обивки','body color')else'leg_color'if name in ('椅腿颜色','支架颜色','цвет ножек','leg color')else None
  c=color(value)
  if role and c:
   if role in out and out[role]!=c:out[role]=None
   elif role not in out:out[role]=c
 for key in ('body_color','leg_color'):
  if ref.get(key)in ('grey','black','white','pink','blue','green','purple','brown','gold','silver'):out[key]=ref[key]
 return out

def conflict(task,v):
 axis=v.get('prefilter_axis')or{}
 if axis.get('status')!='selected':return None
 name=axis['name'];value=(v.get('specs')or{}).get(name)
 if value is None:return None
 kind=axis['kind']
 if kind=='color':
  body=re.split(r'[-—【\[（(]',str(value),maxsplit=1)[0];legs=re.search(r'([黑金银白灰棕咖])\s*(?:色)?腿',str(value))
  supplied={'body_color':color(body),'leg_color':color(legs.group(1))if legs else None}
  for role,expected in color_reference(task).items():
   actual=supplied.get(role)
   if expected and actual and expected!=actual:return {'field':role,'ozon':expected,'supplier':actual,'reason':'主差异为颜色：'+role+' '+expected+' / '+actual}
 elif kind=='capacity':
  target=effective_capacity(task);actual=volume_ml(value)
  if target and actual and abs(target-actual)/target>.02:return {'field':'capacity_ml','ozon':target,'supplier':actual,'reason':'主差异为容量，明确容量不一致'}
 elif kind=='dimensions':
  reference=effective_dimensions(task);supplier=facts([],v.get('specs',{}))
  for key,expected in reference.items():
   actual=supplier.get(key)
   if actual and abs(expected-actual)/expected>.02:return {'field':key,'ozon':expected,'supplier':actual,'reason':'主差异为产品尺寸，同含义数值差异超过2%'}
 elif kind=='material':
  kinds={material(v)for v in axis.get('values',[])}
  role='frame_material'if kinds and kinds<={'wood','metal','plastic'}else'upholstery_material'if kinds and kinds<={'fabric','velvet','linen','leather','pu','real_leather'}else None
  actual=material(value);reference=facts(task.get('attributes',[])).get(role)if role else None
  if actual and reference and not compatible(actual,reference):return {'field':'upholstery_material','ozon':reference,'supplier':actual,'reason':'主差异为面料，明确材质不一致'}
 return None
