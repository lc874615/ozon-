"""Export shared attribute data once; never construct browser-sized data URLs."""

def compact_offer(offer):
 result=dict(offer);shared=offer.get('detail_attributes')or next((v.get('supplier_attributes')for v in offer.get('detail_variants',[])if v.get('supplier_attributes')),[])
 result['detail_attributes']=shared
 for key in ['detail_variants','detail_spec_options','unbound_detail_images']:
  result[key]=[{k:value for k,value in v.items()if(k!='supplier_attributes'or value!=shared)and(k!='prefilter_axis'or value!=offer.get('dominant_axis'))}for v in offer.get(key,[])]
 return result

def build_review_bundle(tasks):
 safe=[]
 for task in tasks:
  offers=[]
  for o in task.get('supplier_offers',[]):
   c=compact_offer(o)
   offers.append({k:c.get(k)for k in ['offer_id','url','candidate_sku_id','detail_attributes','detail_variants','detail_spec_options','unbound_detail_images','all_variants_verified','excluded_missing_sku_images','source_exclusion_reason','background_read_summary','dominant_axis']})
  safe.append({'ozon_sku':task.get('ozon_sku'),'title':task.get('title'),'ozon_main_image':(task.get('images')or[None])[0],'ozon_images':task.get('images',[]),'ozon_attributes':task.get('attributes',[]),'ozon_sales_units':task.get('units_per_sales_sku'),'image_reference':task.get('image_reference'),'offers':offers})
 return {'schema_version':2,'shared_attributes_location':'offers[].detail_attributes','automatic_visual_matching':False,'jobs':safe}
