"""Only the selected dominant differentiating attribute may reject before AI."""
import hashlib,json
from .appearance_terms import color,COLORS
from .dominant_axis import conflict,color_reference
from .attribute_integrity import issues,image_reference
REVISION='dominant-only-prefilter-v3'

def reference_facts(task):return color_reference(task)
def prefilter_key(task,v):
 return hashlib.sha256(json.dumps([REVISION,task.get('attributes'),image_reference(task),issues(task),v.get('specs'),v.get('prefilter_axis'),v.get('images')],sort_keys=True,ensure_ascii=False).encode()).hexdigest()
def prefilter(task,v):
 reliable=v.get('image_binding_verified')is True or v.get('option_image_binding_verified')is True
 if not reliable or not v.get('images'):return None
 difference=conflict(task,v)
 if difference:return {'status':'prefilter_rejected','prefilter_revision':REVISION,'prefilter_key':prefilter_key(task,v),'reason':difference['reason'],'evidence':{'basis':'selected_dominant_attribute_only','axis':{k:v.get('prefilter_axis',{}).get(k)for k in ('name','kind','basis')},**difference},'profit_allowed':False,'ai_called':False}
 return None
