// One deduplicated extension-owned browser notice. Never solves a site challenge.
let attentionBusy=false;
function needs1688Attention(reason){return /^(site_login_required|site_verification_required|login_or_verification_required|site_http_403|site_http_429|site_rate_limit)$/.test(reason||'');}
async function show1688Attention(info){
 if(!needs1688Attention(info.reason)||attentionBusy)return;
 attentionBusy=true;
 try{
  const signature=[info.scope,info.reason,info.ozon_sku,info.offer_id,info.incident_id].join('|');
  const previous=(await chrome.storage.local.get('attention1688V1')).attention1688V1||{};
  if(previous.signature===signature&&!info.force){if(chrome.action&&!previous.handled)await chrome.action.setBadgeText({text:'!'});return;}
  const notice={signature,incident_id:info.incident_id,reason:info.reason,scope:info.scope||'detail',ozon_sku:String(info.ozon_sku||''),offer_id:/^\d+$/.test(String(info.offer_id))?String(info.offer_id):null,source_tab_id:info.source_tab_id||null,handled:false,created_at:new Date().toISOString(),window_id:previous.window_id};
  await chrome.storage.local.set({attention1688V1:notice});
  if(chrome.action){await chrome.action.setBadgeText({text:'!'});await chrome.action.setBadgeBackgroundColor({color:'#C45416'});}
  try{
   if(notice.window_id){try{const old=await chrome.windows.get(notice.window_id,{populate:true});if(old.type==='popup'&&old.tabs?.some(t=>t.url===chrome.runtime.getURL('attention.html'))){await chrome.windows.update(notice.window_id,{focused:true});return;}}catch{}}
   const win=await chrome.windows.create({url:chrome.runtime.getURL('attention.html'),type:'popup',width:460,height:370,focused:true});
   notice.window_id=win.id;await chrome.storage.local.set({attention1688V1:notice});
  }catch{notice.popup_unavailable=true;await chrome.storage.local.set({attention1688V1:notice});}
 }finally{attentionBusy=false;}
}
async function clear1688Attention(){
 const current=(await chrome.storage.local.get('attention1688V1')).attention1688V1;
 if(current)await chrome.storage.local.set({attention1688V1:{...current,handled:true}});
 if(chrome.action)await chrome.action.setBadgeText({text:''});
}
async function open1688AttentionTarget(login=false){
 const notice=(await chrome.storage.local.get('attention1688V1')).attention1688V1||{};
 if(!login&&notice.source_tab_id)try{const tab=await chrome.tabs.get(notice.source_tab_id);const u=new URL(tab.url);if(/(^|\.)1688\.com$/.test(u.hostname)&&(!notice.offer_id||u.hostname==='detail.1688.com'&&u.pathname==='/offer/'+notice.offer_id+'.html')){await chrome.tabs.update(tab.id,{active:true});if(tab.windowId)await chrome.windows.update(tab.windowId,{focused:true});return {status:'opened'};}}catch{}
 const url=login?'https://login.1688.com/member/signin.htm':notice.offer_id?'https://detail.1688.com/offer/'+notice.offer_id+'.html':'https://www.1688.com/';
 const existing=(await chrome.tabs.query({url}))[0];
 if(existing){await chrome.tabs.update(existing.id,{active:true});if(existing.windowId)await chrome.windows.update(existing.windowId,{focused:true});}
 else await chrome.tabs.create({url,active:true});
 return {status:'opened'};
}
async function resume1688AfterAttention(){
 const saved=await chrome.storage.local.get(['candidateCrawlV1','automaticImageSearchV1','attention1688V1']);
 const state=saved.candidateCrawlV1||{attempted:{}};state.paused=false;delete state.reason;
 const update={candidateCrawlV1:state};
 if(saved.automaticImageSearchV1?.phase==='failed'&&needs1688Attention(saved.automaticImageSearchV1.reason))update.automaticImageSearchV1={...saved.automaticImageSearchV1,resume:'attention-'+Date.now()};
 await chrome.storage.local.set(update);await clear1688Attention();
 const workbench=(await chrome.tabs.query({url:'http://127.0.0.1:8765/*'}))[0];
 if(workbench){await chrome.tabs.update(workbench.id,{active:true});if(workbench.windowId)await chrome.windows.update(workbench.windowId,{focused:true});}
 if(typeof crawlNextCandidate==='function')crawlNextCandidate();
 return {status:'resumed'};
}
