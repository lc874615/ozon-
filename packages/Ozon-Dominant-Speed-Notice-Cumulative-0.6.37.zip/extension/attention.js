const $=id=>document.getElementById(id);
async function render(){const n=(await chrome.storage.local.get('attention1688V1')).attention1688V1;if(!n||n.handled){window.close();return;}
 const rate=['site_http_429','site_rate_limit'].includes(n.reason),denied=n.reason==='site_http_403',login=n.reason==='site_login_required';
 $('title').textContent=rate?'1688请求受到限流':denied?'1688暂时拒绝访问':login?'1688需要登录':'1688需要安全验证';
 $('detail').textContent=rate?'队列已暂停。限流通常需要等待，请稍后再手动继续；登录或拉滑条不保证解除限流。':denied?'队列已暂停。可查看网站是否有登录或验证提示，完成后再继续。':'请在安装本插件的同一浏览器完成本人登录或滑条验证，然后回来继续。程序不会自动代过验证。';
 $('context').textContent='Ozon SKU：'+(n.ozon_sku||'未指定')+(n.offer_id?'；1688商品：'+n.offer_id:'；阶段：图搜');$('resume').textContent=rate?'等待后，手动继续':'我已处理，继续抓取';
}
async function send(action){$('error').textContent='';try{const r=await chrome.runtime.sendMessage({action});if(r?.status==='error')throw Error(r.message);return r;}catch(e){$('error').textContent=e.message;return null;}}
$('process').onclick=()=>send('open_1688_attention_target');$('login').onclick=()=>send('open_1688_attention_login');$('later').onclick=()=>window.close();$('resume').onclick=async()=>{if(await send('resume_1688_after_attention'))window.close();};render();setInterval(render,1000);
