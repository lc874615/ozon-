import re
COLORS={'grey':r'灰|\bgr[ae]y\b|сер(?:ый|ая|ое|ые|ого)', 'black':r'黑|\bblack\b|ч[её]рн', 'white':r'白|\bwhite\b|бел(?:ый|ая|ое|ые|ого)', 'pink':r'粉|\bpink\b|розов', 'blue':r'蓝|\bblue\b|син(?:ий|яя|ее)|голуб', 'green':r'绿|\bgreen\b|зел[её]н', 'purple':r'紫|\bpurple\b|фиолет', 'brown':r'棕|咖|\bbrown\b|коричнев', 'gold':r'金(?!属|丝)|\bgold\b|золот', 'silver':r'银|\bsilver\b|серебр'}
def color(value):
 found={k for k,p in COLORS.items()if re.search(p,str(value),re.I)}
 return next(iter(found))if len(found)==1 else None

