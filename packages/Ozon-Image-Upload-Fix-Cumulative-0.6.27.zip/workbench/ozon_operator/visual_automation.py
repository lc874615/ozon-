"""Resumable visual stage. Review images first; never infer SKU identity from similarity."""
import hashlib,json
from .local_vision import compare_local,MODEL
REVISION='visual-spec-options-original-image-v2'

def review_fingerprint(main_image,images,policy):
 return hashlib.sha256(json.dumps([REVISION,MODEL,main_image,images,policy],sort_keys=True,ensure_ascii=False).encode()).hexdigest()

def visual_batch(task,policy,compare=None,emit=None):
 compare=compare or compare_local
 main=(task.get('images')or[None])[0]
 if not main:return {'status':'blocked','reason':'ozon_main_image_missing','evaluated':0}
 if not task.get('supplier_offers'):return {'status':'blocked','reason':'supplier_candidates_missing','evaluated':0}
 counts={'missing_sku_images':0,'missing_detail_inventory':0,'inventory_incomplete':sum(o.get('all_variants_verified')is not True for o in task.get('supplier_offers',[])),'evaluated':0,'reused':0,'visual_pass':0,'visual_reject':0,'pending':0,'identity_pending':0};events=[];run_cache={}
 for offer in task.get('supplier_offers',[]):
  variants=[('detail_variants',i,v)for i,v in enumerate(offer.get('detail_variants')or[])]+[('detail_spec_options',i,v)for i,v in enumerate(offer.get('detail_spec_options')or[])]+[('unbound_detail_images',i,v)for i,v in enumerate(offer.get('unbound_detail_images')or[])]
  if not variants:counts['pending']+=1;counts['missing_detail_inventory']+=1;continue
  for collection,index,v in variants:
   images=v.get('images')or[]
   if not images:counts['pending']+=1;counts['missing_sku_images']+=1;continue
   fp=review_fingerprint(main,images,policy);old=v.get('automatic_visual_review')or{}
   if old.get('fingerprint')==fp and old.get('assessment',{}).get('status')=='visual_assessment_read':
    result=old['assessment'];counts['reused']+=1;run_cache[fp]=result
   elif fp in run_cache:
    result=run_cache[fp];counts['reused']+=1
   else:
    result=compare(main,images,{},policy);counts['evaluated']+=1
    if result.get('status')=='visual_assessment_read':run_cache[fp]=result
   bound=bool(v.get('sku_id')and v.get('identity_verified')is True and v.get('image_binding_verified')is True)
   visual=result.get('visual',{})
   if result.get('status')!='visual_assessment_read':state='model_or_image_pending';counts['pending']+=1
   elif visual.get('visual_match_allowed')is True:
    counts['visual_pass']+=1
    if bound:state='visual_pass_sku_bound'
    else:state='visual_pass_sku_identity_pending';counts['identity_pending']+=1
   elif any(visual.get(k)=='mismatch'for k in ('structure','local_details','color')):
    state='visual_reject';counts['visual_reject']+=1
   else:state='visual_evidence_pending';counts['pending']+=1
   event={'offer_id':str(offer.get('offer_id')),'variant_index':index,'variant_collection':collection,'sku_id':v.get('sku_id'),'fingerprint':fp,'state':state,'assessment':result,'source_images':{'ozon_main_image':main,'supplier_sku_images':images},'profit_eligible':False}
   events.append(event)
   if emit:emit(event)
   if result.get('status')=='vision_busy':return {'status':'paused','reason':'vision_busy',**counts}
 if counts['evaluated']+counts['reused']==0:return {'status':'waiting_for_detail_images','reason':'no_comparable_detail_images','next_action':'sync_open_candidate_detail_pages',**counts,'profit_eligible':False}
 return {'status':'visual_stage_finished_other_stages_pending',**counts,'profit_eligible':False}

def summarize_spec_visuals(task,policy):
 counts={'named_specs':0,'passed':0,'rejected':0,'unknown':0,'waiting':0,'offers_missing_named_specs':0,'all_specs_read_verified':False}
 for offer in task.get('supplier_offers',[]):
  options=offer.get('detail_spec_options')or[]
  if not options:counts['offers_missing_named_specs']+=1;continue
  for v in options:
   counts['named_specs']+=1
   review=v.get('automatic_visual_review')or{}
   if review.get('fingerprint')!=review_fingerprint((task.get('images')or[None])[0],v.get('images',[]),policy):counts['waiting']+=1;continue
   if review.get('assessment',{}).get('status')!='visual_assessment_read':counts['unknown']+=1;continue
   visual=review['assessment'].get('visual',{})
   if visual.get('visual_match_allowed'):counts['passed']+=1
   elif any(visual.get(k)=='mismatch'for k in ('structure','local_details','color')):counts['rejected']+=1
   else:counts['unknown']+=1
 return counts
