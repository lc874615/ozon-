"""Prevent a partial page observation from replacing stronger exact inventory evidence."""
def partial_inventory_downgrade(previous,incoming,new_rows):
 old_rows=previous.get('detail_variants')or[];summary=previous.get('background_read_summary')or{}
 old_count=summary.get('observed_sku_map_count')
 stronger=summary.get('transport')=='background_html'or(type(old_count)is int and old_count>0 and old_count==len(old_rows))
 count=incoming.get('observed_sku_map_count')
 exact=type(count)is int and count>0 and count==len(new_rows)and incoming.get('scan_limited')is not True
 if not stronger or exact:return False
 old_ids={str(v.get('sku_id'))for v in old_rows if v.get('sku_id')}
 new_ids={str(v.get('sku_id'))for v in new_rows if v.get('sku_id')}
 return len(new_rows)<len(old_rows)or not old_ids.issubset(new_ids)
