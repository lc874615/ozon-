"""Loopback-only Ollama visual inference; no hosted inference fallback."""
import base64,json,urllib.request,urllib.error,threading,time,hashlib
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib.parse import urlsplit
from .image_quality import image_dimensions
from .visual_result_cache import cached_result,save_result
from .vision_matcher import SCHEMA,validated_visual_result,build_payload,calibrate_visual_result
LOCK=threading.Lock()
def load_profile():
 try:config=json.loads((Path(__file__).resolve().parents[1]/'data'/'local-vision.json').read_text(encoding='utf-8-sig'))
 except (OSError,ValueError):config={}
 model=config.get('model','qwen2.5vl:3b')
 if model not in ('qwen2.5vl:3b','qwen3-vl:2b'):model='qwen2.5vl:3b'
 edge=config.get('inference_max_edge',1024)
 if type(edge)is not int or edge not in (0,768,1024,1280):edge=1024
 return model,edge
MODEL,IMAGE_MAX_EDGE=load_profile()
PREPARED_CACHE=OrderedDict()
PREPARED_LOCK=threading.Lock()

def prepare_inference_image(content,max_edge=None):
 edge=IMAGE_MAX_EDGE if max_edge is None else max_edge
 raw=base64.b64decode(content)
 if edge==0:return content,{'max_edge':0,'resized':False,'policy':'original'}
 key=(hashlib.sha256(raw).hexdigest(),edge)
 with PREPARED_LOCK:
  if key in PREPARED_CACHE:PREPARED_CACHE.move_to_end(key);return PREPARED_CACHE[key]
 try:from PIL import Image,ImageOps
 except ImportError:raise ValueError('image_resize_dependency_missing')
 from io import BytesIO
 with Image.open(BytesIO(raw))as source:
  if source.width*source.height>25000000:raise ValueError('image_pixel_limit')
  im=ImageOps.exif_transpose(source)
  original=im.size
  if max(original)<=edge:result=(content,{'max_edge':edge,'resized':False,'width':original[0],'height':original[1]})
  else:
   if im.mode in ('RGBA','LA')or'Transparency'in im.info or'transparency'in im.info:
    rgba=im.convert('RGBA');background=Image.new('RGBA',rgba.size,'white');im=Image.alpha_composite(background,rgba).convert('RGB')
   else:im=im.convert('RGB')
   im.thumbnail((edge,edge),Image.Resampling.LANCZOS)
   output=BytesIO();im.save(output,format='JPEG',quality=90,subsampling=0)
   result=(base64.b64encode(output.getvalue()).decode('ascii'),{'max_edge':edge,'resized':True,'width':im.width,'height':im.height,'original_width':original[0],'original_height':original[1]})
 with PREPARED_LOCK:
  PREPARED_CACHE[key]=result
  while len(PREPARED_CACHE)>64:PREPARED_CACHE.popitem(last=False)
 return result

BASE='http://127.0.0.1:11434'
IMAGE_CACHE=OrderedDict()
IMAGE_CACHE_LOCK=threading.Lock()
IMAGE_CACHE_MAX_BYTES=64*1024*1024
VISUAL_RESULT_CACHE=OrderedDict()
MODEL_ID_CACHE=None

def installed_model_digest():
 global MODEL_ID_CACHE
 if MODEL_ID_CACHE and time.monotonic()-MODEL_ID_CACHE[0]<60:return MODEL_ID_CACHE[1]
 try:
  models=local_json('/api/tags',timeout=5).get('models',[])
  identity=next((m.get('digest')for m in models if m.get('name')==MODEL or m.get('model')==MODEL),None)
 except (OSError,ValueError,TypeError):identity=None
 MODEL_ID_CACHE=(time.monotonic(),identity)
 return identity

def enabled():
 p=Path(__file__).resolve().parents[1]/'data'/'local-vision.json'
 try:return json.loads(p.read_text(encoding='utf-8-sig')).get('provider')=='ollama'
 except (OSError,ValueError):return False

def local_json(path,payload=None,timeout=5):
 request=urllib.request.Request(BASE+path,data=None if payload is None else json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
 with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(request,timeout=timeout)as r:
  raw=r.read(1000001)
  if len(raw)>1000000:raise ValueError('oversize local response')
  return json.loads(raw)

def status():
 result={'provider':'ollama','inference_max_edge':IMAGE_MAX_EDGE,'model':MODEL,'configured':enabled(),'automatic_vision_connected':False,'local_service':True,'credentials_configured':False}
 if not result['configured']:return result
 try:
  models=local_json('/api/tags').get('models',[])
  result['model_available']=any(x.get('name')==MODEL or x.get('model')==MODEL for x in models)
  result['service_reachable']=True
  try:import PIL;resize_ready=True
  except ImportError:resize_ready=IMAGE_MAX_EDGE==0
  result['image_preprocessing_ready']=resize_ready
  result['automatic_vision_connected']=result['model_available']and resize_ready
 except (OSError,ValueError):result['service_reachable']=False
 result['real_product_validation_passed']=False
 return result

def allowed_image(url):
 u=urlsplit(url)
 return u.scheme=='https'and u.port in (None,443)and not u.username and not u.password and any(u.hostname==h or (u.hostname or'').endswith('.'+h)for h in ['alicdn.com','1688.com','ozonstatic.cn','ozonstatic.ru','ozonstatic.com'])

class ImageRedirects(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl):
  if not allowed_image(newurl):raise ValueError('image redirect outside product CDN')
  return super().redirect_request(req,fp,code,msg,headers,newurl)

def read_image(url):
 if not allowed_image(url):raise ValueError('unsupported product image host')
 with IMAGE_CACHE_LOCK:
  cached=IMAGE_CACHE.get(url)
  if cached and time.monotonic()-cached[0]<600:
   IMAGE_CACHE.move_to_end(url);return base64.b64encode(cached[1]).decode('ascii')
 request=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0','Accept':'image/png,image/jpeg,image/webp'})
 with urllib.request.build_opener(ImageRedirects()).open(request,timeout=15)as r:
  if not allowed_image(r.url):raise ValueError('image source changed')
  raw=r.read(12000001)
 if len(raw)>12000000 or not (raw.startswith(b'\xff\xd8\xff')or raw.startswith(b'\x89PNG\r\n\x1a\n')or(raw[:4]==b'RIFF'and raw[8:12]==b'WEBP')):raise ValueError('unsupported or oversized image')
 with IMAGE_CACHE_LOCK:
  IMAGE_CACHE[url]=(time.monotonic(),raw);IMAGE_CACHE.move_to_end(url)
  total=sum(len(v[1])for v in IMAGE_CACHE.values())
  while total>IMAGE_CACHE_MAX_BYTES and IMAGE_CACHE:
   _,(_,removed)=IMAGE_CACHE.popitem(last=False);total-=len(removed)
 return base64.b64encode(raw).decode('ascii')

def read_high_resolution_image(url):
 import re
 parts=urlsplit(url);candidates=[]
 if (parts.hostname or'').endswith('alicdn.com'):
  path=re.sub(r'_sum\.jpg$','',parts.path,flags=re.I)
  path=re.sub(r'(\.(?:jpe?g|png|webp))_\d+x\d+[A-Za-z0-9]*\.(?:jpe?g|png|webp)(?:_\.webp)?$',r'\1',path,flags=re.I)
  if path!=parts.path:candidates.append(parts._replace(path=path).geturl())
 candidates.append(url)
 for candidate in dict.fromkeys(candidates):
  try:
   content=read_image(candidate);size=image_dimensions(base64.b64decode(content))
   if size and min(size)>=600:return content,candidate
  except (OSError,ValueError):continue
 raise ValueError('high_resolution_image_required')

def compare_local(ozon_image,sku_images,attributes,policy,image_reader=None,transport=None,force_inference=False,acquire_lock=True):
 started=time.monotonic();failure_stage='image_loading'
 if acquire_lock and not LOCK.acquire(blocking=False):return {'status':'vision_busy','profit_allowed':False}
 try:
  if not sku_images or not ozon_image:return {'status':'both_source_images_required','profit_allowed':False}
  if len(sku_images)>6:return {'status':'too_many_sku_images_for_one_review','profit_allowed':False}
  loader=(lambda u:(image_reader(u),u))if image_reader else read_high_resolution_image
  started=time.monotonic()
  with ThreadPoolExecutor(max_workers=2)as pool:loaded=list(pool.map(loader,[ozon_image,*sku_images]))
  original_images=[x[0]for x in loaded]
  prepared=[prepare_inference_image(x)for x in original_images]if image_reader is None else[(x,{'policy':'test_injected'})for x in original_images]
  images=[x[0]for x in prepared];inference_profile={'model':MODEL,'max_edge':IMAGE_MAX_EDGE,'images':[x[1]for x in prepared],'original_source_preserved':True}
  resolved_urls=[x[1]for x in loaded];image_load_ms=round((time.monotonic()-started)*1000)
  quality=[{'url':u,'width':(d or(None,None))[0],'height':(d or(None,None))[1]}for content,u in loaded for d in [image_dimensions(base64.b64decode(content))if image_reader is None else None]]
  prompt=build_payload(ozon_image,sku_images,attributes,policy,MODEL)['messages'][0]['content']
  text='\n'.join(x['text']for x in prompt if x['type']=='text')+'\nReturn JSON using schema: '+json.dumps(SCHEMA)
  payload={'model':MODEL,'messages':[{'role':'user','content':text,'images':images}],'format':SCHEMA,'stream':False,'options':{'temperature':0,'num_ctx':8192,'num_predict':2048},'keep_alive':'5m'}
  if MODEL.startswith('qwen3-vl:'):payload['think']=False
  model_digest=installed_model_digest()if image_reader is None and transport is None else None
  digest=hashlib.sha256(json.dumps(['visual-cache-v4-high-resolution',MODEL,model_digest,text,policy,images],sort_keys=True,ensure_ascii=False).encode()).hexdigest()
  cached=VISUAL_RESULT_CACHE.get(digest)
  if not force_inference and cached and time.monotonic()-cached[0]<600:
   VISUAL_RESULT_CACHE.move_to_end(digest)
   return {'status':'visual_assessment_read','provider':'ollama','inference_profile':inference_profile,'model':MODEL,'visual':json.loads(json.dumps(cached[1])),'profit_allowed':False,'visual_scope':['appearance_structure','visible_local_details','color'],'dimension_verification':'outside_visual_scope','selected_sku_identity_verification':'separate_required','image_count':len(images),'resolved_image_urls':resolved_urls,'image_quality':quality,'image_quality_min_short_edge':600,'hosted_inference_used':False,'inference_cache_hit':True,'elapsed_ms':round((time.monotonic()-started)*1000)}
  if model_digest and not force_inference:
   persisted=cached_result(digest)
   if persisted:
    try:visual=calibrate_visual_result(validated_visual_result(persisted),attributes)
    except (ValueError,TypeError,KeyError):visual=None
    if visual:
     VISUAL_RESULT_CACHE[digest]=(time.monotonic(),visual)
     return {'status':'visual_assessment_read','provider':'ollama','inference_profile':inference_profile,'model':MODEL,'visual':visual,'profit_allowed':False,'selected_sku_identity_verification':'separate_required','image_count':len(images),'resolved_image_urls':resolved_urls,'image_quality':quality,'image_quality_min_short_edge':600,'hosted_inference_used':False,'inference_cache_hit':True,'cache_scope':'persistent_exact_image_and_model','elapsed_ms':round((time.monotonic()-started)*1000)}
  failure_stage='model_request'
  request_started=time.monotonic()
  response=(transport or (lambda p:local_json('/api/chat',p,timeout=180)))(payload)
  request_ms=round((time.monotonic()-request_started)*1000)
  failure_stage='result_validation'
  if response.get('done')is not True:raise ValueError('incomplete inference')
  visual=calibrate_visual_result(validated_visual_result(json.loads(response['message']['content'])),attributes)
  if model_digest:save_result(digest,visual)
  VISUAL_RESULT_CACHE[digest]=(time.monotonic(),json.loads(json.dumps(visual)))
  while len(VISUAL_RESULT_CACHE)>256:VISUAL_RESULT_CACHE.popitem(last=False)
  return {'status':'visual_assessment_read','provider':'ollama','inference_profile':inference_profile,'model':MODEL,'visual':visual,'profit_allowed':False,'visual_scope':['appearance_structure','visible_local_details','color'],'dimension_verification':'outside_visual_scope','selected_sku_identity_verification':'separate_required','image_count':len(images),'resolved_image_urls':resolved_urls,'image_quality':quality,'image_quality_min_short_edge':600,'thumbnail_fallbacks':[u for u in resolved_urls if '_sum.jpg'in u],'timing':{'image_load_ms':image_load_ms,'request_ms':request_ms,'model_load_ms':round(response.get('load_duration',0)/1000000),'prompt_eval_ms':round(response.get('prompt_eval_duration',0)/1000000),'decode_ms':round(response.get('eval_duration',0)/1000000),'prompt_tokens':response.get('prompt_eval_count',0),'output_tokens':response.get('eval_count',0)},'hosted_inference_used':False,'elapsed_ms':round((time.monotonic()-started)*1000)}
 except (OSError,ValueError,TypeError,KeyError,IndexError)as error:return {'model':MODEL,'elapsed_ms':round((time.monotonic()-started)*1000),'failure_stage':failure_stage,'error_type':type(error).__name__,'status':'local_vision_image_or_inference_failed','failure_reason':'image_resize_dependency_missing'if 'image_resize_dependency_missing'in str(error)else'high_resolution_image_required'if 'high_resolution_image_required'in str(error)else'image_or_model_error','profit_allowed':False}
 finally:
  if acquire_lock:LOCK.release()
