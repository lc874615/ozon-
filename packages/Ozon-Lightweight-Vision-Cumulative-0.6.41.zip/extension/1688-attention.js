// One deduplicated extension-owned browser notice. Never solves a site challenge.
let attentionBusy=false,verificationTimer=null;
function schedule1688Verification(){if(typeof setTimeout!=='function')return;if(verificationTimer&&typeof clearTimeout==='function')clearTimeout(verificationTimer);verificationTimer=setTimeout(()=>{verificationTimer=null;monitor1688Verification().catch(()=>{});},5000);}
function needs1688Attention(reason){return /^(site_login_required|site_verification_required|login_or_verification_required|site_http_403|site_http_429|site_rate_limit)$/.test(reason||'');}
async function show1688Attention(info){
 if(!needs1688Attention(info.reason)||attentionBusy)return;
 attentionBusy=true;
 try{
  const signature=[info.scope,info.reason,info.ozon_sku,info.offer_id,info.incident_id].join('|');
  const previous=(await chrome.storage.local.get('attention1688V1')).attention1688V1||{};
  if(previous.signature===signature&&!info.force){if(chrome.action&&!previous.handled)await chrome.action.setBadgeText({text:'!'});return;}
  if(info.force&&previous.signature===signature&&!previous.handled&&previous.verification_tab_id)try{const tab=await chrome.tabs.get(previous.verification_tab_id);await chrome.tabs.update(tab.id,{active:true});if(tab.windowId)await chrome.windows.update(tab.windowId,{focused:true});return;}catch{}
  const notice={signature,incident_id:info.incident_id,reason:info.reason,scope:info.scope||'detail',ozon_sku:String(info.ozon_sku||''),offer_id:/^\d+$/.test(String(info.offer_id))?String(info.offer_id):null,source_tab_id:info.source_tab_id||null,handled:false,created_at:new Date().toISOString(),window_id:previous.window_id};
  await chrome.storage.local.set({attention1688V1:notice});
  if(!['site_http_429','site_rate_limit'].includes(info.reason)){await openAutomatic1688Verification(notice);return;}
  if(chrome.action){await chrome.action.setBadgeText({text:'!'});await chrome.action.setBadgeBackgroundColor({color:'#C45416'});}
  try{
   if(notice.window_id){try{const old=await chrome.windows.get(notice.window_id,{populate:true});if(old.type==='popup'&&old.tabs?.some(t=>t.url===chrome.runtime.getURL('attention.html'))){await chrome.windows.update(notice.window_id,{focused:true});return;}}catch{}}
   const win=await chrome.windows.create({url:chrome.runtime.getURL('attention.html'),type:'popup',width:460,height:370,focused:true});
   notice.window_id=win.id;await chrome.storage.local.set({attention1688V1:notice});
  }catch{notice.popup_unavailable=true;await chrome.storage.local.set({attention1688V1:notice});}
 }finally{attentionBusy=false;}
}
async function clear1688Attention(){
 const current=(await chrome.storage.local.get('attention1688V1')).attention1688V1;
 if(current)await closeOwned1688Verification(current);
 if(current)await chrome.storage.local.set({attention1688V1:{...current,handled:true}});
 if(chrome.action)await chrome.action.setBadgeText({text:''});
}
async function open1688AttentionTarget(login=false){
 const notice=(await chrome.storage.local.get('attention1688V1')).attention1688V1||{};
 if(!login&&notice.source_tab_id)try{const tab=await chrome.tabs.get(notice.source_tab_id);const u=new URL(tab.url);if(/(^|\.)1688\.com$/.test(u.hostname)&&(!notice.offer_id||u.hostname==='detail.1688.com'&&u.pathname==='/offer/'+notice.offer_id+'.html')){await chrome.tabs.update(tab.id,{active:true});if(tab.windowId)await chrome.windows.update(tab.windowId,{focused:true});return {status:'opened'};}}catch{}
 const url=login?'https://login.1688.com/member/signin.htm':notice.offer_id?'https://detail.1688.com/offer/'+notice.offer_id+'.html':'https://www.1688.com/';
 const existing=(await chrome.tabs.query({url}))[0];
 if(existing){await chrome.tabs.update(existing.id,{active:true});if(existing.windowId)await chrome.windows.update(existing.windowId,{focused:true});}
 else await chrome.tabs.create({url,active:true});
 return {status:'opened'};
}
async function resume1688AfterAttention(){
 const saved=await chrome.storage.local.get(['candidateCrawlV1','automaticImageSearchV1','attention1688V1']);
 const state=saved.candidateCrawlV1||{attempted:{}};state.paused=false;delete state.reason;
 const update={candidateCrawlV1:state};
 if(saved.automaticImageSearchV1?.phase==='failed'&&needs1688Attention(saved.automaticImageSearchV1.reason))update.automaticImageSearchV1={...saved.automaticImageSearchV1,resume:'attention-'+Date.now()};
 await chrome.storage.local.set(update);await clear1688Attention();
 const workbench=(await chrome.tabs.query({url:'http://127.0.0.1:8765/*'}))[0];
 if(workbench){await chrome.tabs.update(workbench.id,{active:true});if(workbench.windowId)await chrome.windows.update(workbench.windowId,{focused:true});}
 if(typeof crawlNextCandidate==='function')crawlNextCandidate();
 return {status:'resumed'};
}

// Observe only normal page readiness after the user handles the site challenge.
let verificationMonitorBusy=false;
async function openAutomatic1688Verification(notice){
 const state=(await chrome.storage.local.get('candidateCrawlV1')).candidateCrawlV1||{attempted:{}};
 state.paused=true;state.reason=notice.reason;await chrome.storage.local.set({candidateCrawlV1:state});
 let url=notice.offer_id?'https://detail.1688.com/offer/'+notice.offer_id+'.html':'https://www.1688.com/';
 if(!notice.offer_id&&notice.source_tab_id)try{const t=await chrome.tabs.get(notice.source_tab_id),u=new URL(t.url);if(u.protocol==='https:'&&/(^|\.)1688\.com$/.test(u.hostname))url=u.href;}catch{}
 try{
  const tab=await chrome.tabs.create({url,active:true});
  const latest=(await chrome.storage.local.get('attention1688V1')).attention1688V1;
  if(latest?.signature!==notice.signature){return;}
  await chrome.storage.local.set({attention1688V1:{...latest,verification_tab_id:tab.id,verification_owned:true,auto_resume:true,verification_status:'waiting_for_user'}});
  if(tab.windowId)await chrome.windows.update(tab.windowId,{focused:true});
  schedule1688Verification();
 }catch{await chrome.storage.local.set({attention1688V1:{...notice,popup_unavailable:true}});}
}
async function closeOwned1688Verification(notice){
 if(!notice.verification_owned||!notice.verification_tab_id)return;
 try{const tab=await chrome.tabs.get(notice.verification_tab_id),u=new URL(tab.url);if(u.protocol==='https:'&&/(^|\.)1688\.com$/.test(u.hostname))await chrome.tabs.remove(tab.id);}catch{}
}
function inspect1688VerificationCompletion(){
 const visible=e=>!!e&&!!(e.offsetWidth||e.offsetHeight||e.getClientRects().length);
 const text=(document.body?.innerText||'').slice(0,50000);
 const challenge=[...document.querySelectorAll('#nc_1_wrapper,.nc-container,#baxia-dialog,iframe[src*="captcha"],iframe[src*="punish"]')].some(visible)||/请拖动|拖动滑块|请完成验证|安全验证|访问受限/.test(text);
 const login=/login\.1688\.com/.test(location.hostname)||[...document.querySelectorAll('input[type="password"]')].some(visible);
 const product=!challenge&&!login&&/商品属性|包装信息/.test(text)&&/立即下单|加入采购车|起批/.test(text);
 const search=!challenge&&!login&&/以图搜款|图片搜索/.test(text)&&!!document.querySelector('input[type="file"]');
 return {challenge,login,product,search,ready:document.readyState==='complete'};
}
async function monitor1688Verification(){
 if(verificationMonitorBusy)return;verificationMonitorBusy=true;
 let again=false;
 try{
  const n=(await chrome.storage.local.get('attention1688V1')).attention1688V1;
  if(!n||n.handled||!n.auto_resume||!n.verification_tab_id)return;
  const tab=await chrome.tabs.get(n.verification_tab_id),u=new URL(tab.url);
  if(u.protocol!=='https:'||!/(^|\.)1688\.com$/.test(u.hostname))return;
  again=true;
  if(tab.status!=='complete')return;
  const result=(await chrome.scripting.executeScript({target:{tabId:tab.id},func:inspect1688VerificationCompletion}))[0]?.result;
  if(!result?.ready||result.challenge||result.login)return;
  if(n.offer_id){
   if(!result.product||Date.now()-(n.last_probe_ms||0)<30000)return;
   await chrome.storage.local.set({attention1688V1:{...n,last_probe_ms:Date.now()}});
   const data=await fetch1688DetailWithoutTab(n.offer_id);
   if(data.status!=='supplier_variants_observed'||String(data.offer_id)!==n.offer_id)return;
  }else if(!result.search)return;
  // Recheck incident identity so an old completion cannot resume a new pause.
  const latest=(await chrome.storage.local.get('attention1688V1')).attention1688V1;
  if(latest?.signature!==n.signature||latest.handled)return;
  await chrome.storage.local.set({attention1688V1:{...latest,verification_status:'completed_normal_data_ready'}});
  await resume1688AfterAttention();again=false;
 }catch{}finally{verificationMonitorBusy=false;if(again)schedule1688Verification();}
}
