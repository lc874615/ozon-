// Run in the existing 1688 image-search page MAIN world using its normal SDK.
async function read1688ImageSearch(observedImageId=null){
 if(!/(^|\.)1688\.com$/.test(location.hostname))return {status:'invalid_context'};
 const query=new URL(location.href).searchParams;const imageId=observedImageId||query.get('imageId');
 if(!imageId)return {status:'image_context_missing',reason:'当前页面网址没有imageId，不能猜测上传参数'};
 const sdk=window.lib?.mtop;
 if(typeof sdk?.request!=='function')return {status:'normal_page_sdk_unavailable'};
 const failure=(error,status='image_request_failed')=>{
  const raw=Array.isArray(error?.ret)?error.ret:[];
  const codes=raw.map(x=>String(x).split('::')[0]).filter(x=>/^[A-Z0-9_]{1,100}$/.test(x)).slice(0,8);
  const cause=codes.some(x=>/TOKEN|SESSION|LOGIN/.test(x))?'会话或登录校验失败':codes.some(x=>/LIMIT|TRAFFIC|FREQUENCY/.test(x))?'请求频率或访问限制':codes.some(x=>/SIGN|APPKEY|PARAM|API|DATA/.test(x))?'接口参数或签名环境不匹配':'尚未分类的SDK失败';
  const attention_reason=codes.some(v=>/LIMIT|FLOOD|TRAFFIC|FREQUENCY/.test(v))?'site_rate_limit':codes.some(v=>/TOKEN|SESSION|LOGIN/.test(v))?'site_login_required':codes.some(v=>/VALIDATE|CAPTCHA|ILLEGAL_ACCESS|RGV/.test(v))?'site_verification_required':null;
  return {status,attention_reason,reason:cause+'；未自动重试',diagnostics:{sdk_error_codes:codes,error_kind:error?.message==='timeout'?'timeout':raw.length?'sdk_rejection':'exception',request_method:'GET',response_type:'jsonp',api:'mtop.relationrecommend.wirelessrecommend.recommend',method:'imageOfferSearchService'}};
 };
 let timer;
 try{
  const payload=await Promise.race([sdk.request({api:'mtop.relationrecommend.wirelessrecommend.recommend',v:'2.0',type:'GET',dataType:'jsonp',timeout:15000,data:{appId:32517,params:JSON.stringify({beginPage:1,pageSize:30,method:'imageOfferSearchService',searchScene:'pcImageSearch',appName:'pctusou',tab:'imageSearch',imageId})}}),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('timeout')),16000)})]);
  const ret=payload?.ret||[];if(ret.length&&!ret.some(v=>String(v).startsWith('SUCCESS')))return failure(payload,'image_request_rejected');
  const offers=new Map();
  const add=d=>{if(!d||typeof d!=='object')return;const id=String(d.offerId||'');if(!/^\d+$/.test(id)||offers.has(id)||offers.size>=30)return;offers.set(id,{offer_id:id,title:d.title||d.subject||'',image:d.offerPicUrl||d.odPicUrl||'',url:'https://detail.1688.com/offer/'+id+'.html',candidate_sku_id:String(d.skuId||''),search_moq_labels:(d.afterPriceList||[]).filter(a=>a.matKey==='quantity_begin').map(a=>a.text),free_shipping_tag_observed:(d.tags||[]).some(a=>a.text==='包邮'),cost_verified:false,discovery_method:'1688_image_search',match_verified:false});};
  const explicit=payload?.data?.data?.OFFER?.items||payload?.data?.result;
  if(Array.isArray(explicit))for(const row of explicit)add(row.data||row);
  const walk=(x,depth=0)=>{if(!x||typeof x!=='object'||depth>20)return;
   if(x.cellType==='image_search_offer'&&x.data)add(x.data);
   for(const v of Object.values(x).slice(0,300))if(v&&typeof v==='object')walk(v,depth+1);
  };walk(payload);
  return {status:'image_candidates_read',offers:[...offers.values()],candidate_limit:30,selection_order:'search_response_order',image_binding_verified:false,pagination_complete:false};
 }catch(error){return failure(error);}finally{clearTimeout(timer);}
}
// Normal site's SDK handles its own session; no cookie extraction or signed URL replay.
async function convert1688ImageToId(base64){
 if(!/(^|\.)1688\.com$/.test(location.hostname))return {status:'invalid_context'};
 const sdk=window.lib?.mtop;if(typeof sdk?.request!=='function')return {status:'sdk_upload_unavailable'};
 let timer;
 try{
  const reply=await Promise.race([sdk.request({api:'mtop.relationrecommend.WirelessRecommend.recommend',v:'2.0',type:'POST',dataType:'json',timeout:15000,data:{appId:32517,params:JSON.stringify({searchScene:'imageEx',interfaceName:'imageBase64ToImageId','serviceParam.extendParam[imageBase64]':base64,subChannel:'pc_image_search_image_id'})}}),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('sdk_upload_timeout')),16000)})]);
  const codes=(reply?.ret||[]).map(v=>String(v).split('::')[0]);
  if(codes.some(v=>/TOKEN|SESSION|LOGIN|VALIDATE|CAPTCHA|ILLEGAL_ACCESS|RGV|LIMIT|FLOOD/.test(v))||reply?.rgv587_flag)return {status:'sdk_upload_verification_required'};
  if(!codes.some(v=>v==='SUCCESS'))return {status:'sdk_upload_not_supported'};
  const id=String(reply?.data?.imageId||'');return /^\d{5,30}$/.test(id)?{status:'sdk_image_id_ready',image_id:id}:{status:'sdk_upload_no_image_id'};
 }catch(e){
  if((e?.ret||[]).some(v=>/TOKEN|SESSION|LOGIN|VALIDATE|CAPTCHA|ILLEGAL_ACCESS|RGV|LIMIT|FLOOD/.test(String(v))))return {status:'sdk_upload_verification_required'};
  return {status:'sdk_upload_failed'};
 }finally{clearTimeout(timer);}
}
