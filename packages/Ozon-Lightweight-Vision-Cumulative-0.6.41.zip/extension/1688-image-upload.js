function find1688ImageUploadInputs(){
 const compatible=e=>!e.disabled&&(/image\//i.test(e.accept)||/\.(?:jpe?g|png|bmp|webp)(?:\s*,|\s*$)/i.test(e.accept));
 // Current public search header uses this exact site-owned file input.
 const header=[...document.querySelectorAll('.search-image-upload-container input[type="file"]')].filter(compatible);
 if(header.length===1)return header;
 const identified=[...document.querySelectorAll('input#img-search-upload[type="file"]')].filter(compatible);
 if(identified.length===1)return identified;
 return [...document.querySelectorAll('input[type="file"]')].filter(compatible);
}
// Only operate the site's own image upload control. No undocumented upload API.
function inspect1688ImageUpload(){
 const visible=e=>e&&e.getClientRects().length&&getComputedStyle(e).visibility!=='hidden';
 const auth=/登录|安全验证|验证码|captcha|sign.?in/i.test(document.title||'')||[...document.querySelectorAll('iframe[src*="captcha"],iframe[src*="punish"],#baxia-dialog-content,.nc-container')].some(visible);
 if(auth)return {status:'login_or_verification_required'};
 const imageId=new URL(location.href).searchParams.get('imageId');
 return {status:'ready',image_id:imageId||null,file_inputs:find1688ImageUploadInputs().length,file_controls:[...document.querySelectorAll('input[type="file"]')].slice(0,10).map(e=>({id:e.id,accept:e.accept,disabled:!!e.disabled,multiple:!!e.multiple})),upload_buttons:document.querySelectorAll('.image-upload-button-camera,.image-upload-button-container').length,search_confirm_buttons:[...document.querySelectorAll('.search-image-upload-container .copy-image-container .search-btn')].slice(0,4).map(e=>({text:(e.innerText||e.textContent||'').trim().slice(0,40),disabled:!!e.disabled})),ready:document.readyState!=='loading'};
}
function prepare1688ImageUpload(){
 const state=inspect1688ImageUpload();if(state.status!=='ready')return state;
 const files=find1688ImageUploadInputs();
 if(files.length===1)return {status:'upload_control_ready'};
 if(files.length>1)return {status:'upload_control_ambiguous'};
 const candidates=[...document.querySelectorAll('[class*="image-search"],[class*="imageSearch"],[class*="camera"],[class*="Camera"],[title],[aria-label]')].filter(e=>e.getClientRects().length&&(/以图搜|图片搜索|以图找|拍照搜/.test((e.getAttribute('title')||'')+' '+(e.getAttribute('aria-label')||''))||/camera/i.test(e.className||'')));
 if(candidates.length===1){candidates[0].click();return {status:'opening_upload_control'};}
 return {status:'upload_control_not_found'};
}
function submit1688SearchImage(payload){
 const state=inspect1688ImageUpload();if(state.status!=='ready')return state;
 const inputs=find1688ImageUploadInputs();
 if(inputs.length!==1)return {status:inputs.length?'upload_control_ambiguous':'upload_control_not_found'};
 const bytes=Uint8Array.from(atob(payload.base64),c=>c.charCodeAt(0));
 const file=new File([bytes],payload.name,{type:payload.type});const transfer=new DataTransfer();transfer.items.add(file);
 inputs[0].files=transfer.files;inputs[0].dispatchEvent(new Event('input',{bubbles:true}));inputs[0].dispatchEvent(new Event('change',{bubbles:true}));
 return {status:'image_submitted',bytes:bytes.length};
}
function confirm1688UploadedImageSearch(submission){
 const state=inspect1688ImageUpload();if(state.status!=='ready')return state;
 if(state.image_id)return {status:'search_already_started'};
 if(window.__ozonImageSearchConfirmedSubmission===submission)return {status:'search_confirmation_already_sent'};
 const buttons=[...document.querySelectorAll('.search-image-upload-container .copy-image-container .search-btn')];
 const candidates=buttons.filter(e=>!e.disabled&&e.getAttribute('aria-disabled')!=='true'&&/^(搜索图片|搜尋圖片|Search image|Search by image)$/i.test((e.innerText||e.textContent||'').trim()));
 if(candidates.length>1)return {status:'search_confirmation_ambiguous'};
 if(!candidates.length)return {status:'waiting_upload_preview',preview_count:buttons.length};
 // This button is a site-owned search action inside the uploaded-image preview.
 window.__ozonImageSearchConfirmedSubmission=submission;
 candidates[0].click();return {status:'search_confirmation_clicked'};
}
