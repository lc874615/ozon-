/* document_start, MAIN world: observe only the page's ordinary SKU-selector response.
   No request replay, signed URLs, account identifiers or raw response persistence. */
(()=>{
 if(window.__ozonSkuObserverVersion===2)return;window.__ozonSkuSelectorObserverInstalled=true;window.__ozonSkuObserverVersion=2;window.__ozonSkuObserverStats={installed:true,requests:0,responses:0,template_ready:false};
 const pageOffer=()=>location.hostname==='detail.1688.com'&&location.pathname.match(/^\/offer\/(\d+)\.html$/)?.[1];
 const target=url=>{try{const u=new URL(url,location.href);return /\/mtop\.1688\.wosc\.queryofferskuselectormodel\//i.test(u.pathname)||String(u.searchParams.get('api')||'').toLowerCase()==='mtop.1688.wosc.queryofferskuselectormodel';}catch{return false;}};
 const safeImage=u=>{if(typeof u!=='string'||!u)return null;try{const x=new URL(u,location.href);return x.protocol==='https:'&&/(^|\.)(alicdn\.com|1688\.com)$/.test(x.hostname)?x.href:null;}catch{return null;}};
 const sanitize=(response,offer,direct=false)=>{
  if(!offer||!direct&&offer!==pageOffer())return;
  if(!Array.isArray(response.ret)||!response.ret.some(x=>String(x).startsWith('SUCCESS'))){window.__ozonSkuSelectorInventory={status:'selector_response_not_successful',offer_id:offer};return;}
  const explicitOffer=response.data?.offerId??response.data?.model?.offerId??response.data?.data?.offerId;if(explicitOffer!=null&&String(explicitOffer)!==String(offer))return;
  const variants=[],properties=[],shapes=[],seen=new WeakSet();let nodes=0,limited=false;
  const walk=(o,path,depth)=>{
   if(!o||typeof o!=='object'||seen.has(o))return;if(depth>20||++nodes>25000){limited=true;return;}seen.add(o);
   if(/sku|spec|prop|model/i.test(path)){
    const images=[...new Set(['skuImageUrl','skuImgUrl','skuPicUrl','imageUrl','picUrl','image','imgUrl'].map(k=>safeImage(o[k])).filter(Boolean))];
    const labels=['skuName','specName','name','value','valueName','label'].map(k=>typeof o[k]==='string'?o[k].trim():'').filter(v=>v&&v.length<250);
    const sku=String(o.skuId||o.skuID||'');
    const propertyValues=['specAttrs','skuAttrs','skuPropIds','propPath','specPath'].map(k=>({name:k,value:typeof o[k]==='string'?o[k].slice(0,1000):null})).filter(x=>x.value);
    if(/^\d+$/.test(sku))variants.push({sku_id:sku,labels,images,specification_text:labels.join(' / '),property_paths:propertyValues,identity_verified:true,image_binding_verified:images.length>0,image_binding_source:images.length?'normal_page_sku_selector_record':null,extraction_status:images.length?'selector_sku_image':'selector_sku_image_missing'});
    else if(images.length)properties.push({labels,images,property_value_id:String(o.valueId||o.vid||o.propValueId||'').slice(0,100),binding_verified:false,source:'normal_page_selector_property'});
    if(shapes.length<100)shapes.push({path:path.slice(0,200),keys:Object.keys(o).filter(k=>!/user|buyer|seller|account|token|sign|secret|session|address|cookie|trace/i.test(k)).slice(0,40)});
   }
   for(const [k,v]of Object.entries(o))if(!/user|buyer|seller|member|account|token|sign|secret|session|address|cookie|trace|order|rating|review/i.test(k)&&v&&typeof v==='object')walk(v,path+'.'+k,depth+1);
  };
  walk(response.data,'selector_model',0);
  const unique=new Map();for(const v of variants){const old=unique.get(v.sku_id);if(!old||v.images.length>old.images.length)unique.set(v.sku_id,v);}
  const inventory={status:'selector_inventory_observed',offer_id:offer,variants:[...unique.values()].slice(0,2000),property_images:properties.slice(0,2000),schema_shapes:shapes,scan_limited:limited||unique.size>2000,all_variants_verified:false,observed_at:new Date().toISOString()};
  if(offer===pageOffer())window.__ozonSkuSelectorInventory=inventory;
  return inventory;
 };
 const requestInfo=(url,body)=>{
  try{
   const u=new URL(url,location.href);let raw=u.searchParams.get('data');
   if(body instanceof ArrayBuffer||ArrayBuffer.isView(body))body=new TextDecoder().decode(body);
   if(!raw&&typeof body==='string'){raw=new URLSearchParams(body).get('data');if(!raw&&body.trim().startsWith('{'))raw=body;}
   if(!raw&&body instanceof URLSearchParams)raw=body.get('data');if(!raw&&body instanceof FormData)raw=body.get('data');
   const data=JSON.parse(raw||'{}');const offer=/^\d+$/.test(String(data.offerId))?String(data.offerId):null;
   const version=u.searchParams.get('v')||u.pathname.match(/\/(\d+(?:\.\d+)*)\/?$/)?.[1];
   return {offer,data,version};
  }catch{return {};}
 };
 const templateFrom=info=>{
  if(!info.offer||!/^\d+(?:\.\d+)*$/.test(info.version||''))return null;
  const d=info.data;
  if(!Object.hasOwn(d,'useCase')||!Object.hasOwn(d,'bizScene')||!Object.hasOwn(d,'urlParam'))return null;
  if(!['string','number'].includes(typeof d.useCase)||!['string','number'].includes(typeof d.bizScene))return null;
  if(!/^[A-Za-z0-9_.-]{0,100}$/.test(String(d.useCase))||!/^[A-Za-z0-9_.-]{0,100}$/.test(String(d.bizScene)))return null;
  const allowed=new Set(['offerId','offerid','source','scene','pageScene','pageName','pageId','skuId','spm','bizScene','useCase']);
  const valid=obj=>obj&&typeof obj==='object'&&!Array.isArray(obj)&&Object.entries(obj).every(([k,v])=>allowed.has(k)&&['string','number','boolean'].includes(typeof v)&&String(v).length<=300&&!/[?&](?:[^=&]*token|sign|secret|session|cookie)=/i.test(String(v))&&!(k==='skuId'&&String(v)!==''&&String(v)!=='0'));
  let urlParam=d.urlParam;
  if(typeof urlParam==='string'&&urlParam!==''){
   try{if(!valid(JSON.parse(urlParam)))return null;}catch{return null;}
  }else if(urlParam!==''&&!valid(urlParam))return null;
  return {version:info.version,data:{offerId:info.offer,useCase:d.useCase,bizScene:d.bizScene,urlParam}};
 };
 const observe=(response,info)=>{
  if(!info.offer)return;window.__ozonSkuObserverStats.responses++;window.__ozonSkuObserverStats.business_field_types=Object.fromEntries(['offerId','useCase','bizScene','urlParam'].map(k=>[k,typeof info.data?.[k]]));let urlKeys=[];try{const value=typeof info.data?.urlParam==='string'?JSON.parse(info.data.urlParam):info.data?.urlParam;if(value&&typeof value==='object')urlKeys=Object.keys(value).filter(k=>/^[a-zA-Z0-9_]{1,80}$/.test(k)).slice(0,40);}catch{}window.__ozonSkuObserverStats.url_param_keys=urlKeys;
  const inventory=sanitize(response,info.offer);
  if(inventory){const template=templateFrom(info);window.__ozonSkuObserverStats.template_ready=!!template;if(template)window.__ozonSkuBusinessTemplate=template;else window.__ozonSkuObserverStats.template_block_reason='necessary_business_fields_not_verified';}
 };
 window.__ozonFetchSkuInventory=async offer=>{
  if(!/^\d+$/.test(String(offer)))return {status:'invalid_offer'};
  const template=window.__ozonSkuBusinessTemplate;
  if(!template||typeof window.lib?.mtop?.request!=='function')return {status:'sku_fast_path_unavailable'};
  if(!template.coverage_validated){
   const dom=typeof window.collect1688FullSkuInventory==='function'?window.collect1688FullSkuInventory():null;
   const observed=window.__ozonSkuSelectorInventory;
   const baseline=dom?.spec_options||[];
   const records=[...(observed?.property_images||[]),...(observed?.variants||[])];
   const label=s=>String(s).replace(/\s+/g,'').split('').filter(c=>!'-—【】[]()（）'.includes(c)).join('');
   const image=s=>{try{return new URL(s).pathname.replace(/_sum\.jpg$/i,'');}catch{return '';}};
   const covered=baseline.length>0&&baseline.every(o=>records.some(r=>(r.labels||[]).some(n=>(o.labels||[]).some(x=>label(n)===label(x)))&&(r.images||[]).some(u=>(o.images||[]).some(v=>image(u)===image(v)))));
   window.__ozonSkuObserverStats.coverage_validated=covered;
   if(!covered)return {status:'sku_fast_path_coverage_unverified'};
   template.coverage_validated=true;
  }

  const data=JSON.parse(JSON.stringify(template.data));data.offerId=String(offer);
  if(data.urlParam!==''){
   const wasString=typeof data.urlParam==='string',params=wasString?JSON.parse(data.urlParam):data.urlParam;
   for(const key of ['offerId','offerid'])if(Object.hasOwn(params,key))params[key]=String(offer);
   data.urlParam=wasString?JSON.stringify(params):params;
  }
  let timer;try{
   const started=performance.now();
   const response=await Promise.race([window.lib.mtop.request({api:'mtop.1688.wosc.queryOfferSkuSelectorModel',v:template.version,type:'POST',dataType:'json',timeout:12000,data}),new Promise((_,reject)=>timer=setTimeout(()=>reject(Error('timeout')),13000))]);
   const codes=(response.ret||[]).map(x=>String(x).split('::')[0]);
   if(codes.some(x=>/TOKEN|SESSION|LOGIN|VALIDATE|CAPTCHA|ILLEGAL_ACCESS|RGV587|FLOOD|LIMIT/.test(x)))return {status:'sku_fast_path_verification_required',codes};
   const inventory=sanitize(response,String(offer),true);
   if(!inventory)return {status:'sku_fast_path_response_unverified'};
   const options=[...inventory.property_images,...inventory.variants].filter(v=>v.labels?.length&&v.images?.length).map(v=>({...v,sku_id:v.sku_id||null,option_key:v.labels.join(' / ')+'|'+v.images[0]+'|'+(v.sku_id||''),specification_text:v.labels.join(' / '),option_image_binding_verified:true,image_binding_verified:v.image_binding_verified===true,identity_verified:v.identity_verified===true,source:'normal_selector_property_record',extraction_status:'selector_named_spec_option'}));
   const result={...inventory,status:'supplier_variants_observed',spec_options:options,shared_image_groups:inventory.property_images,control_diagnostics:[],network_inventory_status:'same_page_sdk_observed_template',completeness:'selector_response_inventory_not_proven',transport:'same_page_sdk',fetch_elapsed_ms:Math.round(performance.now()-started)};
   window.__ozonLastDirectSkuInventory=result;return result;
  }catch{return {status:'sku_fast_path_request_failed'};}finally{clearTimeout(timer);}
 };
 const originalOpen=XMLHttpRequest.prototype.open,originalSend=XMLHttpRequest.prototype.send,meta=new WeakMap();
 XMLHttpRequest.prototype.open=function(method,url,...rest){meta.delete(this);if(target(url))meta.set(this,String(url));return originalOpen.call(this,method,url,...rest);};
 XMLHttpRequest.prototype.send=function(body){const url=meta.get(this);if(url){const info=requestInfo(url,body);if(info.offer)window.__ozonSkuObserverStats.requests++;if(info.offer)this.addEventListener('load',()=>{try{observe(this.responseType==='json'?this.response:JSON.parse(this.responseText),info);}catch{}},{once:true});}return originalSend.call(this,body);};
 const originalFetch=window.fetch;
 if(typeof originalFetch==='function')window.fetch=async function(input,init){
  const url=typeof input==='string'||input instanceof URL?String(input):input?.url;
  let infoPromise=null;
  if(target(url)){
   if(init?.body!==undefined)infoPromise=Promise.resolve(requestInfo(url,init.body));
   else if(typeof input?.clone==='function')infoPromise=input.clone().text().then(body=>requestInfo(url,body)).catch(()=>({}));
   else infoPromise=Promise.resolve(requestInfo(url,null));
  }
  const response=await originalFetch.apply(this,arguments);
  if(infoPromise){try{const clone=response.clone();infoPromise.then(info=>clone.json().then(r=>observe(r,info))).catch(()=>{});}catch{}}
  return response;
 };
})();
