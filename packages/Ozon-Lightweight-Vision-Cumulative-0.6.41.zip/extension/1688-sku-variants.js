function supplierContentsQuantity(name,unitText=''){
 const text=String(name)+' '+String(unitText),found=[];
 for(const m of text.matchAll(/(?:^|[^\d.])(\d+)\s*(?:件|个|把|只|张|支|条|枚|双|对)(?:\s*(?:装|套装|组合|\/套|每套))?/g)){
  const n=Number(m[1]);if(Number.isSafeInteger(n)&&n>0)found.push(n);
 }
 const distinct=[...new Set(found)];
 return distinct.length>1?{value:null,basis:'conflicting_explicit_quantities'}:distinct.length?{value:distinct[0],basis:'sku_name_or_unit_explicit'}:{value:1,basis:'user_default_one'};
}
function collect1688SkuVariants(){
 const offer=location.hostname==='detail.1688.com'&&location.pathname.match(/^\/offer\/(\d+)\.html$/)?.[1];
 if(!offer)return {status:'detail_page_required'};
 const safeImage=u=>{if(typeof u!=='string'||!u.trim())return null;try{const x=new URL(u,location.href);return x.protocol==='https:'&&/(^|\.)(alicdn\.com|1688\.com)$/.test(x.hostname)?x.href:null;}catch{return null;}};
 const rows=[],diagnostics=[],sharedImageGroups=[],specOptions=[];const seen=new Set();
 const selector='input.ant-input-number-input,input[role="spinbutton"]';
 const inputs=[...document.querySelectorAll(selector)].filter(e=>e.getClientRects().length);
 const imagesOf=node=>{
  const values=[...node.querySelectorAll('img')].flatMap(i=>[i.getAttribute('data-original'),i.getAttribute('data-origin'),i.getAttribute('data-large'),i.getAttribute('data-big'),i.currentSrc,i.getAttribute('src'),i.getAttribute('data-src'),i.getAttribute('data-lazy-src'),(i.getAttribute('srcset')||'').split(',')[0]?.trim().split(/\s+/)[0]]);
  for(const e of [node,...node.querySelectorAll('[style],[class*="image"],[class*="pic"],[class*="thumb"]')].slice(0,400)){
   let css=e.style?.backgroundImage||'';if(!css&&typeof getComputedStyle==='function')css=getComputedStyle(e).backgroundImage||'';
   for(const match of css.matchAll(/url\(["']?([^"')]+)["']?\)/g))values.push(match[1]);
  }
  return [...new Set(values.map(safeImage).filter(Boolean))];
 };
 const meaningful=t=>/[\u4e00-\u9fffA-Za-zА-Яа-я]/.test(t)&&!/^(?:库存|数量|起批|件|个|把|￥|¥|元|价格|单价|可售|剩余|\d|\s|[.,:+-])+$/.test(t);
 for(const input of inputs){
  let row=null,p=input.parentElement,group=null;const path=[];
  for(let depth=0;p&&depth<16;depth++,p=p.parentElement){
   if(p===document.body||p===document.documentElement)break;
   const controls=p.querySelectorAll(selector).length;
   const text=(p.innerText||'').trim();
   path.push({tag:p.tagName?.toLowerCase(),classes:typeof p.className==='string'?p.className.slice(0,250):'',quantity_controls:controls,image_count:p.querySelectorAll('img').length,text_length:text.length});
   if(controls>1){group=p;break;}
   if(controls===1&&text.length<=1500&&meaningful(text)&&!/ant-input-number(?:-|$)/.test(p.className||''))row=p;
  }
  // Preserve every control even when its surrounding labels/images are absent.
  const origin=row||input.parentElement;
  diagnostics.push({control_index:inputs.indexOf(input),row_found:!!row,path});
  if(seen.has(origin))continue;seen.add(origin);
  const ids=new Set();
  for(const e of [origin,...origin.querySelectorAll('[data-sku-id],[data-skuid],[data-sku]')])for(const a of ['data-sku-id','data-skuid','data-sku']){const v=e.getAttribute(a);if(/^\d+$/.test(v||''))ids.add(v);}
  const sku=ids.size===1?[...ids][0]:null;
  const labelNodes=[...origin.querySelectorAll('[title],img[alt],[class*="sku-name"],[class*="spec-name"],[class*="item-name"],[class*="prop-name"]')];
  const labels=[...new Set(labelNodes.map(e=>e.getAttribute('title')||e.getAttribute('alt')||e.innerText||'').map(s=>s.trim()).filter(s=>s&&s.length<=200&&meaningful(s)))];
  const images=imagesOf(origin);
  if(group){
   let scope=group;
   for(let depth=0;scope&&depth<7;depth++,scope=scope.parentElement){
    if(scope===document.body||scope===document.documentElement)break;
    const text=(scope.innerText||'');if(text.length>12000)break;
    // A larger SKU/ordering scope can contain shared color thumbnails outside
    // the quantity list. Never label these thumbnails as a particular SKU.
    if(depth===0||/sku|spec|prop|sale|order|trade/i.test(scope.className||'')){
     const urls=imagesOf(scope);
     if(urls.length){
      sharedImageGroups.push({control_indices:inputs.map((e,i)=>scope.contains(e)?i:-1).filter(i=>i>=0),images:urls,binding_verified:false,source:'outer_sku_region'});
      for(const img of scope.querySelectorAll('img')){
       let cell=null,parent=img.parentElement;
       for(let n=0;parent&&parent!==scope&&n<6;n++,parent=parent.parentElement){
        const text=(parent.innerText||parent.getAttribute('title')||'').trim();
        if(parent.querySelectorAll('img').length!==1||parent.querySelectorAll(selector).length)break;
        if(text&&text.length<=180&&meaningful(text)&&!/库存|起批|包邮|运费|销量/.test(text))cell=parent;
       }
       if(!cell)continue;
       const label=(cell.innerText||cell.getAttribute('title')||'').trim();const images=imagesOf(cell);if(!images.length)continue;
       const valueId=['data-value-id','data-vid','data-prop-value-id'].map(k=>cell.getAttribute(k)).find(Boolean)||null;
       specOptions.push({sku_id:null,option_key:label+'|'+images[0],labels:[label],specification_text:label,images,property_value_id:valueId,option_image_binding_verified:true,image_binding_verified:false,identity_verified:false,source:'dom_same_spec_option_cell',extraction_status:'named_option_image_sku_combination_pending'});
      }
      break;
     }
    }
   }
  }
  rows.push({sku_id:sku,control_index:inputs.indexOf(input),labels,specification_text:row?(row.innerText||'').trim().slice(0,1000):'',images,image_binding_verified:!!sku&&images.length>0,image_binding_source:sku&&images.length?'dom_explicit_sku_row':null,identity_conflict:ids.size>1,quantity_basis:'sku_name_or_explicit_unit_only_default_one',identity_verified:!!sku,match_verified:false,extraction_status:!row?'quantity_control_only':!images.length?'specification_read_image_binding_missing':!sku?'image_and_spec_read_sku_id_missing':'variant_observed_needs_visual_verification'});
 }
 return {status:'supplier_variants_observed',offer_id:offer,variants:rows,shared_image_groups:sharedImageGroups,spec_options:[...new Map(specOptions.map(o=>[o.option_key,o])).values()],control_diagnostics:diagnostics,quantity_control_count:inputs.length,all_variants_verified:false,completeness:'rendered_rows_only_hidden_or_unloaded_variants_not_verified',profit_eligible:false};
}

// Read inert product JSON only. Never eval scripts or export page state/account fields.
function collect1688StructuredSkuInventory(){
 const allowedImage=u=>{try{const x=new URL(u,location.href);return typeof u==='string'&&u&&x.protocol==='https:'&&/(^|\.)(alicdn\.com|1688\.com)$/.test(x.hostname)?x.href:null;}catch{return null;}};
 const roots=[];
 for(const el of document.querySelectorAll('script[type="application/json"],script#__NEXT_DATA__')){
  if((el.textContent||'').length>8000000)continue;
  try{roots.push(JSON.parse(el.textContent));}catch{}
 }
 // Known initial-data containers are read in MAIN world when available.
 for(const key of ['__INIT_DATA__','__INITIAL_STATE__','__NEXT_DATA__']){try{const value=window[key];if(value&&typeof value==='object')roots.push(value);}catch{}}
 for(const el of [...document.querySelectorAll('input.ant-input-number-input,input[role="spinbutton"],[class*="sku-selector"],[class*="sku-content"]')].slice(0,120)){
  const fiberKey=Object.keys(el).find(k=>k.startsWith('__reactFiber$'));
  let fiber=fiberKey?el[fiberKey]:null;
  for(let n=0;fiber&&n<10;n++,fiber=fiber.return){
   const props=fiber.memoizedProps;
   if(props&&typeof props==='object'&&(Object.keys(props).some(k=>/sku|spec/i.test(k))||/sku|spec|prop/i.test(String(props.className||''))))roots.push({skuComponentProps:props});
  }
 }
 const variants=[],unbound=[],seen=new WeakSet();let visited=0,limited=false;
 const imagesOf=x=>[...new Set(['skuImageUrl','skuImgUrl','skuPicUrl','imageUrl','picUrl','image'].map(k=>allowedImage(x[k])).filter(Boolean))];
 const walk=(x,depth,context='')=>{
  if(!x||typeof x!=='object'||seen.has(x))return;if(depth>18||++visited>25000){limited=true;return;}seen.add(x);
  if(/sku|spec|prop/i.test(context)){
   const sku=String(x.skuId||x.skuID||''),images=imagesOf(x);
   const labels=['skuName','specName','name','value'].map(k=>typeof x[k]==='string'?x[k].trim():'').filter(s=>s&&s.length<250);
   if(/^\d+$/.test(sku))variants.push({sku_id:sku,labels,images,specification_text:labels.join(' / '),identity_verified:true,image_binding_verified:images.length>0,image_binding_source:images.length?'structured_explicit_sku_record':null,extraction_status:images.length?'structured_sku_image':'structured_sku_image_missing'});
   else if(images.length)unbound.push({images,labels,binding_verified:false,source:'structured_spec_property_image'});
  }
  // Skip account, token, tracking, review/order and address branches entirely.
  for(const [k,v]of Object.entries(x))if(!/user|buyer|seller|member|cookie|token|secret|session|sign|tracking|trace|order|address|review|rating/i.test(k)){
   if(v&&typeof v==='object')walk(v,depth+1,/sku|spec|prop/i.test(k)?k:context);
  }
 };
 for(const root of roots)walk(root,0);
 const unique=new Map();for(const v of variants){const old=unique.get(v.sku_id);if(!old||v.images.length>old.images.length)unique.set(v.sku_id,v);}
 return {variants:[...unique.values()].slice(0,300),shared_image_groups:unbound.slice(0,300),structured_roots:roots.length,scan_limited:limited||unique.size>300,all_variants_verified:false};
}
function collect1688FullSkuInventory(){
 const title=document.title||'';
 if(/验证码|安全验证|安全检查|captcha|请登录|登录1688/i.test(title))return {status:'supplier_page_requires_verification'};
 const dom=collect1688SkuVariants();if(dom.status!=='supplier_variants_observed')return dom;
 const structured=collect1688StructuredSkuInventory();
 const observed=window.__ozonSkuSelectorInventory;const network=observed?.offer_id===dom.offer_id&&observed.status==='selector_inventory_observed'?observed:null;
 const combined=[...(network?.variants||[]),...structured.variants];const uniqueSku=new Map();for(const v of combined){const old=uniqueSku.get(v.sku_id);if(!old||v.images.length>old.images.length)uniqueSku.set(v.sku_id,v);}const rows=[...uniqueSku.values()];
 for(const v of dom.variants){const existing=v.sku_id&&rows.find(x=>x.sku_id===v.sku_id);if(existing){if(!existing.images.length&&v.images.length)Object.assign(existing,v);}else rows.push(v);}
 return {...dom,variants:rows.slice(0,300),shared_image_groups:[...dom.shared_image_groups,...structured.shared_image_groups,...(network?.property_images||[])].slice(0,2000),network_observer_stats:window.__ozonSkuObserverStats||null,network_inventory_status:observed?.status||'not_observed',network_schema_shapes:network?.schema_shapes||[],structured_roots:structured.structured_roots,scan_limited:structured.scan_limited||rows.length>300,all_variants_verified:false,completeness:'all_discovered_dom_and_structured_rows_total_inventory_not_proven'};
}
