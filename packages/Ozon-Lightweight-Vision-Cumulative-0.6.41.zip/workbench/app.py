import json,secrets,sqlite3,webbrowser,threading,hashlib
from datetime import datetime,timezone
from ozon_operator.match_policy import DEFAULT_POLICY,validate_policy,current_policy
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from ozon_operator.collection_handoff import build_source_queue
from ozon_operator.source_triage import triage_task
from ozon_operator.quote_intake import merge_quotes
from ozon_operator.supplier_variants import normalize_variants,preserve_visual_reviews,normalize_inventory_rows
from ozon_operator.vision_matcher import configuration_status,compare_sku_images
from ozon_operator.local_vision import enabled as local_vision_enabled,status as local_vision_status,compare_local
from ozon_operator.visual_automation import visual_batch,review_fingerprint
from ozon_operator.performance_diagnostics import performance_report
from ozon_operator.image_reference import audit_main_image
from ozon_operator.attribute_integrity import issues as attribute_issues
from ozon_operator.review_export import compact_offer,build_review_bundle
ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data';DATA.mkdir(exist_ok=True)
KEY=DATA/'pairing-key.txt'
if not KEY.exists():KEY.write_text(secrets.token_urlsafe(32),encoding='utf-8')
TOKEN=KEY.read_text(encoding='utf-8').strip()
def db():
 c=sqlite3.connect(DATA/'tasks.sqlite3');c.execute('CREATE TABLE IF NOT EXISTS tasks(sku TEXT PRIMARY KEY, payload TEXT NOT NULL)');return c
AUTO_LOCK=threading.Lock()
AUTO_PENDING=set()
TASK_VIEW_CACHE={'key':None,'rows':None}
TASK_VIEW_LOCK=threading.Lock()
def task_views(rows):
 policy=current_policy()
 key=hashlib.sha256(json.dumps([rows,policy],sort_keys=True,ensure_ascii=False).encode()).hexdigest()
 with TASK_VIEW_LOCK:
  if TASK_VIEW_CACHE['key']!=key:TASK_VIEW_CACHE.update(key=key,rows=[triage_task(json.loads(row[0]))for row in rows])
  return key,TASK_VIEW_CACHE['rows']
def start_visual_job(sku):
 with db()as c:gate=c.execute('SELECT payload FROM tasks WHERE sku=?',(sku,)).fetchone()
 if not gate or not json.loads(gate[0]).get('visual_run_requested'):return False
 if not AUTO_LOCK.acquire(blocking=False):AUTO_PENDING.add(sku);return False
 def run():
  try:
   with db()as c:
    row=c.execute('SELECT payload FROM tasks WHERE sku=?',(sku,)).fetchone()
    if not row:return
    task=json.loads(row[0]);generation=task.get('verification_reset');task['automatic_visual_stage']={'status':'running','profit_eligible':False};c.execute('UPDATE tasks SET payload=? WHERE sku=?',(json.dumps(task,ensure_ascii=False),sku))
   if not local_vision_status().get('automatic_vision_connected'):
    with db()as c:
     row=c.execute('SELECT payload FROM tasks WHERE sku=?',(sku,)).fetchone();latest=json.loads(row[0]);
     if latest.get('verification_reset')!=generation:return
     latest['automatic_visual_stage']={'status':'paused_local_model_not_ready','profit_eligible':False};c.execute('UPDATE tasks SET payload=? WHERE sku=?',(json.dumps(latest,ensure_ascii=False),sku))
    return
   policy=current_policy()
   def emit(event):
    with db()as c:
     row=c.execute('SELECT payload FROM tasks WHERE sku=?',(sku,)).fetchone();latest=json.loads(row[0])
     if latest.get('verification_reset')!=generation:raise RuntimeError('verification_reset')
     for o in latest.get('supplier_offers',[]):
      if str(o.get('offer_id'))!=event['offer_id']:continue
      variants=o.get(event.get('variant_collection','detail_variants'),[]);index=event['variant_index']
      if index>=len(variants):continue
      v=variants[index]
      if review_fingerprint((latest.get('images')or[None])[0],v.get('images')or[],current_policy())!=event['fingerprint']:continue
      if v.get('sku_id')!=event['sku_id']:continue
      v['automatic_visual_review']=event
     latest['automatic_visual_stage']={'status':'running','last_state':event['state'],'progress':event.get('progress'),'updated_at':datetime.now(timezone.utc).isoformat(),'profit_eligible':False}
     c.execute('UPDATE tasks SET payload=? WHERE sku=?',(json.dumps(latest,ensure_ascii=False),sku))
   def progress(info):
    with db()as c:
     row=c.execute('SELECT payload FROM tasks WHERE sku=?',(sku,)).fetchone();latest=json.loads(row[0])
     if latest.get('verification_reset')!=generation:raise RuntimeError('verification_reset')
     latest['automatic_visual_stage']={'status':'running','progress':info,'updated_at':datetime.now(timezone.utc).isoformat(),'profit_eligible':False}
     c.execute('UPDATE tasks SET payload=? WHERE sku=?',(json.dumps(latest,ensure_ascii=False),sku))
   result=visual_batch(task,policy,emit=emit,progress=progress)
   with db()as c:
    row=c.execute('SELECT payload FROM tasks WHERE sku=?',(sku,)).fetchone();latest=json.loads(row[0]);
    if latest.get('verification_reset')!=generation:return
    latest['automatic_visual_stage']=result;c.execute('UPDATE tasks SET payload=? WHERE sku=?',(json.dumps(latest,ensure_ascii=False),sku))
  except Exception:
   with db()as c:
    row=c.execute('SELECT payload FROM tasks WHERE sku=?',(sku,)).fetchone()
    if row:
     task=json.loads(row[0]);
     if task.get('verification_reset')!=locals().get('generation'):return
     task['automatic_visual_stage']={'status':'paused_error','profit_eligible':False};c.execute('UPDATE tasks SET payload=? WHERE sku=?',(json.dumps(task,ensure_ascii=False),sku))
  finally:
   AUTO_LOCK.release()
   if AUTO_PENDING:
    next_sku=AUTO_PENDING.pop();threading.Timer(1,lambda:start_visual_job(next_sku)).start()
 threading.Thread(target=run,daemon=True).start();return True

def start_image_reference(sku,force=False):
 with db()as c:row=c.execute('SELECT payload FROM tasks WHERE sku=?',(sku,)).fetchone()
 if not row:return False
 task=json.loads(row[0]);main=(task.get('images')or[None])[0];old=task.get('image_reference')or{}
 if not main or not force and old.get('main_image_url')==main and old.get('status')in ('ready','running','failed'):return False
 from ozon_operator.dominant_axis import prepare_context
 if not force and prepare_context(task)['palette']:return False
 if not force and not attribute_issues(task):
  from ozon_operator.dominant_axis import choose_axis,color_reference
  if color_reference(task).get('body_color')or not any(choose_axis(o,task).get('kind')=='color'for o in task.get('supplier_offers',[])):return False
 if not AUTO_LOCK.acquire(blocking=False):return False
 generation=task.get('verification_reset')
 task['image_reference']={'status':'running','main_image_url':main}
 with db()as c:c.execute('UPDATE tasks SET payload=? WHERE sku=?',(json.dumps(task,ensure_ascii=False),sku))
 def run_reference():
  try:
   result=audit_main_image(main)
   with db()as c:
    row=c.execute('SELECT payload FROM tasks WHERE sku=?',(sku,)).fetchone()
    if not row:return
    latest=json.loads(row[0])
    if latest.get('verification_reset')!=generation or(latest.get('images')or[None])[0]!=main:return
    latest['image_reference']=result;c.execute('UPDATE tasks SET payload=? WHERE sku=?',(json.dumps(latest,ensure_ascii=False),sku))
  finally:
   AUTO_LOCK.release()
   if AUTO_PENDING:
    pending=AUTO_PENDING.pop();threading.Timer(1,lambda:start_visual_job(pending)).start()
 threading.Thread(target=run_reference,daemon=True).start();return True

class Handler(BaseHTTPRequestHandler):
 def handle(self):
  try:super().handle()
  except (ConnectionAbortedError,ConnectionResetError,BrokenPipeError):
   self.close_connection=True

 def allowed(self):
  origin=self.headers.get('Origin','')
  return not origin or origin=='http://127.0.0.1:8765' or origin.startswith('chrome-extension://')
 def reply(self,status,payload,typ='application/json'):
  raw=payload.encode() if isinstance(payload,str) else json.dumps(payload,ensure_ascii=False).encode()
  self.send_response(status);self.send_header('Content-Type',typ+'; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
  origin=self.headers.get('Origin','')
  if self.allowed() and origin:self.send_header('Access-Control-Allow-Origin',origin);self.send_header('Vary','Origin')
  self.end_headers();self.wfile.write(raw)
 def do_OPTIONS(self):
  if not self.allowed():return self.reply(403,{'error':'origin_denied'})
  self.send_response(204);self.send_header('Access-Control-Allow-Origin',self.headers.get('Origin',''));self.send_header('Access-Control-Allow-Headers','Content-Type, X-Pairing-Key');self.send_header('Access-Control-Allow-Methods','POST, GET, OPTIONS');self.end_headers()
 def do_GET(self):
  if self.headers.get('Host')!='127.0.0.1:8765' or not self.allowed():return self.reply(403,{'error':'local_access_only'})
  if self.path=='/':return self.reply(200,(ROOT/'index.html').read_text(encoding='utf-8'), 'text/html')
  if self.path=='/api/1688-status':
   f=DATA/'1688-status.json';return self.reply(200,json.loads(f.read_text(encoding='utf-8')) if f.exists() else {'status':'unknown','reason':'尚未收到浏览器状态'})
  if self.path=='/api/vision-performance':
   with db()as c:tasks=[json.loads(r[0])for r in c.execute('SELECT payload FROM tasks')]
   return self.reply(200,performance_report(tasks))
  if self.path=='/api/vision-status':return self.reply(200,local_vision_status()if local_vision_enabled()else configuration_status())
  if self.path=='/api/match-policy':
   path=DATA/'match-policy.json'
   return self.reply(200,current_policy())
  if self.path in ['/api/match-review-bundle','/api/match-review-export']:
   with db()as c:raw=c.execute('SELECT payload FROM tasks').fetchall()
   _,jobs=task_views(raw);bundle=build_review_bundle(jobs)
   if self.path=='/api/match-review-bundle':return self.reply(200,bundle)
   self.send_response(200);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Disposition','attachment; filename="supplier-image-spec-review.json"');self.send_header('Cache-Control','no-store');self.end_headers()
   buffer=[];length=0
   for chunk in json.JSONEncoder(ensure_ascii=False,separators=(',',':')).iterencode(bundle):
    buffer.append(chunk);length+=len(chunk)
    if length>=32768:self.wfile.write(''.join(buffer).encode());buffer=[];length=0
   if buffer:self.wfile.write(''.join(buffer).encode())
   return
  if self.path=='/api/tasks':
   with db()as c:raw=c.execute('SELECT payload FROM tasks').fetchall()
   revision,rows=task_views(raw)
   projected=[{**j,'supplier_offers':[compact_offer(o)for o in j.get('supplier_offers',[])]}for j in rows]
   return self.reply(200,{'revision':revision,'jobs':projected,'capabilities':{'local_import':True,'supplier_automatic_search':False,'automatic_visual_matching':False,'remote_sync':False}})
  if self.path=='/api/pair' and self.headers.get('Origin','') in ('','http://127.0.0.1:8765'):return self.reply(200,{'key':TOKEN})
  self.reply(404,{'error':'not_found'})
 def do_POST(self):
  if self.headers.get('Host')!='127.0.0.1:8765' or not self.allowed() or not secrets.compare_digest(self.headers.get('X-Pairing-Key',''),TOKEN):return self.reply(403,{'error':'pairing_required'})
  try:
   size=int(self.headers.get('Content-Length','0'))
   if size<=0 or size>20000000:return self.reply(413,{'error':'size_limit'})
   data=json.loads(self.rfile.read(size))
   if self.path=='/api/image-reference':
    return self.reply(202,{'started':start_image_reference(str(data.get('ozon_sku','')),force=True)})
   if self.path=='/api/reset-verification':
    sku=str(data.get('ozon_sku',''))
    with db()as c:
     row=c.execute('SELECT payload FROM tasks WHERE sku=?',(sku,)).fetchone()
     if not row:return self.reply(404,{'error':'task_missing'})
     task=json.loads(row[0]);stamp=secrets.token_hex(12)
     backup=DATA/'reset-backups';backup.mkdir(exist_ok=True)
     (backup/(stamp+'.json')).write_text(json.dumps(task,ensure_ascii=False),encoding='utf-8')
     for k in ['supplier_offers','candidate_crawl_progress','candidate_crawl_status','detail_bridge_status','automatic_visual_stage','automatic_image_search','query_source_image','image_binding_verified','spec_shortlist','spec_visual_summary','triage_summary','image_reference']:
      task.pop(k,None)
     task.update({'supplier_offers':[],'source_search_status':'pending','profit_status':'not_calculated','verification_reset':stamp,'crawl_resume_request':stamp,'automatic_visual_enabled':True})
     c.execute('UPDATE tasks SET payload=? WHERE sku=?',(json.dumps(task,ensure_ascii=False),sku))
    AUTO_PENDING.discard(sku)
    return self.reply(200,{'reset':True,'ozon_data_preserved':True,'backup_created':True})
   if self.path in ['/api/supplier-candidates','/api/supplier-variants','/api/image-search-progress','/api/candidate-crawl-progress']:
    with db()as c:row=c.execute('SELECT payload FROM tasks WHERE sku=?',(str(data.get('ozon_sku','')),)).fetchone()
    expected=json.loads(row[0]).get('verification_reset')if row else None
    if expected and data.get('verification_reset')!=expected:return self.reply(409,{'error':'stale_verification_generation'})
   if self.path=='/api/image-search-progress':
    sku=str(data.get('ozon_sku',''))
    safe={k:str(data.get(k)or'')[:500]for k in ['phase','reason','source_image']};safe['received_at']=datetime.now(timezone.utc).isoformat()
    with db()as c:
     row=c.execute('SELECT payload FROM tasks WHERE sku=?',(sku,)).fetchone()
     if not row:return self.reply(404,{'error':'task_missing'})
     task=json.loads(row[0]);task['automatic_image_search']=safe;c.execute('UPDATE tasks SET payload=? WHERE sku=?',(json.dumps(task,ensure_ascii=False),sku))
    return self.reply(200,{'accepted':True})
   if self.path=='/api/candidate-crawl-progress':
    sku=str(data.get('ozon_sku',''))
    safe={k:str(data.get(k)or'')[:120]for k in ['phase','current_offer_id','reason','failed_phase','extension_version','updated_at','transport','fast_path_status']}
    for k in ['total','attempted','with_images','missing_images','sync_rejected','excluded_missing_images']:
     value=data.get(k,0)
     if type(value)is not int or not 0<=value<=10000:return self.reply(400,{'error':'invalid progress count'})
     safe[k]=value
    for metric in ['crawl_elapsed_ms','total_read_ms','average_read_ms']:
     safe[metric]=data.get(metric)if type(data.get(metric))is int and 0<=data[metric]<1000000000000 else 0
    safe['last_duration_ms']=data.get('last_duration_ms')if type(data.get('last_duration_ms'))is int else 0
    http_error=data.get('last_http_error')
    if isinstance(http_error,dict):safe['last_http_error']={k:str(http_error.get(k,''))[:180]for k in ['path','status','error']}
    safe['received_at']=datetime.now(timezone.utc).isoformat()
    with db()as c:
     row=c.execute('SELECT payload FROM tasks WHERE sku=?',(sku,)).fetchone()
     if not row:return self.reply(404,{'error':'task missing'})
     task=json.loads(row[0]);task['candidate_crawl_progress']=safe;c.execute('UPDATE tasks SET payload=? WHERE sku=?',(json.dumps(task,ensure_ascii=False),sku))
    if safe.get('phase')=='all_candidates_attempted':start_image_reference(sku)
    return self.reply(200,{'accepted':True})
   if self.path=='/api/resume-candidate-crawl':
    sku=str(data.get('ozon_sku',''))
    with db()as c:
     row=c.execute('SELECT payload FROM tasks WHERE sku=?',(sku,)).fetchone()
     if not row:return self.reply(404,{'error':'task missing'})
     task=json.loads(row[0]);task['automatic_visual_enabled']=True;task['crawl_resume_request']=secrets.token_hex(8);c.execute('UPDATE tasks SET payload=? WHERE sku=?',(json.dumps(task,ensure_ascii=False),sku))
    return self.reply(202,{'resume_requested':True,'note':'waiting_for_extension_poll'})
   if self.path=='/api/detail-bridge-status':
    sku=str(data.get('ozon_sku',''))
    with db()as c:
     row=c.execute('SELECT payload FROM tasks WHERE sku=?',(sku,)).fetchone()
     if not row:return self.reply(404,{'error':'task missing'})
     task=json.loads(row[0]);status_key='candidate_crawl_status'if str(data.get('state','')).startswith(('automatically_loading','candidate_read','crawl_'))else'detail_bridge_status';task[status_key]={'open_candidate_tabs':data.get('open_candidate_tabs',0),'synced_offers':data.get('synced_offers',0),'state':str(data.get('state','unknown'))[:100],'received_at':datetime.now(timezone.utc).isoformat()}
     c.execute('UPDATE tasks SET payload=? WHERE sku=?',(json.dumps(task,ensure_ascii=False),sku))
    return self.reply(200,{'accepted':True})
   if self.path=='/api/automatic-visual':
    sku=str(data.get('ozon_sku',''))
    if not local_vision_enabled():return self.reply(409,{'error':'本地视觉未配置'})
    with db()as c:row=c.execute('SELECT payload FROM tasks WHERE sku=?',(sku,)).fetchone()
    if not row:return self.reply(404,{'error':'Ozon任务不存在'})
    task=json.loads(row[0]);task['automatic_visual_enabled']=True;task['visual_run_requested']=True
    with db()as c:c.execute('UPDATE tasks SET payload=? WHERE sku=?',(json.dumps(task,ensure_ascii=False),sku))
    return self.reply(202,{'started':start_visual_job(sku),'automatic_visual_enabled':True,'profit_eligible':False})
   if self.path=='/api/vision-preview':
    if not local_vision_enabled():return self.reply(409,{'error':'请先运行本地视觉安装脚本并重启工作台'})
    sku=str(data.get('ozon_sku',''));image=data.get('supplier_image')
    if not isinstance(image,str):return self.reply(400,{'error':'缺少1688规格图片地址'})
    with db()as c:row=c.execute('SELECT payload FROM tasks WHERE sku=?',(sku,)).fetchone()
    if not row:return self.reply(404,{'error':'Ozon任务不存在'})
    task=json.loads(row[0])
    if not task.get('images'):return self.reply(409,{'error':'缺少Ozon采集主图'})
    known=[o for o in task.get('supplier_offers',[])if image==o.get('image')or any(image in v.get('images',[])for v in o.get('detail_variants',[]))]
    material_attributes=known[0].get('package_observation',{}).get('attributes',[])if len(known)==1 else []
    result=compare_local(task['images'][0],[image],{'ozon_attributes':task.get('attributes',[]),'supplier_material_attributes':material_attributes},current_policy())
    result['source_images']={'ozon_main_image':task['images'][0],'supplier_test_image':image}
    result['supplier_material_source']='uniquely_matched_offer_attributes_not_selected_sku_verified'if material_attributes else 'not_available'
    result['preview_only']=True;result['sku_identity_verified']=False
    return self.reply(200,result)
   if self.path=='/api/vision-review':
    if not local_vision_enabled()and not configuration_status()['configured']:return self.reply(409,{'error':'尚未配置本机视觉模型服务','status':'vision_service_not_configured'})
    sku=str(data.get('ozon_sku',''));offer=str(data.get('offer_id',''));supplier_sku=str(data.get('sku_id',''))
    with db()as c:row=c.execute('SELECT payload FROM tasks WHERE sku=?',(sku,)).fetchone()
    if not row:return self.reply(404,{'error':'Ozon任务不存在'})
    task=json.loads(row[0]);offers=[o for o in task.get('supplier_offers',[])if str(o.get('offer_id'))==offer]
    if len(offers)!=1:return self.reply(409,{'error':'供应商商品未唯一关联'})
    variants=[v for v in offers[0].get('detail_variants',[])if v.get('sku_id')and str(v['sku_id'])==supplier_sku]
    if len(variants)!=1 or not variants[0].get('images')or variants[0].get('image_binding_verified')is not True:return self.reply(409,{'error':'尚未取得唯一SKU及其明确关联图片，不能调用视觉模型认定匹配'})
    if not task.get('images'):return self.reply(409,{'error':'Ozon采集主图缺失'})
    variant=variants[0]
    result=(compare_local if local_vision_enabled()else compare_sku_images)(task['images'][0],variant['images'],{'ozon_attributes':task.get('attributes',[]),'supplier_sku_labels':variant.get('labels',[]),'supplier_sku_specification':variant.get('specification_text'),'supplier_material_attributes':offers[0].get('package_observation',{}).get('attributes',[])},current_policy())
    if result['status']=='visual_assessment_read':
     with db()as c:
      row=c.execute('SELECT payload FROM tasks WHERE sku=?',(sku,)).fetchone();latest=json.loads(row[0])
      for o in latest.get('supplier_offers',[]):
       if str(o.get('offer_id'))==offer:
        for v in o.get('detail_variants',[]):
         if str(v.get('sku_id'))==supplier_sku:v['visual_assessment']=result
      c.execute('UPDATE tasks SET payload=? WHERE sku=?',(json.dumps(latest,ensure_ascii=False),sku))
    return self.reply(200,result)
   if self.path=='/api/match-policy':
    policy=validate_policy(data);path=DATA/'match-policy.json'
    if path.exists():
     history=DATA/'policy-history';history.mkdir(exist_ok=True)
     (history/(datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%f')+'.json')).write_bytes(path.read_bytes())
    policy['saved_at']=datetime.now(timezone.utc).isoformat();path.write_text(json.dumps(policy,ensure_ascii=False,indent=2),encoding='utf-8')
    with db()as c:
     for sku,payload in c.execute('SELECT sku,payload FROM tasks').fetchall():
      task=json.loads(payload)
      for o in task.get('supplier_offers',[]):o['selected_sku_match_verified']=False
      c.execute('UPDATE tasks SET payload=? WHERE sku=?',(json.dumps(task,ensure_ascii=False),sku))
    return self.reply(200,{'saved':True,'automatic_visual_matching':False})
   if self.path=='/api/supplier-variants':
    sku=str(data.get('ozon_sku',''));offer=str(data.get('offer_id',''))
    try:variants=normalize_inventory_rows(data.get('variants'))
    except (ValueError,TypeError):return self.reply(400,{'error':'invalid variant evidence'})
    with db() as c:
     row=c.execute('SELECT payload FROM tasks WHERE sku=?',(sku,)).fetchone()
     if not row:return self.reply(404,{'error':'工作台没有该Ozon SKU'})
     task=json.loads(row[0]);matches=[o for o in task.get('supplier_offers',[])if str(o.get('offer_id'))==offer]
     if len(matches)!=1:return self.reply(409,{'error':'当前商品不在唯一图搜候选中'})
     attrs=[]
     for a in data.get('product_attributes',[])[:200]:
      if isinstance(a,dict)and isinstance(a.get('name'),str)and isinstance(a.get('values'),list):attrs.append({'name':a['name'][:100],'source':str(a.get('source','detail_initial_data_attribute'))[:100],'source_path':str(a.get('source_path',''))[:300],'values':[str(v)[:300]for v in a['values'][:100]if isinstance(v,(str,int,float))]})
     for v in variants:v['supplier_attributes']=attrs
     matches[0]['detail_attributes']=attrs
     count=data.get('observed_sku_map_count');confirmed_missing=bool(variants)and type(count)is int and count==len(variants)and not any(v.get('images')for v in variants)and not data.get('spec_options')and not data.get('shared_image_groups')and data.get('scan_limited')is not True
     matches[0]['excluded_missing_sku_images']=confirmed_missing
     if confirmed_missing:matches[0]['source_exclusion_reason']='已读取实际SKU记录，但没有对应规格图片，按用户规则直接排除'
     else:matches[0].pop('source_exclusion_reason',None)
     matches[0]['detail_variants']=preserve_visual_reviews(matches[0].get('detail_variants',[]),variants);matches[0]['all_variants_verified']=False
     matches[0]['variant_diagnostics']=data.get('control_diagnostics',[])[:80]
     options=data.get('spec_options',[])
     matches[0]['detail_spec_options']=preserve_visual_reviews(matches[0].get('detail_spec_options',[]),normalize_inventory_rows(options if isinstance(options,list)and len(options)<=2000 else []))
     matches[0]['background_read_summary']={k:data.get(k)for k in ['transport','observed_sku_map_count','exact_property_image_mappings','structured_roots','scan_limited','completeness']}
     for v in matches[0]['detail_spec_options']:v['supplier_attributes']=attrs
     matches[0]['selector_inventory_status']=str(data.get('network_inventory_status','not_observed'))[:100]
     # Deduplicate shared images BEFORE bounded normalization. Previously many
     # property groups expanded beyond the 300-row limit and caused HTTP 400.
     shared_urls={}
     groups=data.get('shared_image_groups',[])
     if not isinstance(groups,list):groups=[]
     shared_limit=False
     for group in groups:
      if not isinstance(group,dict)or not isinstance(group.get('images'),list):continue
      for url in group['images']:
       if not isinstance(url,str):continue
       if len(shared_urls)>=2000 and url not in shared_urls:shared_limit=True;continue
       shared_urls[url]=True
     named_urls={u for v in matches[0]['detail_spec_options']for u in v.get('images',[])}
     shared=[{'sku_id':None,'labels':['详情规格区域图片，未绑定具体SKU'],'images':[url],'extraction_status':'shared_detail_image_sku_unbound'}for url in shared_urls if url not in named_urls]
     normalized=[]
     for offset in range(0,len(shared),300):normalized.extend(normalize_variants(shared[offset:offset+300]))
     unbound=[v for v in normalized if v['images']]
     matches[0]['unbound_detail_images']=preserve_visual_reviews(matches[0].get('unbound_detail_images',[]),unbound)
     matches[0]['inventory_read_limits']={'shared_image_limit_reached':shared_limit,'source_scan_limited':data.get('scan_limited')is True,'shared_images_received':len(shared_urls)}
     matches[0]['selected_sku_match_verified']=False
     c.execute('UPDATE tasks SET payload=? WHERE sku=?',(json.dumps(task,ensure_ascii=False),sku))
    if task.get('automatic_visual_enabled')and local_vision_enabled():start_visual_job(sku)
    return self.reply(200,{'accepted':len(variants),'profit_eligible':False})
   if self.path=='/api/supplier-quotes':
    sku=str(data.get('ozon_sku',''));offer=str(data.get('offer_id',''))
    with db() as c:
     row=c.execute('SELECT payload FROM tasks WHERE sku=?',(sku,)).fetchone()
     if not row:return self.reply(404,{'error':'工作台没有该Ozon SKU'})
     task=json.loads(row[0])
     try:result=merge_quotes(task,offer,data.get('quotes'))
     except ValueError as e:return self.reply(409,{'error':str(e)})
     c.execute('UPDATE tasks SET payload=? WHERE sku=?',(json.dumps(task,ensure_ascii=False),sku))
    return self.reply(200,result)
   if self.path=='/api/supplier-package':
    sku=str(data.get('ozon_sku',''));offer=str(data.get('offer_id',''))
    with db() as c:
     row=c.execute('SELECT payload FROM tasks WHERE sku=?',(sku,)).fetchone()
     if not row:return self.reply(404,{'error':'工作台没有该Ozon SKU'})
     task=json.loads(row[0]);offers=task.get('supplier_offers',[]);matches=[o for o in offers if str(o.get('offer_id'))==offer]
     if len(matches)!=1:return self.reply(409,{'error':'当前供应商不在该SKU的图搜候选中，不能关联'})
     matches[0]['package_observation']={'packaging':data.get('packaging'),'attributes':data.get('attributes',[]),'selected_sku_identity_verified':False,'source':data.get('source','unknown'),'sales_unit_quantity':data.get('sales_unit_quantity'),'attribute_read_status':data.get('attribute_read_status')}
     c.execute('UPDATE tasks SET payload=? WHERE sku=?',(json.dumps(task,ensure_ascii=False),sku))
    return self.reply(200,{'accepted':True,'profit_eligible':False})
   if self.path=='/api/supplier-candidates':
    import re
    sku=str(data.get('ozon_sku',''));offers=data.get('offers',[])
    if not re.fullmatch(r'\d+',sku) or not isinstance(offers,list) or len(offers)>100:return self.reply(400,{'error':'invalid_candidates'})
    with db() as c:
     old=c.execute('SELECT payload FROM tasks WHERE sku=?',(sku,)).fetchone()
     if not old:return self.reply(404,{'error':'Ozon SKU尚未进入工作台'})
     task=json.loads(old[0]);safe=[];previous={str(o.get('offer_id')):o for o in task.get('supplier_offers',[])};seen=set()
     for o in offers:
      if len(safe)>=30:break
      if not isinstance(o,dict) or not re.fullmatch(r'\d+',str(o.get('offer_id',''))):continue
      offer_id=str(o['offer_id'])
      if offer_id in seen:continue
      seen.add(offer_id)
      item={**previous.get(offer_id,{}),**{k:o.get(k)for k in ['offer_id','title','image','candidate_sku_id','search_moq_labels','free_shipping_tag_observed']}};item.update({'url':'https://detail.1688.com/offer/'+str(o['offer_id'])+'.html','cost_verified':False,'match_verified':False,'discovery_method':'1688_image_search'});safe.append(item)
     task['supplier_offers']=safe;task['candidate_limit']=30;task['source_search_status']='candidates_received';task['image_binding_verified']=bool(data.get('image_binding_verified')is True and data.get('auto_uploaded_source_image')==(task.get('images')or[None])[0]);task['query_source_image']=data.get('auto_uploaded_source_image')if task['image_binding_verified']else None;task['tasks']=list(set(task.get('tasks',[])+['verify_query_image_matches_ozon_sku','verify_material_quantity_selected_sku_and_freight']))
     task=triage_task(task)
     c.execute('UPDATE tasks SET payload=? WHERE sku=?',(json.dumps(task,ensure_ascii=False),sku))
    return self.reply(200,{'accepted':len(safe),'profit_calculated':False})
   if self.path=='/api/1688-status':
    if data.get('status') not in ['logged_in_page','login_required','unknown','page_closed']:return self.reply(400,{'error':'invalid_status'})
    safe={k:data.get(k) for k in ['status','reason','observed_at']}
    safe['received_at']=datetime.now(timezone.utc).isoformat();(DATA/'1688-status.json').write_text(json.dumps(safe,ensure_ascii=False),encoding='utf-8');return self.reply(200,{'accepted':True})
   if self.path!='/api/import':return self.reply(404,{'error':'not_found'})
   queue=build_source_queue(data)
   with db() as c:
    for task in queue['jobs']:c.execute('INSERT OR IGNORE INTO tasks VALUES (?,?)',(task['ozon_sku'],json.dumps(task,ensure_ascii=False)))
   return self.reply(200,{'accepted':queue['collection_passed_count']})
  except (ValueError,TypeError,KeyError):return self.reply(400,{'error':'invalid_report'})
 def log_message(self,*args):pass
if __name__=='__main__':
 with db()as c:
  for sku,payload in c.execute('SELECT sku,payload FROM tasks').fetchall():
   task=json.loads(payload)
   if task.get('pipeline_mode')!='dominant_axis_reference_v2':
    task['pipeline_mode']='dominant_axis_reference_v2';task['visual_run_requested']=False;task['automatic_visual_stage']={'status':'deferred_until_capture_and_prefilter','profit_eligible':False};c.execute('UPDATE tasks SET payload=? WHERE sku=?',(json.dumps(task,ensure_ascii=False),sku))
   if task.get('image_reference',{}).get('status')=='running':
    task['image_reference']={**task['image_reference'],'status':'interrupted','reason':'工作台重启中断了参照核查，等待重新排队'};c.execute('UPDATE tasks SET payload=? WHERE sku=?',(json.dumps(task,ensure_ascii=False),sku))
   if task.get('automatic_visual_stage',{}).get('status')=='running':
    task['automatic_visual_stage']={'status':'paused_after_restart','profit_eligible':False};c.execute('UPDATE tasks SET payload=? WHERE sku=?',(json.dumps(task,ensure_ascii=False),sku))
 server=ThreadingHTTPServer(('127.0.0.1',8765),Handler)
 threading.Timer(1,lambda:webbrowser.open('http://127.0.0.1:8765')).start()
 def resume_enabled_visual_tasks():
  with db()as c:tasks=[json.loads(row[0])for row in c.execute('SELECT payload FROM tasks')]
  policy=current_policy()
  for task in tasks:
   if not task.get('automatic_visual_enabled')or not task.get('visual_run_requested'):continue
   rows=[v for o in task.get('supplier_offers',[])for key in ['detail_variants','detail_spec_options','unbound_detail_images']for v in o.get(key,[])]
   if any(v.get('images')and(v.get('automatic_visual_review')or{}).get('fingerprint')!=review_fingerprint((task.get('images')or[None])[0],v['images'],policy)for v in rows):start_visual_job(task['ozon_sku'])
 threading.Timer(2,resume_enabled_visual_tasks).start()
 print('Ozon workbench: http://127.0.0.1:8765 — Ctrl+C to stop')
 server.serve_forever()
