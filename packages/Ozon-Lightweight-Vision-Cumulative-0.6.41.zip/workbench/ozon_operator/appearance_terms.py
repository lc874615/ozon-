import re
COLORS={'grey':r'灰|\bgr[ae]y\b|сер(?:ый|ая|ое|ые|ого)', 'black':r'黑|\bblack\b|ч[её]рн', 'white':r'白|\bwhite\b|бел(?:ый|ая|ое|ые|ого)', 'pink':r'粉|\bpink\b|розов', 'blue':r'蓝|藏青|\bblue\b|син(?:ий|яя|ее)|голуб', 'green':r'绿|\bgreen\b|зел[её]н', 'purple':r'紫|\bpurple\b|фиолет', 'brown':r'棕|咖|驼|\bbrown\b|коричнев', 'gold':r'金(?!属|丝)|\bgold\b|золот', 'silver':r'银|\bsilver\b|серебр'}
COLORS.update({'red':r'红|\bred\b|красн|бордов','yellow':r'黄|\byellow\b|ж[её]лт','orange':r'橙|橘|桔|\borange\b|оранж','beige':r'米色|米白|卡其|奶油(?!风)|香槟|沙色|\bbeige\b|беж','cyan':r'青色|\bcyan\b|бирюз'})
def color(value):
 found={k for k,p in COLORS.items()if re.search(p,str(value),re.I)}
 return next(iter(found))if len(found)==1 else None

