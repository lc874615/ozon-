"""Detect impossible reference dimensions without inventing replacement measurements."""
import re
from .parameter_prefilter import facts

def issues(task):
 attrs=task.get('attributes',[]);whole=facts(attrs);result=[]
 for a in attrs:
  if not isinstance(a,dict):continue
  name=str(a.get('name')or a.get('title')or'').lower()
  if 'сиденья'not in name:continue
  comparable=re.sub(r'\s+сиденья','',name)
  seat=facts([{**a,'name':comparable}])
  for axis,value in seat.items():
   parent=whole.get(axis)
   if axis.endswith('_mm')and parent and value and value>parent:result.append({'code':'seat_exceeds_whole','axis':axis,'whole_mm':parent,'seat_mm':value,'action':'disable_axis_until_image_evidence'})
 capacities=capacity_values(task)
 if len(set(capacities))>1:result.append({'code':'conflicting_capacity_values','action':'disable_capacity_until_image_evidence'})
 return result

def image_reference(task):
 ref=task.get('image_reference')or{}
 return ref if ref.get('status')=='ready'and ref.get('main_image_url')==(task.get('images')or[None])[0]else{}

def effective_dimensions(task):
 values={k:v for k,v in facts(task.get('attributes',[])).items()if k.endswith('_mm')}
 for problem in issues(task):values.pop(problem.get('axis'),None)
 for item in image_reference(task).get('printed_dimensions',[]):
  if not isinstance(item,dict):continue
  axis=item.get('axis');value=item.get('value_mm');text=str(item.get('evidence_text',''))
  if axis not in ('height_mm','width_mm','depth_mm','length_mm')or not isinstance(value,(int,float))or not 0<value<100000:continue
  match=re.search(r'(\d+(?:[.,]\d+)?)\s*(mm|cm|мм|см|毫米|厘米)',text,re.I)
  if match:
   actual=float(match.group(1).replace(',','.'))*(10 if match.group(2).lower()in ('cm','см','厘米')else 1)
   if abs(actual-value)<.1:values[axis]=value
 return values

def capacity_values(task):
 values=[]
 for a in task.get('attributes',[]):
  name=str(a.get('name','')).lower()
  if not re.search(r'容量|容积|объ[её]м|[её]мкость|capacity',name)or re.search(r'包装|упаков',name):continue
  raw=str(a.get('value',''));unit=re.search(r'(ml|мл|毫升|l|л|升)\s*$',name,re.I)
  m=re.fullmatch(r'\s*(\d+(?:[.,]\d+)?)\s*(ml|мл|毫升|l|л|升)?\s*',raw,re.I)
  u=(m.group(2)or(unit.group(1)if unit else None))if m else None
  if m and u:values.append(float(m.group(1).replace(',','.'))*(1000 if u.lower()in ('l','л','升')else 1))
 return [v for v in values if v>0]

def effective_capacity(task):
 values=capacity_values(task);result=values[0]if len(set(values))==1 else None
 printed=image_reference(task).get('printed_capacity')
 if isinstance(printed,dict):
  match=re.search(r'(\d+(?:[.,]\d+)?)\s*(ml|мл|毫升|l|л|升)',str(printed.get('evidence_text','')),re.I)
  value=printed.get('value_ml')
  if match and type(value)in(int,float)and value>0:
   actual=float(match.group(1).replace(',','.'))*(1000 if match.group(2).lower()in ('l','л','升')else 1)
   if abs(actual-value)<.1:result=value
 return result
