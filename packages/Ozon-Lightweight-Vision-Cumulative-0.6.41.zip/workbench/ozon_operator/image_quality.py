"""Read native image geometry without resizing or adding image dependencies."""
import struct

def image_dimensions(raw):
 if raw.startswith(b'\x89PNG\r\n\x1a\n')and len(raw)>=24:return struct.unpack('>II',raw[16:24])
 if raw[:3]==b'\xff\xd8\xff':
  i=2
  while i+4<=len(raw):
   if raw[i]!=255:i+=1;continue
   while i<len(raw)and raw[i]==255:i+=1
   if i>=len(raw):break
   marker=raw[i];i+=1
   if marker in (0xD8,0xD9,0x01)or 0xD0<=marker<=0xD7:continue
   if i+2>len(raw):break
   size=int.from_bytes(raw[i:i+2],'big')
   if size<2 or i+size>len(raw):break
   if marker in (0xC0,0xC1,0xC2,0xC3,0xC5,0xC6,0xC7,0xC9,0xCA,0xCB,0xCD,0xCE,0xCF)and size>=7:
    h,w=struct.unpack('>HH',raw[i+3:i+7]);return w,h
   i+=size
 if raw[:4]==b'RIFF'and raw[8:12]==b'WEBP'and len(raw)>=30:
  kind=raw[12:16]
  if kind==b'VP8X':return 1+int.from_bytes(raw[24:27],'little'),1+int.from_bytes(raw[27:30],'little')
  if kind==b'VP8 'and raw[23:26]==b'\x9d\x01\x2a':return int.from_bytes(raw[26:28],'little')&16383,int.from_bytes(raw[28:30],'little')&16383
  if kind==b'VP8L'and raw[20]==0x2F:
   bits=int.from_bytes(raw[21:25],'little');return (bits&16383)+1,((bits>>14)&16383)+1
 return None
