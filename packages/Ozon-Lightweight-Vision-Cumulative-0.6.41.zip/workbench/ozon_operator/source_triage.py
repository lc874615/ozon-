"""Conservative lead triage. Search evidence never establishes final SKU costs."""
import re,time
from decimal import Decimal,InvalidOperation

def triage_offer(offer):
    reasons=[];title=str(offer.get('title',''))
    price=None
    try:
        p=Decimal(str(offer.get('search_price_cny')))
        if p.is_finite() and p>0:price=str(p)
    except (ValueError,InvalidOperation):pass
    return {**offer,'triage_status':'hold_from_cost_shortlist' if reasons else 'detail_verification_pending','triage_reasons':reasons,'cost_verified':False,'match_verified':False,'search_price_cny':None,'freight_status':'free_shipping_tag_needs_sku_scope_check' if offer.get('free_shipping_tag_observed') else 'unknown_not_zero','required_checks':['query_image_binding','whole_product_structure','material','sku_specification','sales_pack_quantity','selected_sku_moq','selected_sku_price','domestic_freight'],'profit_eligible':False}

def triage_task(task):
    started=time.perf_counter()
    # Apply chair-specific title rules only to chair tasks.
    title=str(task.get('title','')).lower();chair=bool(re.search(r'стул|椅',title))
    offers=[]
    for offer in task.get('supplier_offers',[]):
        if chair:offers.append(triage_offer(offer))
        else:
            item=triage_offer({**offer,'title':''});item['title']=offer.get('title','');offers.append(item)
    for offer in offers:
        if offer.get('excluded_missing_sku_images'):
            offer['triage_status']='excluded_missing_sku_images';offer['triage_reasons']=[offer.get('source_exclusion_reason','规格缺图，已排除')];offer['profit_eligible']=False
    from .spec_shortlist import rank_profit_candidates
    from .match_policy import current_policy
    policy=current_policy()
    from .visual_automation import summarize_spec_visuals,visual_result_view
    from .visual_prefilter import reference_facts,prefilter
    from .dominant_axis import choose_axis,prepare_context,reference_status,color_screening
    from .attribute_integrity import issues,effective_dimensions
    from .parameter_prefilter import facts as parameter_facts
    from .visual_automation import review_fingerprint
    context=prepare_context(task)
    axis_summary=[]
    for o in offers:
        offer_start=time.perf_counter()
        o['dominant_axis']=choose_axis(o,task)
        for v in o.get('detail_spec_options',[])+o.get('detail_variants',[]):
            v['prefilter_axis']=o['dominant_axis']
            if not v.get('specs')and len(v.get('labels',[]))==1 and v['labels'][0]in o['dominant_axis'].get('values',[]):v['specs']={o['dominant_axis']['name']:v['labels'][0]}
            if o['dominant_axis'].get('kind')=='color':v['color_screening']=color_screening((v.get('specs')or{}).get(o['dominant_axis'].get('name'),''),context)
            quick=prefilter(task,v,context)
            if quick:v['automatic_visual_review']={'fingerprint':review_fingerprint((task.get('images')or[None])[0],v.get('images',[]),policy),'assessment':quick,'state':'visual_reject','profit_eligible':False}
            v['visual_result_view']={'result':'不符','reason':o.get('source_exclusion_reason','缺规格图，已排除'),'retryable':False}if o.get('excluded_missing_sku_images')else visual_result_view(task,v,policy,context)
        selected=[v for v in o.get('detail_variants',[])if v.get('image_binding_verified')and v.get('images')]or o.get('detail_spec_options',[])
        rejected=sum(v.get('visual_result_view',{}).get('result')=='不符'and(v.get('automatic_visual_review')or{}).get('assessment',{}).get('status')=='prefilter_rejected'for v in selected)
        summary={'offer_id':str(o.get('offer_id')),'axis_name':o['dominant_axis'].get('name'),'axis_kind':o['dominant_axis'].get('kind'),'status':o['dominant_axis']['status'],'basis':o['dominant_axis'].get('basis'),'reference_status':reference_status(o['dominant_axis'],context),'specs':len(selected),'rejected':rejected,'remaining':len(selected)-rejected,'color_rejected':sum(v.get('color_screening',{}).get('result')=='不符'for v in selected),'color_unknown_excluded':sum((v.get('automatic_visual_review')or{}).get('assessment',{}).get('evidence',{}).get('code')=='supplier_color_missing_excluded'for v in selected),'style_exception_passed':sum(v.get('color_screening',{}).get('user_style_exception')is True for v in selected),'color_passed':sum(v.get('color_screening',{}).get('result')=='通过'and not v.get('color_screening',{}).get('user_style_exception')for v in selected),'color_unknown':sum(v.get('color_screening',{}).get('result')is None for v in selected)if o['dominant_axis'].get('kind')=='color'else 0,'elapsed_ms':round((time.perf_counter()-offer_start)*1000,2)}
        if o.get('excluded_missing_sku_images'):summary.update(status='excluded_missing_images',axis_kind='excluded',axis_name=None,reference_status='缺图已排除，不参与主差异筛选',excluded_specs=len(o.get('detail_variants',[])))
        o['dominant_screening']=summary;axis_summary.append(summary)
    screening_ms=round((time.perf_counter()-started)*1000,2)
    shortlist=rank_profit_candidates({**task,'supplier_offers':offers},policy)
    visual_summary=summarize_spec_visuals({**task,'supplier_offers':offers},policy,context)
    reference_parameters=parameter_facts(task.get('attributes',[]))
    supplier_parameters=[parameter_facts(o.get('detail_attributes',[]),v.get('specs',{}))for o in offers for v in o.get('detail_variants',[])]
    coverage={'ozon_product_dimension_axes':len(effective_dimensions(task)),'supplier_specs_with_product_dimensions':sum(any(k.endswith('_mm')and v is not None for k,v in f.items())for f in supplier_parameters),'supplier_specs_with_material':sum(any(k.endswith('_material')and v is not None for k,v in f.items())for f in supplier_parameters),'reference_parameters':reference_parameters}
    return {**task,'dominant_screening':{'offers':axis_summary,'elapsed_ms':screening_ms,'rejected':sum(a['rejected']for a in axis_summary),'remaining':sum(a['remaining']for a in axis_summary),'color_rejected':sum(a['color_rejected']for a in axis_summary),'color_unknown_excluded':sum(a['color_unknown_excluded']for a in axis_summary),'parameter_passed':sum(a['color_passed']+a['style_exception_passed']for a in axis_summary),'style_exception_passed':sum(a['style_exception_passed']for a in axis_summary),'color_passed':sum(a['color_passed']for a in axis_summary),'color_unknown':sum(a['color_unknown']for a in axis_summary),'allowed_colors':context['palette'],'reference_status':(task.get('image_reference')or{}).get('status','not_started')},'attribute_integrity_issues':issues(task),'parameter_prefilter_coverage':coverage,'visual_prefilter_reference':reference_facts(task),'spec_shortlist':shortlist,'spec_visual_summary':visual_summary,'supplier_offers':offers,'triage_summary':{'total':len(offers),'excluded_missing_images':sum(bool(o.get('excluded_missing_sku_images'))for o in offers),'held':sum(o['triage_status']=='hold_from_cost_shortlist'for o in offers),'pending_details':sum(o['triage_status']=='detail_verification_pending'for o in offers)}}
