"""Visual -> parameter -> exact quantity quote -> cheapest goods+domestic freight.
No similarity score ranking and no price from image-search cards.
"""
from decimal import Decimal,InvalidOperation
from datetime import datetime,timezone
from .supplier_variants import purchase_quantity
from .visual_automation import review_fingerprint

REQUIRED_PARAMETERS=('material','product_dimensions')

def rank_profit_candidates(task,policy):
 eligible=[];pending=[];rejected=[]
 for offer in task.get('supplier_offers',[]):
  rows=[('detail_variants',v)for v in offer.get('detail_variants',[])]+[('detail_spec_options',v)for v in offer.get('detail_spec_options',[])]
  for kind,v in rows:
   identity={'offer_id':str(offer.get('offer_id')),'sku_id':v.get('sku_id'),'labels':v.get('labels',[]),'images':v.get('images',[]),'url':'https://detail.1688.com/offer/'+str(offer.get('offer_id'))+'.html'}
   review=v.get('automatic_visual_review')or{};visual=review.get('assessment',{}).get('visual',{})
   expected=review_fingerprint((task.get('images')or[None])[0],v.get('images',[]),policy)
   if review.get('fingerprint')!=expected:pending.append({**identity,'stage':'visual','reason':'visual_review_missing_or_stale'});continue
   if any(visual.get(k)=='mismatch'for k in ('structure','local_details','color')):rejected.append({**identity,'stage':'visual'});continue
   if not visual.get('visual_match_allowed'):pending.append({**identity,'stage':'visual','reason':'visual_evidence_pending'});continue
   params=v.get('parameter_findings')or{};checks=params.get('checks',{})
   mismatch=[k for k in REQUIRED_PARAMETERS if checks.get(k,{}).get('decision')=='mismatch']
   if mismatch:rejected.append({**identity,'stage':'parameters','reasons':mismatch});continue
   missing=[k for k in REQUIRED_PARAMETERS if checks.get(k,{}).get('decision')!='match'or not checks[k].get('ozon_evidence')or not checks[k].get('supplier_evidence')]
   if missing:pending.append({**identity,'stage':'parameters','reasons':missing});continue
   if not v.get('sku_id')or not v.get('image_binding_verified'):pending.append({**identity,'stage':'sku_binding','reason':'exact_sku_combination_not_verified'});continue
   try:quantity=purchase_quantity(task.get('units_per_sales_sku'),v.get('sales_unit_quantity',{}).get('value',1))
   except ValueError:pending.append({**identity,'stage':'quantity','reason':'quantity_invalid'});continue
   quotes=[q for q in offer.get('quantity_quotes',[])if str(q.get('sku_id'))==str(v['sku_id'])and q.get('purchase_quantity')==quantity]
   costs=[]
   for q in quotes:
    try:
     goods=Decimal(str(q['goods_total_cny']));freight=Decimal(str(q['domestic_freight_cny']))
     if not goods.is_finite()or not freight.is_finite()or goods<=0 or freight<0 or q.get('currency')!='CNY':continue
     if q.get('freight_destination_verified')is not True:continue
     received=datetime.fromisoformat(q['received_at'].replace('Z','+00:00'))
     age=(datetime.now(timezone.utc)-received).total_seconds()
     if age<0 or age>900:continue
     costs.append((goods+freight,goods,freight,q))
    except (KeyError,ValueError,TypeError,InvalidOperation):continue
   if not costs:pending.append({**identity,'stage':'quote','reason':'fresh_exact_quantity_goods_and_destination_freight_required','purchase_quantity':quantity});continue
   cost,goods,freight,q=min(costs,key=lambda x:x[0])
   eligible.append({**identity,'stage':'profit_candidate','purchase_quantity':quantity,'goods_total_cny':str(goods),'domestic_freight_cny':str(freight),'goods_plus_freight_cny':str(cost),'quote_received_at':q['received_at'],'financial_margin_verified':False})
 eligible.sort(key=lambda v:(Decimal(v['goods_plus_freight_cny']),v['offer_id'],str(v['sku_id'])))
 return {'eligible':eligible,'pending':pending,'rejected':rejected,'lowest_verified_candidate':eligible[0]if eligible else None,'selection_basis':'lowest_exact_purchase_total_plus_verified_domestic_freight_after_visual_and_parameter_pass','global_minimum_proven':False,'profit_calculated':False}
