"""Per-variant evidence and user-authorized default contents quantity."""
import re
from urllib.parse import urlsplit

def contents_quantity(name):
 values={int(m.group(1))for m in re.finditer(r'(?<![\d.])(\d+)\s*(?:件|个|把|只|张|支|条|枚|双|对)(?!起批)',name)if int(m.group(1))>0}
 if len(values)>1:return {'value':None,'basis':'conflicting_explicit_quantities'}
 return {'value':next(iter(values))if values else 1,'basis':'sku_name_explicit'if values else 'user_default_one'}

def purchase_quantity(sales_units,supplier_units=1):
 if type(sales_units)is not int or sales_units<1 or type(supplier_units)is not int or supplier_units<1:raise ValueError('invalid quantity')
 return (sales_units+supplier_units-1)//supplier_units

def normalize_variants(rows):
 if not isinstance(rows,list)or len(rows)>300:raise ValueError('invalid variants')
 clean=[]
 for r in rows:
  sku=str(r.get('sku_id')or'');labels=[x[:200]for x in r.get('labels',[])if isinstance(x,str)][:30]
  images=[]
  for url in r.get('images',[])[:20]:
   if not isinstance(url,str):continue
   u=urlsplit(url)
   if u.scheme=='https'and any(u.hostname==h or (u.hostname or'').endswith('.'+h)for h in ['alicdn.com','1688.com']):images.append(url)
  clean.append({'sku_id':sku if re.fullmatch(r'\d+',sku)else None,'labels':labels,'specification_text':str(r.get('specification_text',''))[:1000],'images':images,'specs':{str(k)[:100]:str(v)[:300]for k,v in (r.get('specs')or{}).items()}if isinstance(r.get('specs'),dict)else{},'supplier_attributes':r.get('supplier_attributes',[])if isinstance(r.get('supplier_attributes'),list)else[],'sales_unit_quantity':contents_quantity(' '.join(labels)),'extraction_status':str(r.get('extraction_status','unknown'))[:100],'property_paths':[{'name':str(p.get('name',''))[:60],'value':str(p.get('value',''))[:1000]}for p in r.get('property_paths',[])[:12]if isinstance(p,dict)],'option_image_binding_verified':bool(images and labels and r.get('option_image_binding_verified')is True),'image_binding_verified':bool(re.fullmatch(r'\d+',sku)and images and r.get('image_binding_verified')is True and r.get('image_binding_source')in ('dom_explicit_sku_row','structured_explicit_sku_record','normal_page_sku_selector_record')),'match_verified':False,'identity_verified':bool(re.fullmatch(r'\d+',sku))})
 return clean

def preserve_visual_reviews(old_rows,new_rows):
 def key(v):return (v.get('sku_id'),tuple(v.get('images',[])),tuple(v.get('labels',[])),v.get('specification_text',''))
 old={key(v):v for v in old_rows}
 for v in new_rows:
  previous=old.get(key(v),{})
  if previous.get('automatic_visual_review'):v['automatic_visual_review']=previous['automatic_visual_review']
 return new_rows

def normalize_inventory_rows(rows):
 if not isinstance(rows,list)or len(rows)>2000 or any(not isinstance(r,dict)for r in rows):raise ValueError('invalid variant inventory')
 result=[]
 for offset in range(0,len(rows),300):result.extend(normalize_variants(rows[offset:offset+300]))
 return result
