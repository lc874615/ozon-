"""Bounded on-disk cache of successful exact-image assessments, without source images."""
import json,sqlite3,time
from pathlib import Path
CACHE_PATH=Path(__file__).resolve().parents[1]/'data'/'visual-result-cache.sqlite3'
MAX_ROWS=5000
TTL=7*24*3600

def cached_result(key):
 try:
  if not CACHE_PATH.exists():return None
  with sqlite3.connect(CACHE_PATH,timeout=2)as db:
   row=db.execute('SELECT created,visual FROM assessments WHERE key=?',(key,)).fetchone()
  if not row or not 0<=time.time()-row[0]<TTL:return None
  value=json.loads(row[1]);return value if isinstance(value,dict)else None
 except (OSError,ValueError,sqlite3.Error):return None

def save_result(key,visual):
 try:
  CACHE_PATH.parent.mkdir(parents=True,exist_ok=True)
  with sqlite3.connect(CACHE_PATH,timeout=2)as db:
   db.execute('CREATE TABLE IF NOT EXISTS assessments(key TEXT PRIMARY KEY,created REAL,visual TEXT)')
   db.execute('INSERT OR REPLACE INTO assessments VALUES(?,?,?)',(key,time.time(),json.dumps(visual,ensure_ascii=False)))
   db.execute('DELETE FROM assessments WHERE created<?',(time.time()-TTL,))
   db.execute('DELETE FROM assessments WHERE key IN (SELECT key FROM assessments ORDER BY created DESC LIMIT -1 OFFSET ?)',(MAX_ROWS,))
 except (OSError,ValueError,sqlite3.Error):pass
