param([ValidateSet('qwen3-vl:2b','qwen2.5vl:3b')][string]$Model = 'qwen3-vl:2b', [ValidateSet(0,768,1024,1280)][int]$MaxEdge = 1024)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
Write-Host 'Before switching, finish or pause visual tasks and close the old workbench.'
Write-Host ('Preparing local vision: Ollama + ' + $Model + ', inference max edge ' + $MaxEdge)
Write-Host 'Qwen3-VL 2B downloads about 1.9 GB; the 3B alternative is larger. Inference stays local.'
$ollamaCommand = Get-Command ollama -ErrorAction SilentlyContinue
$ollamaPath = if ($ollamaCommand) { $ollamaCommand.Source } else { Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama.exe' }
if (-not (Test-Path $ollamaPath)) {
    $installer = Join-Path $env:TEMP 'Ozon-OllamaSetup.exe'
    Write-Host 'Downloading the official Windows installer...'
    Invoke-WebRequest -Uri 'https://ollama.com/download/OllamaSetup.exe' -OutFile $installer -UseBasicParsing
    $signature = Get-AuthenticodeSignature -FilePath $installer
    if ($signature.Status -ne 'Valid') { throw 'Installer signature is not valid. Installation stopped.' }
    Write-Host ('Verified signer: ' + $signature.SignerCertificate.Subject)
    Start-Process -FilePath $installer -Wait
    if (-not (Test-Path $ollamaPath)) {
        $ollamaCommand = Get-Command ollama -ErrorAction SilentlyContinue
        if ($ollamaCommand) { $ollamaPath = $ollamaCommand.Source }
    }
    if (-not (Test-Path $ollamaPath)) { throw 'Ollama installation not found. Complete installation and run setup again.' }
}
$localApi = 'http://127.0.0.1:11434'
try { $null = Invoke-RestMethod -Uri "$localApi/api/tags" -TimeoutSec 3 }
catch {
    $env:OLLAMA_HOST = '127.0.0.1:11434'
    Start-Process -FilePath $ollamaPath -ArgumentList 'serve' -WindowStyle Minimized
    $ready = $false
    for ($attempt = 0; $attempt -lt 20; $attempt++) {
        Start-Sleep -Seconds 1
        try { $null = Invoke-RestMethod -Uri "$localApi/api/tags" -TimeoutSec 2; $ready = $true; break } catch {}
    }
    if (-not $ready) { throw 'Local Ollama API did not start. Check Ollama logs.' }
}
Write-Host 'Downloading/verifying model. Existing model blobs will be reused.'
& $ollamaPath pull $Model
if ($LASTEXITCODE -ne 0) { throw 'Model download failed. Update Ollama from https://ollama.com/download if the model is unsupported, then rerun setup.' }
$showBody = @{ model = $Model } | ConvertTo-Json
$show = Invoke-RestMethod -Uri "$localApi/api/show" -Method Post -ContentType 'application/json' -Body $showBody -TimeoutSec 15
if ($show.capabilities -notcontains 'vision') { throw 'Downloaded model did not report vision capability.' }
$pythonCommand = Get-Command python -ErrorAction SilentlyContinue
$pythonPrefix = @()
if ($pythonCommand) { $pythonExe = $pythonCommand.Source } else {
    $pythonCommand = Get-Command py -ErrorAction SilentlyContinue
    if (-not $pythonCommand) { throw 'Python is required. Install Python and rerun setup.' }
    $pythonExe = $pythonCommand.Source; $pythonPrefix = @('-3')
}
if ($MaxEdge -gt 0) {
    & $pythonExe @pythonPrefix -c 'import importlib.util,sys; sys.exit(0 if importlib.util.find_spec("PIL") else 1)'
    if ($LASTEXITCODE -ne 0) {
        & $pythonExe @pythonPrefix -m pip install --user 'Pillow>=10.4,<13'
        if ($LASTEXITCODE -ne 0) { throw 'Image resize dependency installation failed.' }
    }
}
$dataPath = Join-Path $PSScriptRoot 'data'
New-Item -ItemType Directory -Force -Path $dataPath | Out-Null
@{ provider = 'ollama'; model = $Model; inference_max_edge = $MaxEdge; base_url = $localApi; real_product_validation_passed = $false } | ConvertTo-Json | Set-Content -Encoding UTF8 -Path (Join-Path $dataPath 'local-vision.json')
try {
    $oldModel = if ($Model -eq 'qwen3-vl:2b') { 'qwen2.5vl:3b' } else { 'qwen3-vl:2b' }
    $unloadBody = @{ model = $oldModel; keep_alive = 0; stream = $false } | ConvertTo-Json
    $null = Invoke-RestMethod -Uri "$localApi/api/generate" -Method Post -ContentType 'application/json' -Body $unloadBody -TimeoutSec 10
} catch { Write-Host 'Previous model was not loaded or could not be unloaded; Ollama will manage model memory.' }
Write-Host 'Local model is installed and API is reachable. Product matching accuracy is NOT yet validated.'
Write-Host 'Close the old workbench and run start.bat. Then run the local image comparison test.'
