@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup-local-vision.ps1" -Model "qwen3-vl:2b" -MaxEdge 1024
if errorlevel 1 echo Setup failed. Read the error; the model switch was not completed.
pause
