@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup-local-vision.ps1" -Model "qwen2.5vl:3b" -MaxEdge 0
if errorlevel 1 echo Setup failed. Read the error; the model switch was not completed.
pause
