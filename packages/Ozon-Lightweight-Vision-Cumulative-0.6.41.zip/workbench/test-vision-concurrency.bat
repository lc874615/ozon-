@echo off
cd /d "%~dp0"
python -c "import sys" >nul 2>nul
if errorlevel 1 (
  py -3 -u benchmark-local-vision.py
) else (
  python -u benchmark-local-vision.py
)
if errorlevel 1 echo Benchmark failed. Read the error above; no production settings were changed.
pause
