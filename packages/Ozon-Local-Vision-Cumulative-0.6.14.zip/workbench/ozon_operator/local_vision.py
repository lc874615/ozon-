"""Loopback-only Ollama visual inference; no hosted inference fallback."""
import base64,json,urllib.request,urllib.error,threading
from pathlib import Path
from urllib.parse import urlsplit
from .vision_matcher import SCHEMA,validated_visual_result,build_payload
LOCK=threading.Lock()
MODEL='qwen2.5vl:3b'
BASE='http://127.0.0.1:11434'

def enabled():
 p=Path(__file__).resolve().parents[1]/'data'/'local-vision.json'
 try:return json.loads(p.read_text(encoding='utf-8-sig')).get('provider')=='ollama'
 except (OSError,ValueError):return False

def local_json(path,payload=None,timeout=5):
 request=urllib.request.Request(BASE+path,data=None if payload is None else json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
 with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(request,timeout=timeout)as r:
  raw=r.read(1000001)
  if len(raw)>1000000:raise ValueError('oversize local response')
  return json.loads(raw)

def status():
 result={'provider':'ollama','model':MODEL,'configured':enabled(),'automatic_vision_connected':False,'local_service':True,'credentials_configured':False}
 if not result['configured']:return result
 try:
  models=local_json('/api/tags').get('models',[])
  result['model_available']=any(x.get('name')==MODEL or x.get('model')==MODEL for x in models)
  result['service_reachable']=True
  result['automatic_vision_connected']=result['model_available']
 except (OSError,ValueError):result['service_reachable']=False
 result['real_product_validation_passed']=False
 return result

def allowed_image(url):
 u=urlsplit(url)
 return u.scheme=='https'and u.port in (None,443)and not u.username and not u.password and any(u.hostname==h or (u.hostname or'').endswith('.'+h)for h in ['alicdn.com','1688.com','ozonstatic.cn','ozonstatic.ru','ozonstatic.com'])

class ImageRedirects(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl):
  if not allowed_image(newurl):raise ValueError('image redirect outside product CDN')
  return super().redirect_request(req,fp,code,msg,headers,newurl)

def read_image(url):
 if not allowed_image(url):raise ValueError('unsupported product image host')
 request=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0','Accept':'image/png,image/jpeg,image/webp'})
 with urllib.request.build_opener(ImageRedirects()).open(request,timeout=15)as r:
  if not allowed_image(r.url):raise ValueError('image source changed')
  raw=r.read(12000001)
 if len(raw)>12000000 or not (raw.startswith(b'\xff\xd8\xff')or raw.startswith(b'\x89PNG\r\n\x1a\n')or(raw[:4]==b'RIFF'and raw[8:12]==b'WEBP')):raise ValueError('unsupported or oversized image')
 return base64.b64encode(raw).decode('ascii')

def compare_local(ozon_image,sku_images,attributes,policy,image_reader=None,transport=None):
 if not LOCK.acquire(blocking=False):return {'status':'vision_busy','profit_allowed':False}
 try:
  if not sku_images or not ozon_image:return {'status':'both_source_images_required','profit_allowed':False}
  if len(sku_images)>6:return {'status':'too_many_sku_images_for_one_review','profit_allowed':False}
  image_reader=image_reader or read_image
  images=[image_reader(u)for u in [ozon_image,*sku_images]]
  prompt=build_payload(ozon_image,sku_images,attributes,policy,MODEL)['messages'][0]['content']
  text='\n'.join(x['text']for x in prompt if x['type']=='text')+'\nReturn JSON using schema: '+json.dumps(SCHEMA)
  payload={'model':MODEL,'messages':[{'role':'user','content':text,'images':images}],'format':SCHEMA,'stream':False,'options':{'temperature':0,'num_ctx':8192,'num_predict':2048},'keep_alive':'5m'}
  response=(transport or (lambda p:local_json('/api/chat',p,timeout=180)))(payload)
  if response.get('done')is not True:raise ValueError('incomplete inference')
  visual=validated_visual_result(json.loads(response['message']['content']))
  return {'status':'visual_assessment_read','provider':'ollama','model':MODEL,'visual':visual,'profit_allowed':False,'dimension_verification':'separate_required','selected_sku_identity_verification':'separate_required','image_count':len(images),'hosted_inference_used':False}
 except (OSError,ValueError,TypeError,KeyError,IndexError):return {'status':'local_vision_image_or_inference_failed','profit_allowed':False}
 finally:LOCK.release()
