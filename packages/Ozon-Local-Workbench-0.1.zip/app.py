import json,secrets,sqlite3,webbrowser,threading
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from ozon_operator.collection_handoff import build_source_queue
ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data';DATA.mkdir(exist_ok=True)
KEY=DATA/'pairing-key.txt'
if not KEY.exists():KEY.write_text(secrets.token_urlsafe(32))
TOKEN=KEY.read_text().strip()
def db():
 c=sqlite3.connect(DATA/'tasks.sqlite3');c.execute('CREATE TABLE IF NOT EXISTS tasks(sku TEXT PRIMARY KEY, payload TEXT NOT NULL)');return c
class Handler(BaseHTTPRequestHandler):
 def allowed(self):
  origin=self.headers.get('Origin','')
  return not origin or origin=='http://127.0.0.1:8765' or origin.startswith('chrome-extension://')
 def reply(self,status,payload,typ='application/json'):
  raw=payload.encode() if isinstance(payload,str) else json.dumps(payload,ensure_ascii=False).encode()
  self.send_response(status);self.send_header('Content-Type',typ+'; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
  origin=self.headers.get('Origin','')
  if self.allowed() and origin:self.send_header('Access-Control-Allow-Origin',origin);self.send_header('Vary','Origin')
  self.end_headers();self.wfile.write(raw)
 def do_OPTIONS(self):
  if not self.allowed():return self.reply(403,{'error':'origin_denied'})
  self.send_response(204);self.send_header('Access-Control-Allow-Origin',self.headers.get('Origin',''));self.send_header('Access-Control-Allow-Headers','Content-Type, X-Pairing-Key');self.send_header('Access-Control-Allow-Methods','POST, GET, OPTIONS');self.end_headers()
 def do_GET(self):
  if self.headers.get('Host')!='127.0.0.1:8765' or not self.allowed():return self.reply(403,{'error':'local_access_only'})
  if self.path=='/':return self.reply(200,(ROOT/'index.html').read_text(), 'text/html')
  if self.path=='/api/tasks':
   with db() as c:rows=[json.loads(r[0])for r in c.execute('SELECT payload FROM tasks')]
   return self.reply(200,{'jobs':rows,'capabilities':{'local_import':True,'supplier_automatic_search':False,'automatic_visual_matching':False,'remote_sync':False}})
  if self.path=='/api/pair' and self.headers.get('Origin','') in ('','http://127.0.0.1:8765'):return self.reply(200,{'key':TOKEN})
  self.reply(404,{'error':'not_found'})
 def do_POST(self):
  if self.headers.get('Host')!='127.0.0.1:8765' or not self.allowed() or not secrets.compare_digest(self.headers.get('X-Pairing-Key',''),TOKEN):return self.reply(403,{'error':'pairing_required'})
  try:
   size=int(self.headers.get('Content-Length','0'))
   if size<=0 or size>20000000:return self.reply(413,{'error':'size_limit'})
   data=json.loads(self.rfile.read(size))
   if self.path!='/api/import':return self.reply(404,{'error':'not_found'})
   queue=build_source_queue(data)
   with db() as c:
    for task in queue['jobs']:c.execute('INSERT OR IGNORE INTO tasks VALUES (?,?)',(task['ozon_sku'],json.dumps(task,ensure_ascii=False)))
   return self.reply(200,{'accepted':queue['collection_passed_count']})
  except (ValueError,TypeError,KeyError):return self.reply(400,{'error':'invalid_report'})
 def log_message(self,*args):pass
if __name__=='__main__':
 with db():pass
 server=ThreadingHTTPServer(('127.0.0.1',8765),Handler)
 threading.Timer(1,lambda:webbrowser.open('http://127.0.0.1:8765')).start()
 print('Ozon workbench: http://127.0.0.1:8765 — Ctrl+C to stop')
 server.serve_forever()
