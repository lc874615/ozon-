import json,secrets,sqlite3,webbrowser,threading
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from ozon_operator.collection_handoff import build_source_queue
ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data';DATA.mkdir(exist_ok=True)
KEY=DATA/'pairing-key.txt'
if not KEY.exists():KEY.write_text(secrets.token_urlsafe(32),encoding='utf-8')
API_SECRETS={}  # Process memory only; never serialized or logged.
TOKEN=KEY.read_text(encoding='utf-8').strip()
def db():
 c=sqlite3.connect(DATA/'tasks.sqlite3');c.execute('CREATE TABLE IF NOT EXISTS tasks(sku TEXT PRIMARY KEY, payload TEXT NOT NULL)');return c
class Handler(BaseHTTPRequestHandler):
 def allowed(self):
  origin=self.headers.get('Origin','')
  return not origin or origin=='http://127.0.0.1:8765' or origin.startswith('chrome-extension://')
 def reply(self,status,payload,typ='application/json'):
  raw=payload.encode() if isinstance(payload,str) else json.dumps(payload,ensure_ascii=False).encode()
  self.send_response(status);self.send_header('Content-Type',typ+'; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
  origin=self.headers.get('Origin','')
  if self.allowed() and origin:self.send_header('Access-Control-Allow-Origin',origin);self.send_header('Vary','Origin')
  self.end_headers();self.wfile.write(raw)
 def do_OPTIONS(self):
  if not self.allowed():return self.reply(403,{'error':'origin_denied'})
  self.send_response(204);self.send_header('Access-Control-Allow-Origin',self.headers.get('Origin',''));self.send_header('Access-Control-Allow-Headers','Content-Type, X-Pairing-Key');self.send_header('Access-Control-Allow-Methods','POST, GET, OPTIONS');self.end_headers()
 def do_GET(self):
  if self.headers.get('Host')!='127.0.0.1:8765' or not self.allowed():return self.reply(403,{'error':'local_access_only'})
  if self.path=='/':return self.reply(200,(ROOT/'index.html').read_text(encoding='utf-8'), 'text/html')
  if self.path=='/api/1688/config':
   f=DATA/'1688-api-config.json';config=json.loads(f.read_text(encoding='utf-8')) if f.exists() else {};return self.reply(200,{'config':config,'secret_in_memory':bool(API_SECRETS.get('app_secret')),'token_in_memory':bool(API_SECRETS.get('access_token')),'api_authorization_verified':False,'image_search_verified':False,'detail_verified':False,'freight_verified':False})
  if self.path=='/api/1688-status':
   f=DATA/'1688-status.json';return self.reply(200,json.loads(f.read_text(encoding='utf-8')) if f.exists() else {'status':'unknown','reason':'尚未收到浏览器状态'})
  if self.path=='/api/tasks':
   with db() as c:rows=[json.loads(r[0])for r in c.execute('SELECT payload FROM tasks')]
   return self.reply(200,{'jobs':rows,'capabilities':{'local_import':True,'supplier_automatic_search':False,'automatic_visual_matching':False,'remote_sync':False}})
  if self.path=='/api/pair' and self.headers.get('Origin','') in ('','http://127.0.0.1:8765'):return self.reply(200,{'key':TOKEN})
  self.reply(404,{'error':'not_found'})
 def do_POST(self):
  if self.headers.get('Host')!='127.0.0.1:8765' or not self.allowed() or not secrets.compare_digest(self.headers.get('X-Pairing-Key',''),TOKEN):return self.reply(403,{'error':'pairing_required'})
  try:
   size=int(self.headers.get('Content-Length','0'))
   if size<=0 or size>20000000:return self.reply(413,{'error':'size_limit'})
   data=json.loads(self.rfile.read(size))
   if self.path=='/api/1688/config':
    from urllib.parse import urlparse
    app_key=str(data.get('app_key','')).strip();url=str(data.get('official_authorization_url','')).strip()
    if app_key and (len(app_key)>100 or not app_key.isalnum()):return self.reply(400,{'error':'invalid_app_key'})
    if url:
     u=urlparse(url)
     if u.scheme!='https' or not(u.hostname=='open.1688.com' or u.hostname=='auth.1688.com'):return self.reply(400,{'error':'仅接受官方确认的open.1688.com或auth.1688.com授权链接'})
     if any(x in u.query.lower() for x in ['access_token','app_secret','refresh_token']):return self.reply(400,{'error':'授权链接不能包含密钥或Token'})
    config={'app_key':app_key,'official_authorization_url':url,'solution':'self_developed_cross_border_procurement','requested_capabilities':['image_search','product_detail','sku_price','domestic_freight']}
    for k in ['app_secret','access_token']:
     if data.get(k):API_SECRETS[k]=str(data[k])
    (DATA/'1688-api-config.json').write_text(json.dumps(config,ensure_ascii=False),encoding='utf-8')
    return self.reply(200,{'saved':True,'authorization_verified':False,'note':'仅保存配置，不代表授权或接口验证成功；密钥仅存内存，重启后需重新输入'})
   if self.path=='/api/1688/check':
    f=DATA/'1688-api-config.json';config=json.loads(f.read_text(encoding='utf-8')) if f.exists() else {}
    checks={'app_key_configured':bool(config.get('app_key')),'secret_available':bool(API_SECRETS.get('app_secret')),'token_available':bool(API_SECRETS.get('access_token')),'authorization_link_configured':bool(config.get('official_authorization_url')),'official_api_contract_verified':False,'remote_api_test_executed':False}
    return self.reply(200,{'checks':checks,'status':'awaiting_official_access','next':'等待官方明确接入资格、授权方式及图搜/详情/运费接口文档；未发送远程请求'})
   if self.path=='/api/1688-status':
    if data.get('status') not in ['logged_in_page','login_required','unknown','page_closed']:return self.reply(400,{'error':'invalid_status'})
    from datetime import datetime,timezone
    safe={k:data.get(k) for k in ['status','reason','observed_at']};safe['received_at']=datetime.now(timezone.utc).isoformat();(DATA/'1688-status.json').write_text(json.dumps(safe,ensure_ascii=False),encoding='utf-8');return self.reply(200,{'accepted':True})
   if self.path!='/api/import':return self.reply(404,{'error':'not_found'})
   queue=build_source_queue(data)
   with db() as c:
    for task in queue['jobs']:c.execute('INSERT OR IGNORE INTO tasks VALUES (?,?)',(task['ozon_sku'],json.dumps(task,ensure_ascii=False)))
   return self.reply(200,{'accepted':queue['collection_passed_count']})
  except (ValueError,TypeError,KeyError):return self.reply(400,{'error':'invalid_report'})
 def log_message(self,*args):pass
if __name__=='__main__':
 with db():pass
 server=ThreadingHTTPServer(('127.0.0.1',8765),Handler)
 threading.Timer(1,lambda:webbrowser.open('http://127.0.0.1:8765')).start()
 print('Ozon workbench: http://127.0.0.1:8765 — Ctrl+C to stop')
 server.serve_forever()
