import json,secrets,sqlite3,webbrowser,threading
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from ozon_operator.collection_handoff import build_source_queue
from ozon_operator.source_triage import triage_task
ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data';DATA.mkdir(exist_ok=True)
KEY=DATA/'pairing-key.txt'
if not KEY.exists():KEY.write_text(secrets.token_urlsafe(32),encoding='utf-8')
TOKEN=KEY.read_text(encoding='utf-8').strip()
def db():
 c=sqlite3.connect(DATA/'tasks.sqlite3');c.execute('CREATE TABLE IF NOT EXISTS tasks(sku TEXT PRIMARY KEY, payload TEXT NOT NULL)');return c
class Handler(BaseHTTPRequestHandler):
 def allowed(self):
  origin=self.headers.get('Origin','')
  return not origin or origin=='http://127.0.0.1:8765' or origin.startswith('chrome-extension://')
 def reply(self,status,payload,typ='application/json'):
  raw=payload.encode() if isinstance(payload,str) else json.dumps(payload,ensure_ascii=False).encode()
  self.send_response(status);self.send_header('Content-Type',typ+'; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
  origin=self.headers.get('Origin','')
  if self.allowed() and origin:self.send_header('Access-Control-Allow-Origin',origin);self.send_header('Vary','Origin')
  self.end_headers();self.wfile.write(raw)
 def do_OPTIONS(self):
  if not self.allowed():return self.reply(403,{'error':'origin_denied'})
  self.send_response(204);self.send_header('Access-Control-Allow-Origin',self.headers.get('Origin',''));self.send_header('Access-Control-Allow-Headers','Content-Type, X-Pairing-Key');self.send_header('Access-Control-Allow-Methods','POST, GET, OPTIONS');self.end_headers()
 def do_GET(self):
  if self.headers.get('Host')!='127.0.0.1:8765' or not self.allowed():return self.reply(403,{'error':'local_access_only'})
  if self.path=='/':return self.reply(200,(ROOT/'index.html').read_text(encoding='utf-8'), 'text/html')
  if self.path=='/api/1688-status':
   f=DATA/'1688-status.json';return self.reply(200,json.loads(f.read_text(encoding='utf-8')) if f.exists() else {'status':'unknown','reason':'尚未收到浏览器状态'})
  if self.path=='/api/tasks':
   with db() as c:rows=[triage_task(json.loads(r[0]))for r in c.execute('SELECT payload FROM tasks')]
   return self.reply(200,{'jobs':rows,'capabilities':{'local_import':True,'supplier_automatic_search':False,'automatic_visual_matching':False,'remote_sync':False}})
  if self.path=='/api/pair' and self.headers.get('Origin','') in ('','http://127.0.0.1:8765'):return self.reply(200,{'key':TOKEN})
  self.reply(404,{'error':'not_found'})
 def do_POST(self):
  if self.headers.get('Host')!='127.0.0.1:8765' or not self.allowed() or not secrets.compare_digest(self.headers.get('X-Pairing-Key',''),TOKEN):return self.reply(403,{'error':'pairing_required'})
  try:
   size=int(self.headers.get('Content-Length','0'))
   if size<=0 or size>20000000:return self.reply(413,{'error':'size_limit'})
   data=json.loads(self.rfile.read(size))
   if self.path=='/api/supplier-package':
    sku=str(data.get('ozon_sku',''));offer=str(data.get('offer_id',''))
    with db() as c:
     row=c.execute('SELECT payload FROM tasks WHERE sku=?',(sku,)).fetchone()
     if not row:return self.reply(404,{'error':'工作台没有该Ozon SKU'})
     task=json.loads(row[0]);offers=task.get('supplier_offers',[]);matches=[o for o in offers if str(o.get('offer_id'))==offer]
     if len(matches)!=1:return self.reply(409,{'error':'当前供应商不在该SKU的图搜候选中，不能关联'})
     matches[0]['package_observation']={'packaging':data.get('packaging'),'attributes':data.get('attributes',[]),'selected_sku_identity_verified':False,'source':'decisionAttrService'}
     c.execute('UPDATE tasks SET payload=? WHERE sku=?',(json.dumps(task,ensure_ascii=False),sku))
    return self.reply(200,{'accepted':True,'profit_eligible':False})
   if self.path=='/api/supplier-candidates':
    import re
    sku=str(data.get('ozon_sku',''));offers=data.get('offers',[])
    if not re.fullmatch(r'\d+',sku) or not isinstance(offers,list) or len(offers)>100:return self.reply(400,{'error':'invalid_candidates'})
    with db() as c:
     old=c.execute('SELECT payload FROM tasks WHERE sku=?',(sku,)).fetchone()
     if not old:return self.reply(404,{'error':'Ozon SKU尚未进入工作台'})
     task=json.loads(old[0]);safe=[]
     for o in offers:
      if not isinstance(o,dict) or not re.fullmatch(r'\d+',str(o.get('offer_id',''))):continue
      item={k:o.get(k)for k in ['offer_id','title','image','candidate_sku_id','search_moq_labels','free_shipping_tag_observed']};item.update({'url':'https://detail.1688.com/offer/'+str(o['offer_id'])+'.html','cost_verified':False,'match_verified':False,'discovery_method':'1688_image_search'});safe.append(item)
     task['supplier_offers']=safe;task['source_search_status']='candidates_received';task['image_binding_verified']=False;task['tasks']=list(set(task.get('tasks',[])+['verify_query_image_matches_ozon_sku','verify_material_quantity_selected_sku_and_freight']))
     task=triage_task(task)
     c.execute('UPDATE tasks SET payload=? WHERE sku=?',(json.dumps(task,ensure_ascii=False),sku))
    return self.reply(200,{'accepted':len(safe),'profit_calculated':False})
   if self.path=='/api/1688-status':
    if data.get('status') not in ['logged_in_page','login_required','unknown','page_closed']:return self.reply(400,{'error':'invalid_status'})
    from datetime import datetime,timezone
    safe={k:data.get(k) for k in ['status','reason','observed_at']};safe['received_at']=datetime.now(timezone.utc).isoformat();(DATA/'1688-status.json').write_text(json.dumps(safe,ensure_ascii=False),encoding='utf-8');return self.reply(200,{'accepted':True})
   if self.path!='/api/import':return self.reply(404,{'error':'not_found'})
   queue=build_source_queue(data)
   with db() as c:
    for task in queue['jobs']:c.execute('INSERT OR IGNORE INTO tasks VALUES (?,?)',(task['ozon_sku'],json.dumps(task,ensure_ascii=False)))
   return self.reply(200,{'accepted':queue['collection_passed_count']})
  except (ValueError,TypeError,KeyError):return self.reply(400,{'error':'invalid_report'})
 def log_message(self,*args):pass
if __name__=='__main__':
 with db():pass
 server=ThreadingHTTPServer(('127.0.0.1',8765),Handler)
 threading.Timer(1,lambda:webbrowser.open('http://127.0.0.1:8765')).start()
 print('Ozon workbench: http://127.0.0.1:8765 — Ctrl+C to stop')
 server.serve_forever()
