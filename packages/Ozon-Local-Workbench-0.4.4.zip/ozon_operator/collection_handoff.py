"""Convert collector diagnostics to a supplier-work queue; never invent offers or profit."""
import re

def build_source_queue(report):
    jobs=[]
    for row in report.get('job',{}).get('result',{}).get('results',[]):
        if row.get('status')!='api_data_complete':continue
        buyer=row.get('buyer',{});attrs=buyer.get('attributes',[]);values=[]
        for item in attrs:
            if re.fullmatch(r'Количество (?:в упаковке|в комплекте|предметов в комплекте)(?:,?\s*шт\.?)?|包装数量|每套数量|套装数量',str(item.get('name','')).strip(),re.I):
                v=str(item.get('value','')).strip()
                if re.fullmatch(r'[1-9]\d*',v):values.append(int(v))
                else:values.append(None)
        unique=set(values);qty=next(iter(unique)) if len(unique)==1 and None not in unique else None
        jobs.append({'ozon_sku':row['sku'],'title':buyer.get('title'),'images':buyer.get('images',[]),'attributes':attrs,'units_per_sales_sku':qty,'reference_price_cny':buyer.get('reference_price'),'competitor_packaging':row.get('packaging'),'source_search_status':'pending','profit_status':'not_calculated','minimum_margin':'0.25','tasks':[] if qty else ['verify_sales_pack_quantity'],'supplier_offers':[]})
    return {'schema_version':1,'source_task_id':report.get('job',{}).get('id'),'collection_passed_count':len(jobs),'jobs':jobs,'automation_status':'handoff_only_supplier_access_and_private_transport_not_connected'}
