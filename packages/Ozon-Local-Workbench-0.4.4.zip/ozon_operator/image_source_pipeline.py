"""Image-search-only source selection and evidence-gated sales-margin calculation."""
from decimal import Decimal as D
from .supplier_selection import select_sources
from .cost_engine import assess_market_price
from .strict_supplier_gate import supplier_match_gate

def choose_image_source(offers):
    accepted=[];rejected=[]
    for offer in offers:
        if offer.get('discovery_method')!='1688_image_search' or not offer.get('image_search_evidence'):
            rejected.append({'offer_id':offer.get('offer_id'),'reason':'not_verified_image_search_result'});continue
        try:
            score=D(str(offer['verified_similarity_score']))
            if not score.is_finite() or not 0<=score<=1 or not offer.get('similarity_evidence'):raise ValueError()
        except (KeyError,ValueError,ArithmeticError):
            rejected.append({'offer_id':offer.get('offer_id'),'reason':'similarity_unverified'});continue
        accepted.append(offer)
    ranked=select_sources(accepted)
    eligible=ranked.get('eligible',[])
    if eligible:
        best=max(D(str(o['verified_similarity_score']))for o in eligible)
        group=[o for o in eligible if D(str(o['verified_similarity_score']))==best]
        selected=min(group,key=lambda o:D(o['landed_domestic_cost_cny']))
    else:selected=None
    return {'selected':selected,'eligible':eligible,'source_rejections':rejected,'selection_diagnostics':ranked,'status':'selected' if selected else 'needs_evidence','publication_approved':False}

def evaluate_selected_source(selection, sale_cny, commission_rate, ogl_cny, evidence, parcels=1):
    source=selection.get('selected')
    gate=supplier_match_gate(evidence.get('ozon_sku'),source.get('offer_id')if source else None,source.get('sku_id')if source else None,evidence.get('image_match_findings')or{})
    missing=[]
    if not gate['profit_allowed']:missing.append('selected_sku_images_and_semantics_not_verified')
    if not source:missing.append('matched_supplier_missing')
    for k in ['commission_applicability_verified','ogl_channel_and_package_verified','fx_and_rule_currency_verified','source_sales_unit_cost_verified']:
        if evidence.get(k) is not True:missing.append(k)
    if commission_rate is None:missing.append('commission_unknown')
    if ogl_cny is None:missing.append('ogl_unknown')
    if not isinstance(parcels,int) or parcels<1:missing.append('parcel_count_unknown')
    if missing:return {'status':'hold','unresolved':missing,'publication_approved':False}
    return assess_market_price(sale_cny,{'procurement':source['sku_price_cny'],'domestic_freight':source['domestic_freight_cny'],'ogl_logistics':ogl_cny,'label_fee':str(parcels)}, {'commission':commission_rate,'last_mile':'0.02','withdrawal':'0.012','fx_reserve':'0.03'})
