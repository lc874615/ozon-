"""Normalize observed calculatePrice totals. No signed query/account data retained."""
import json,re
from decimal import Decimal,InvalidOperation

def parse_quote(request,response):
    def amount(v):
        x=Decimal(str(v))
        if not x.is_finite() or x<0:raise ValueError('invalid amount')
        return x
    try:
        if not any(str(x).startswith('SUCCESS')for x in response.get('ret',[])):raise ValueError('business not successful')
        lines=request['skuCalParams'];lines=json.loads(lines)if isinstance(lines,str)else lines
        if len(lines)!=1:raise ValueError('multi SKU requires line allocation')
        line=lines[0];sku=str(line['skuId']);offer=str(request['offerId']);qty=amount(line['number'])
        if qty<=0 or qty!=qty.to_integral_value()or not re.fullmatch(r'\d+',sku)or not re.fullmatch(r'\d+',offer):raise ValueError('identity or quantity')
        data=response['data'];final=amount(data['totalFinalPrice']);original=amount(data['totalOriginalPrice']);discount=amount(data['totalDiscount'])
        if original-final!=discount:raise ValueError('discount arithmetic inconsistent')
        free=data.get('freePostage')is True
        return {'status':'quantity_quote_read','offer_id':offer,'sku_id':sku,'spec_id':line.get('specId'),'purchase_quantity':int(qty),'currency':'CNY','goods_total_cny':str(final),'goods_original_total_cny':str(original),'order_discount_cny':str(discount),'effective_unit_goods_cny':str(final/qty),'free_shipping_for_this_quote':free,'domestic_freight_cny':'0'if free else None,'goods_plus_freight_cny':str(final)if free else None,'quote_reuse_scope':'exact selected SKU, quantity and current buyer/promotion conditions; requery other quantities','material_structure_match_verified':False,'sales_pack_quantity_match_verified':False,'raw_tracking_or_account_data_retained':False}
    except (KeyError,TypeError,ValueError,InvalidOperation,json.JSONDecodeError)as e:
        return {'status':'quote_unverified','reason':str(e),'domestic_freight_cny':None}
