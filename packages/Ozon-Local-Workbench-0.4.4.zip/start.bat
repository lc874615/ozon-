@echo off
cd /d "%~dp0"
python -u app.py
if errorlevel 1 py -3 -u app.py
pause
