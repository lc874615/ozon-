"""Evidence gate: semantic verification must precede any profit evaluation."""
import re
from .match_policy import DEFAULT_POLICY,evaluate_dimensions,current_policy

def supplier_match_gate(ozon_sku,offer_id,sku_id,findings):
    required=['style_structure','color','material','image_text_labels','sku_variant','sales_pack_quantity']
    pending=[];rejected=[]
    policy=current_policy()
    if findings.get('ozon_reference_role')!='collected_main_image':pending.append('collected_main_image_reference_required')
    dimensions=evaluate_dimensions(findings.get('product_dimensions'),policy['dimension_tolerance_percent'])
    pending.extend('dimension:'+x for x in dimensions['pending']);rejected.extend('dimension:'+x for x in dimensions['rejected'])
    if policy['color']=='near_exact' and findings.get('color_difference')not in ('same',None):rejected.append('color_outside_policy')
    if policy['material']=='documented' and not findings.get('material_document_evidence'):pending.append('material_document_evidence_required')
    if findings.get('selected_sku_image_binding_verified')is not True:pending.append('sku_image_binding_unverified')
    if str(findings.get('ozon_sku'))!=str(ozon_sku)or str(findings.get('offer_id'))!=str(offer_id)or str(findings.get('sku_id'))!=str(sku_id):pending.append('image_evidence_identity_unverified')
    if not findings.get('ozon_image_evidence')or not findings.get('selected_sku_image_evidence'):pending.append('both_source_images_required')
    checks=findings.get('checks',{})
    for key in required:
        item=checks.get(key,{})
        if item.get('decision')=='mismatch':rejected.append(key)
        elif item.get('decision')!='match'or not item.get('evidence'):pending.append(key)
    return {'status':'reject'if rejected else 'hold'if pending else 'verified_match','profit_allowed':not pending and not rejected,'rejected':rejected,'pending':pending,'supplier_url':'https://detail.1688.com/offer/'+str(offer_id)+'.html'if re.fullmatch(r'\d+',str(offer_id))else None,'note':'Search ranking or generic product-cover image cannot replace selected-SKU image verification.'}
