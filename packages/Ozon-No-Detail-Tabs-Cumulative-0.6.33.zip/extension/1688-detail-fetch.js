// Service-worker-only, read-only HTML acquisition. No tab, DOM execution, or signed request replay.
function parse1688DetailHtml(html,offerId){
 const offer=String(offerId),roots=[];let truncated=false;
 const balanced=(text,start)=>{
  let depth=0,quoted=false,escape=false;
  for(let i=start;i<text.length&&i-start<8000000;i++){
   const c=text[i];if(quoted){if(escape)escape=false;else if(c==='\\')escape=true;else if(c==='"')quoted=false;continue;}
   if(c==='"')quoted=true;else if(c==='{'||c==='[')depth++;else if(c==='}'||c===']'){if(--depth===0)return text.slice(start,i+1);}
  }return null;
 };
 const parseLiteral=text=>{
  // Only normalize JS's numeric object keys; never evaluate expressions/functions.
  let out='',quoted=false,escape=false;
  for(let i=0;i<text.length;i++){
   const c=text[i];out+=c;
   if(quoted){if(escape)escape=false;else if(c==='\\')escape=true;else if(c==='"')quoted=false;continue;}
   if(c==='"'){quoted=true;continue;}
   if(c==='{'||c===','){
    const m=text.slice(i+1).match(/^(\s*)(\d+)(\s*):/);
    if(m){out+=m[1]+'"'+m[2]+'"'+m[3]+':';i+=m[0].length;}
   }
  }
  return JSON.parse(out);
 };
 for(const match of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script\s*>/gi)){
  if(roots.length>=60){truncated=true;break;}
  const attrs=match[1],text=match[2].trim();if(text.length>8000000){truncated=true;continue;}
  if(/(?:application\/(?:ld\+)?json|__NEXT_DATA__)/i.test(attrs))try{roots.push(JSON.parse(text));}catch{}
  const contextStart=text.indexOf('})(window.contextPath,');
  if(contextStart>=0){const start=contextStart+'})(window.contextPath,'.length;const json=balanced(text,start);if(json)try{roots.push(parseLiteral(json));}catch{}}
  for(const assignment of text.matchAll(/(?:window\.)?(?:__INIT_DATA__|__INIT_DATA|__INITIAL_STATE__|__NEXT_DATA__|detailData|offerData)\s*=\s*/g)){
   const start=assignment.index+assignment[0].length;if(!['{','['].includes(text[start]))continue;
   const json=balanced(text,start);if(json)try{roots.push(parseLiteral(json));}catch{}
  }
 }
 const variants=new Map(),options=new Map(),shapes=new Set(),skuModels=[];let nodes=0;
 const image=value=>{if(typeof value!=='string'||!value.trim())return null;try{const u=new URL(value,'https://detail.1688.com');return u.protocol==='https:'&&!u.username&&!u.password&&/(^|\.)(alicdn\.com|1688\.com)$/.test(u.hostname)?u.href:null;}catch{return null;}};
 const visit=(o,path,depth)=>{
  if(!o||typeof o!=='object')return;if(depth>24||++nodes>40000){truncated=true;return;}
  if(!Array.isArray(o)){
   const declared=o.offerId??o.offerID;if(declared!=null&&String(declared)!==offer)return;
   if(Array.isArray(o.skuProps)&&o.skuInfoMap&&typeof o.skuInfoMap==='object')skuModels.push(o);
   if(/sku|spec|prop/i.test(path)){
    const images=[...new Set(['skuImageUrl','skuImgUrl','skuPicUrl','imageUrl','picUrl','image','imgUrl','originalImageUrl'].map(k=>image(o[k])).filter(Boolean))];
    const labels=[...new Set(['skuName','specName','name','valueName','value','label'].map(k=>typeof o[k]==='string'?o[k].trim():null).filter(v=>v&&v.length<250))];
    const sku=String(o.skuId??o.skuID??'');
    if(/^\d+$/.test(sku)){
     const row={sku_id:sku,labels,images,specification_text:labels.join(' / '),identity_verified:true,image_binding_verified:images.length>0,image_binding_source:images.length?'structured_explicit_sku_record':null,extraction_status:images.length?'html_explicit_sku_image':'html_sku_image_missing'};
     if(!variants.has(sku)||variants.get(sku).images.length<images.length)variants.set(sku,row);
    }else if(images.length&&labels.length){
     const key=labels.join(' / ')+'|'+images.join('|');
     options.set(key,{sku_id:null,labels,images,specification_text:labels.join(' / '),option_key:key,option_image_binding_verified:true,image_binding_verified:false,identity_verified:false,extraction_status:'html_same_property_record_image'});
    }
    if(sku||images.length)shapes.add(Object.keys(o).filter(k=>!/token|sign|secret|user|cookie|account/i.test(k)).slice(0,20).sort().join(','));
   }
  }
  const entries=Object.entries(o);if(entries.length>3000)truncated=true;
  for(const [key,value]of entries.slice(0,3000)){
   if(/token|sign|secret|cookie|account|buyer|seller|shop|order|address|recommend|related|review|rate|tracking/i.test(key))continue;
   if(value&&typeof value==='object')visit(value,path+'.'+key,depth+1);
  }
 };
 for(const root of roots)visit(root,'root',0);
 const decode=value=>String(value||'').replace(/&gt;/g,'>').replace(/&lt;/g,'<').replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&amp;/g,'&');
 let observedSkuMapCount=0,mappedImages=0;
 for(const model of skuModels){
  const map=Object.entries(model.skuInfoMap);observedSkuMapCount+=map.length;
  for(const [key,record]of map){
   if(!record||typeof record!=='object')continue;const sku=String(record.skuId??record.skuID??'');if(!/^\d+$/.test(sku))continue;
   const attrs=decode(record.specAttrs||key).split('>').map(v=>v.trim());
   if(attrs.length!==model.skuProps.length)continue;
   const matches=model.skuProps.map((prop,i)=>(Array.isArray(prop.value)?prop.value:[]).filter(value=>decode(value.name).trim()===attrs[i]));
   if(matches.some(values=>values.length!==1))continue;
   const urls=[...new Set(matches.flatMap(values=>['imageUrl','skuImageUrl','picUrl','image'].map(k=>image(values[0][k])).filter(Boolean)))];
   const old=variants.get(sku);if(!old)continue;
   old.labels=attrs;old.specification_text=attrs.join(' / ');old.property_paths=[{name:'skuInfoMap_key',value:decode(key)}];
   if(!old.images.length&&urls.length===1){old.images=urls;old.image_binding_verified=true;old.image_binding_source='structured_explicit_sku_record';old.extraction_status='html_exact_sku_property_path_image';mappedImages++;}
  }
 }
 const rows=[...variants.values()].slice(0,2000),opts=[...options.values()].slice(0,2000);
 return {status:rows.length||opts.length?'supplier_variants_observed':'detail_html_requires_runtime_data',offer_id:offer,variants:rows,spec_options:opts,shared_image_groups:[],structured_roots:roots.length,quantity_control_count:0,scan_limited:truncated||variants.size>2000||options.size>2000,all_variants_verified:false,completeness:'background_html_discovered_records_total_inventory_not_proven',observed_sku_map_count:observedSkuMapCount,exact_property_image_mappings:mappedImages,network_inventory_status:'background_html',network_schema_shapes:[...shapes].slice(0,30),transport:'background_html',profit_eligible:false};
}
async function fetch1688DetailWithoutTab(offerId){
 if(!/^\d+$/.test(String(offerId)))return {status:'invalid_offer_id'};
 const target='https://detail.1688.com/offer/'+offerId+'.html';
 try{
  const response=await fetch(target,{credentials:'include',signal:AbortSignal.timeout(15000),redirect:'follow'});
  if([403,429].includes(response.status))return {status:'detail_fetch_restricted',http_status:response.status};
  const u=new URL(response.url||target);
  if(/(?:^|\.)(?:login|passport|punish)\./i.test(u.hostname)||/\/captcha|\/punish|\/signin/i.test(u.pathname))return {status:'detail_fetch_verification_required'};
  if(u.hostname!=='detail.1688.com'||u.pathname!=='/offer/'+offerId+'.html')return {status:'detail_fetch_wrong_offer',route:{host:u.hostname,path:u.pathname}};
  if(!response.ok)return {status:'detail_fetch_http_error',http_status:response.status};
  if(Number(response.headers.get('content-length'))>8000000)return {status:'detail_fetch_size_limit'};
  let raw='';if(response.body?.getReader){const reader=response.body.getReader(),decoder=new TextDecoder();let size=0;try{while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>8000000){await reader.cancel();return {status:'detail_fetch_size_limit'};}raw+=decoder.decode(value,{stream:true});}raw+=decoder.decode();}finally{reader.releaseLock();}}
  else{raw=await response.text();if(raw.length>8000000)return {status:'detail_fetch_size_limit'};}
  const title=raw.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]||'';
  if(/登录|安全验证|验证码|captcha|sign.?in/i.test(title))return {status:'detail_fetch_verification_required'};
  const parsed=parse1688DetailHtml(raw,String(offerId));
  if(parsed.status!=='supplier_variants_observed'&&/(?:baxia-dialog|nc-container|请完成验证|访问验证)/i.test(raw))return {status:'detail_fetch_verification_required'};
  return parsed;
 }catch(e){return {status:e?.name==='TimeoutError'||e?.name==='AbortError'?'detail_fetch_timeout':'detail_fetch_failed'};}
}
