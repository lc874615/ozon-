"""Only reject explicitly comparable physical dimensions or role-specific materials."""
import re

def material(value):
 t=str(value).lower()
 found=set()
 for kind,pat in [('pu',r'人造革|pu皮|科技皮|экокож|эко.кож|искусственн.*кож'),('velvet',r'绒布|绒面|велюр|бархат'),('linen',r'亚麻|л[её]н'),('fabric',r'布料|织物|ткан'),('real_leather',r'真皮|натуральн.*кож'),('leather',r'皮革|\bleather\b|\bкожа\b'),('metal',r'金属|металл'),('wood',r'实木|木质|дерев'),('plastic',r'塑料|пластик'),('foam',r'海绵|поролон'),('latex',r'乳胶|латекс')]:
  if re.search(pat,t):found.add(kind)
 if found&{'velvet','linen'}:found.discard('fabric')
 if found&{'pu','real_leather'}:found.discard('leather')
 return next(iter(found))if len(found)==1 else None

def facts(attributes,specs=None):
 out={}
 def put(k,v):
  if v is None:return
  if k in out and out[k]!=v:out[k]=None
  elif k not in out:out[k]=v
 rows=list(attributes or[])+[{'name':k,'value':v}for k,v in (specs or{}).items()]
 for a in rows:
  if not isinstance(a,dict):continue
  name=str(a.get('name')or a.get('title')or a.get('key')or'').strip().lower()
  if re.search(r'包装|包裹|упаков|package|shipping',name):continue
  value=a.get('value');vals=a.get('values')
  if value is None and isinstance(vals,list)and len(vals)==1:value=vals[0]
  if not isinstance(value,(str,int,float)):continue
  val=str(value)
  feature='has_armrests'if name in ('有无扶手','наличие подлокотников','подлокотники')else'foldable'if name in ('是否可折叠','可折叠','складной','складная конструкция')else None
  if feature:
   token=val.strip().lower()
   if token in ('有','是','да','есть','yes','true'):put(feature,True)
   elif token in ('无','否','нет','no','false'):put(feature,False)
  if name in ('комплектация','配件清单','套装包含')and re.search(r'подуш|抱枕',val,re.I)and not re.search(r'без|无|不含',val,re.I):put('has_pillow',True)
  role='frame_material'if name in ('框架','框架材质','支架材质','материал каркаса','frame material')else'upholstery_material'if name in ('面料','面料材质','饰面材质','материал обивки','upholstery material')else'filling_material'if name in ('内部填充物','填充物','наполнитель','filling')else None
  # The site's "尺寸" property sometimes actually describes upholstery; never parse it as physical size.
  if name=='尺寸'and material(val)in ('velvet','fabric','linen','leather','pu','real_leather'):role='upholstery_material'
  if role:put(role,material(val))
  axis=None
  for key,pattern in [('height_mm',r'^(?:产品高度|商品高度|椅子高度|高度|высота)(?:[ ,，]*(?:mm|cm|мм|см|毫米|厘米))?$'),('width_mm',r'^(?:产品宽度|商品宽度|宽度|ширина)(?:[ ,，]*(?:mm|cm|мм|см|毫米|厘米))?$'),('length_mm',r'^(?:产品长度|商品长度|长度|длина)(?:[ ,，]*(?:mm|cm|мм|см|毫米|厘米))?$'),('depth_mm',r'^(?:产品深度|商品深度|深度|глубина)(?:[ ,，]*(?:mm|cm|мм|см|毫米|厘米))?$')]:
   if re.fullmatch(pattern,name):axis=key;break
  if axis:
   match=re.fullmatch(r'\s*(\d+(?:[.,]\d+)?)\s*(mm|cm|мм|см|毫米|厘米)?\s*',val,re.I)
   unit=match.group(2)if match else None
   if not unit:
    u=re.search(r'(mm|cm|мм|см|毫米|厘米)$',name);unit=u.group(1)if u else None
   if match and unit:
    n=float(match.group(1).replace(',','.'))*(10 if unit.lower()in ('cm','см','厘米')else 1)
    if n>0:put(axis,n)
 return out

def compatible(a,b):
 return a==b or (a=='fabric'and b in ('velvet','linen'))or(b=='fabric'and a in ('velvet','linen'))or(a=='leather'and b in ('pu','real_leather'))or(b=='leather'and a in ('pu','real_leather'))

def conflict(task,v):
 reference=facts(task.get('attributes',[]));supplier=facts(v.get('supplier_attributes',[]),v.get('specs',{}))
 label=' '.join(v.get('labels')or[])
 if '无抱枕'in label:supplier['has_pillow']=False
 elif '带抱枕'in label:supplier['has_pillow']=True
 for key,a in reference.items():
  b=supplier.get(key)
  if a is None or b is None:continue
  if key in ('has_armrests','foldable','has_pillow')and a!=b:return {'field':key,'ozon':a,'supplier':b,'reason':'明确配件或结构功能冲突：'+key+' '+str(a)+' / '+str(b)}
  if key.endswith('_mm')and abs(a-b)/a>0.0200000001:return {'field':key,'ozon':a,'supplier':b,'reason':'同含义产品尺寸差异超过2%（毫米）：'+str(a)+' / '+str(b)}
  if key.endswith('_material')and not compatible(a,b):return {'field':key,'ozon':a,'supplier':b,'reason':'同部位材质明确冲突：'+key+' '+a+' / '+b}
 return None
