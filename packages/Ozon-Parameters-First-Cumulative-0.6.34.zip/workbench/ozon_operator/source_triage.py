"""Conservative lead triage. Search evidence never establishes final SKU costs."""
import re
from decimal import Decimal,InvalidOperation

def triage_offer(offer):
    reasons=[];title=str(offer.get('title',''))
    # Explicit accessory/product nouns only; not price or keyword similarity.
    if re.search(r'地毯|椅子套(?:罩)?|椅套(?:罩)?|凳套',title):reasons.append('非整椅候选：标题指向地毯或椅套，暂不参与成本比较')
    for label in offer.get('search_moq_labels')or[]:
        m=re.fullmatch(r'\s*(\d+)件起批\s*',str(label))
        if m and int(m[1])>1:reasons.append('起批量超过1件：待核实具体SKU是否允许1件采购')
    price=None
    try:
        p=Decimal(str(offer.get('search_price_cny')))
        if p.is_finite() and p>0:price=str(p)
    except (ValueError,InvalidOperation):pass
    return {**offer,'triage_status':'hold_from_cost_shortlist' if reasons else 'detail_verification_pending','triage_reasons':reasons,'cost_verified':False,'match_verified':False,'search_price_cny':None,'freight_status':'free_shipping_tag_needs_sku_scope_check' if offer.get('free_shipping_tag_observed') else 'unknown_not_zero','required_checks':['query_image_binding','whole_product_structure','material','sku_specification','sales_pack_quantity','selected_sku_moq','selected_sku_price','domestic_freight'],'profit_eligible':False}

def triage_task(task):
    # Apply chair-specific title rules only to chair tasks.
    title=str(task.get('title','')).lower();chair=bool(re.search(r'стул|椅',title))
    offers=[]
    for offer in task.get('supplier_offers',[]):
        if chair:offers.append(triage_offer(offer))
        else:
            item=triage_offer({**offer,'title':''});item['title']=offer.get('title','');offers.append(item)
    from .spec_shortlist import rank_profit_candidates
    from .match_policy import current_policy
    shortlist=rank_profit_candidates({**task,'supplier_offers':offers},current_policy())
    from .visual_automation import summarize_spec_visuals,visual_result_view
    from .visual_prefilter import reference_facts,prefilter
    from .parameter_prefilter import facts as parameter_facts
    from .visual_automation import review_fingerprint
    for o in offers:
        for v in o.get('detail_spec_options',[])+o.get('detail_variants',[]):
            quick=prefilter(task,v)
            if quick:v['automatic_visual_review']={'fingerprint':review_fingerprint((task.get('images')or[None])[0],v.get('images',[]),current_policy()),'assessment':quick,'state':'visual_reject','profit_eligible':False}
            v['visual_result_view']=visual_result_view(task,v,current_policy())
    visual_summary=summarize_spec_visuals({**task,'supplier_offers':offers},current_policy())
    reference_parameters=parameter_facts(task.get('attributes',[]))
    supplier_parameters=[parameter_facts(o.get('detail_attributes',[]),v.get('specs',{}))for o in offers for v in o.get('detail_variants',[])]
    coverage={'ozon_product_dimension_axes':sum(k.endswith('_mm')and v is not None for k,v in reference_parameters.items()),'supplier_specs_with_product_dimensions':sum(any(k.endswith('_mm')and v is not None for k,v in f.items())for f in supplier_parameters),'supplier_specs_with_material':sum(any(k.endswith('_material')and v is not None for k,v in f.items())for f in supplier_parameters),'reference_parameters':reference_parameters}
    return {**task,'parameter_prefilter_coverage':coverage,'visual_prefilter_reference':reference_facts(task),'spec_shortlist':shortlist,'spec_visual_summary':visual_summary,'supplier_offers':offers,'triage_summary':{'total':len(offers),'held':sum(o['triage_status']=='hold_from_cost_shortlist'for o in offers),'pending_details':sum(o['triage_status']=='detail_verification_pending'for o in offers)}}
