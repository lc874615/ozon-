"""Local hardware and saved timing samples. No credentials or local paths exported."""
import shutil,subprocess
from .local_vision import local_json,MODEL

def performance_report(tasks):
 gpu=[];binary=shutil.which('nvidia-smi')
 if binary:
  try:
   r=subprocess.run([binary,'--query-gpu=name,memory.total,memory.used,driver_version','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=4)
   if r.returncode==0:
    for line in r.stdout.splitlines()[:8]:
     fields=[x.strip()for x in line.split(',')]
     if len(fields)==4:gpu.append(dict(zip(['name','total_memory_mib','used_memory_mib','driver'],fields)))
  except (OSError,subprocess.TimeoutExpired):pass
 running=[]
 try:running=[{k:m.get(k)for k in ['name','size','size_vram','context_length']}for m in local_json('/api/ps',timeout=2).get('models',[])if m.get('name')==MODEL]
 except (OSError,ValueError):pass
 samples=[];seen=set()
 for task in tasks:
  for offer in task.get('supplier_offers',[]):
   for field in ['detail_variants','detail_spec_options','unbound_detail_images']:
    for v in offer.get(field,[]):
     review=v.get('automatic_visual_review')or{};assessment=review.get('assessment')or{};fp=review.get('fingerprint')
     if not fp or fp in seen or assessment.get('status')!='visual_assessment_read':continue
     seen.add(fp);samples.append({'ozon_sku':task.get('ozon_sku'),'offer_id':offer.get('offer_id'),'elapsed_ms':assessment.get('elapsed_ms'),'cache_hit':assessment.get('inference_cache_hit',False),'timing':assessment.get('timing',{})})
 small_gpu=any('1050'in g['name']for g in gpu)
 return {'small_gpu_profile':small_gpu,'model':MODEL,'gpu':gpu,'loaded_model':running,'saved_timing_samples':samples[-100:],'scope':'saved_visual_result_timings_not_whole_pipeline_wall_time','tenfold_speed_verified':False,'experimental_fast_mode_default':False}
