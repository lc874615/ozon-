"""Resumable visual stage. Review images first; never infer SKU identity from similarity."""
import hashlib,json
from .visual_prefilter import prefilter,prefilter_key
from .local_vision import compare_local,MODEL
REVISION='visual-prefilter-original-quality-v5'

def review_fingerprint(main_image,images,policy):
 return hashlib.sha256(json.dumps([REVISION,MODEL,main_image,images,policy],sort_keys=True,ensure_ascii=False).encode()).hexdigest()

def visual_batch(task,policy,compare=None,emit=None):
 compare=compare or compare_local
 main=(task.get('images')or[None])[0]
 if not main:return {'status':'blocked','reason':'ozon_main_image_missing','evaluated':0}
 if not task.get('supplier_offers'):return {'status':'blocked','reason':'supplier_candidates_missing','evaluated':0}
 counts={'missing_sku_images':0,'missing_detail_inventory':0,'inventory_incomplete':sum(o.get('all_variants_verified')is not True for o in task.get('supplier_offers',[])),'evaluated':0,'reused':0,'visual_pass':0,'visual_reject':0,'pending':0,'identity_pending':0,'prefilter_rejected':0};events=[];run_cache={}
 work=[]
 for offer in task.get('supplier_offers',[]):
  variants=[('detail_variants',i,v)for i,v in enumerate(offer.get('detail_variants')or[])]+[('detail_spec_options',i,v)for i,v in enumerate(offer.get('detail_spec_options')or[])]+[('unbound_detail_images',i,v)for i,v in enumerate(offer.get('unbound_detail_images')or[])]
  if not variants:counts['pending']+=1;counts['missing_detail_inventory']+=1;continue
  for collection,index,v in variants:work.append((offer,collection,index,v,prefilter(task,v)))
 # Finish and publish all deterministic rejections before any model request.
 work.sort(key=lambda entry:entry[4]is None)
 for offer,collection,index,v,quick in work:
  images=v.get('images')or[]
  if not images:counts['pending']+=1;counts['missing_sku_images']+=1;continue
  fp=review_fingerprint(main,images,policy);old=v.get('automatic_visual_review')or{}
  if quick:
   result=quick;counts['prefilter_rejected']+=1
  elif old.get('fingerprint')==fp and old.get('assessment',{}).get('status')=='visual_assessment_read':
   result=old['assessment'];counts['reused']+=1;run_cache[fp]=result
  elif fp in run_cache:
   result=run_cache[fp];counts['reused']+=1
  else:
   result=compare(main,images,{},policy);counts['evaluated']+=1
   if result.get('status')=='visual_assessment_read':run_cache[fp]=result
  bound=bool(v.get('sku_id')and v.get('identity_verified')is True and v.get('image_binding_verified')is True)
  visual=result.get('visual',{})
  if result.get('status')=='prefilter_rejected':state='visual_reject';counts['visual_reject']+=1
  elif result.get('status')!='visual_assessment_read':state='model_or_image_pending';counts['pending']+=1
  elif visual.get('visual_match_allowed')is True:
   counts['visual_pass']+=1
   if bound:state='visual_pass_sku_bound'
   else:state='visual_pass_sku_identity_pending';counts['identity_pending']+=1
  elif any(visual.get(k)=='mismatch'for k in ('structure','local_details','color')):
   state='visual_reject';counts['visual_reject']+=1
  else:state='visual_reject';counts['visual_reject']+=1
  event={'offer_id':str(offer.get('offer_id')),'variant_index':index,'variant_collection':collection,'sku_id':v.get('sku_id'),'fingerprint':fp,'state':state,'assessment':result,'source_images':{'ozon_main_image':main,'supplier_sku_images':images},'profit_eligible':False}
  events.append(event)
  if emit:emit(event)
  if result.get('status')=='vision_busy':return {'status':'paused','reason':'vision_busy',**counts}
 if counts['evaluated']+counts['reused']+counts['prefilter_rejected']==0:return {'status':'waiting_for_detail_images','reason':'no_comparable_detail_images','next_action':'sync_open_candidate_detail_pages',**counts,'profit_eligible':False}
 return {'status':'visual_stage_finished_other_stages_pending',**counts,'profit_eligible':False}

def visual_result_view(task,variant,policy):
 """Binary exclusion result; never describe a technical failure as observed difference."""
 images=variant.get('images')or[]
 if not images:return {'result':'不符','reason':'缺少对应规格图片，本次不纳入备选；需补抓','retryable':True}
 review=variant.get('automatic_visual_review')or{}
 if review.get('fingerprint')!=review_fingerprint((task.get('images')or[None])[0],images,policy):return {'result':None,'reason':'尚未按当前规则完成比对','retryable':True}
 assessment=review.get('assessment')or{}
 if assessment.get('status')=='prefilter_rejected':
  if assessment.get('prefilter_key')!=prefilter_key(task,variant):return {'result':None,'reason':'预筛依据已变化，等待重新核验','retryable':True}
  return {'result':'不符','reason':'AI前预筛：'+assessment.get('reason','明确属性冲突'),'retryable':False}
 if assessment.get('failure_reason')=='high_resolution_image_required':return {'result':'不符','reason':'未取得对应清晰规格原图（短边至少600像素），需补抓；未使用缩略图作判断','retryable':True}
 if assessment.get('status')!='visual_assessment_read':return {'result':'不符','reason':'图片读取或模型核验失败，本次不纳入备选；非已证实外观不同','retryable':True}
 visual=assessment.get('visual')or{}
 if visual.get('visual_match_allowed')is True:return {'result':'通过','reason':visual.get('explanation',{}).get('overall','可见结构、细节及颜色符合视觉标准'),'retryable':False}
 different=any(visual.get(k)=='mismatch'for k in ('structure','local_details','color'))
 return {'result':'不符','reason':visual.get('explanation',{}).get('overall')or('可见外观存在差异'if different else'视觉证据未达到通过标准'),'retryable':not different}

def summarize_spec_visuals(task,policy):
 counts={'named_specs':0,'passed':0,'rejected':0,'unknown':0,'waiting':0,'retryable_rejected':0,'offers_missing_named_specs':0,'all_specs_read_verified':False,'offers_inventory_unproven':sum(o.get('all_variants_verified')is not True for o in task.get('supplier_offers',[]))}
 for offer in task.get('supplier_offers',[]):
  options=offer.get('detail_spec_options')or[]
  if not options:counts['offers_missing_named_specs']+=1;continue
  for v in options:
   counts['named_specs']+=1
   view=visual_result_view(task,v,policy)
   if view['result']=='通过':counts['passed']+=1
   elif view['result']=='不符':
    counts['rejected']+=1
    if view['retryable']:counts['retryable_rejected']+=1
   else:counts['waiting']+=1
 return counts
