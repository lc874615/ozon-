"""CPU-only exclusion of explicit, role-bound appearance contradictions. Never passes a SKU."""
import re,hashlib,json
REVISION='appearance-prefilter-v1'
COLORS={'grey':r'灰|\bgr[ae]y\b|сер(?:ый|ая|ое|ые|ого)', 'black':r'黑|\bblack\b|ч[её]рн', 'white':r'白|\bwhite\b|бел(?:ый|ая|ое|ые|ого)', 'pink':r'粉|\bpink\b|розов', 'blue':r'蓝|\bblue\b|син(?:ий|яя|ее)|голуб', 'green':r'绿|\bgreen\b|зел[её]н', 'purple':r'紫|\bpurple\b|фиолет', 'brown':r'棕|咖|\bbrown\b|коричнев', 'gold':r'金(?!属|丝)|\bgold\b|золот', 'silver':r'银|\bsilver\b|серебр'}
def color(value):
 found={k for k,p in COLORS.items()if re.search(p,str(value),re.I)}
 return next(iter(found))if len(found)==1 else None

def reference_facts(task):
 facts={}
 for a in task.get('attributes',[]):
  if not isinstance(a,dict):continue
  name=str(a.get('name')or a.get('title')or a.get('key')or'').strip().lower()
  value=a.get('value')
  if not isinstance(value,(str,int,float)):continue
  role='body_color'if name in ('颜色','主体颜色','椅身颜色','цвет','цвет товара','цвет обивки','body color')else'leg_color'if name in ('椅腿颜色','支架颜色','цвет ножек','leg color')else None
  if role and color(value):
   if role in facts and facts[role]!=color(value):facts[role]=None
   elif role not in facts:facts[role]=color(value)
 return facts

def prefilter_key(task,v):
 return hashlib.sha256(json.dumps([REVISION,reference_facts(task),v.get('labels'),v.get('images'),v.get('extraction_status'),v.get('image_binding_verified'),v.get('option_image_binding_verified')],sort_keys=True,ensure_ascii=False).encode()).hexdigest()

def prefilter(task,v):
 label=' '.join(v.get('labels')or[])
 reliable=v.get('image_binding_verified')is True or v.get('option_image_binding_verified')is True or v.get('extraction_status')=='named_option_image_sku_combination_pending'
 if not reliable or not label or not v.get('images'):return None
 # Supplier first attribute must explicitly contain body color; color elsewhere cannot identify the body.
 body=re.split(r'[-—【\[（(]',label,maxsplit=1)[0]
 legs=re.search(r'([黑金银白灰棕咖])\s*(?:色)?腿',label)
 supplied={'body_color':color(body),'leg_color':color(legs.group(1))if legs else None}
 for role,expected in reference_facts(task).items():
  observed=supplied.get(role)
  if expected and observed and expected!=observed:
   part='主体颜色'if role=='body_color'else'椅腿颜色'
   return {'status':'prefilter_rejected','prefilter_revision':REVISION,'prefilter_key':prefilter_key(task,v),'reason':part+'明确冲突：Ozon采集属性='+expected+'；对应规格='+observed,'evidence':{'basis':'collected_ozon_attribute_and_bound_spec_label','part':part,'ozon':expected,'supplier':observed,'supplier_label':label},'profit_allowed':False,'ai_called':False}
 return None
