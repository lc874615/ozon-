/* document_start, MAIN world: observe only the page's ordinary SKU-selector response.
   No request replay, signed URLs, account identifiers or raw response persistence. */
(()=>{
 if(window.__ozonSkuSelectorObserverInstalled)return;window.__ozonSkuSelectorObserverInstalled=true;
 const pageOffer=()=>location.hostname==='detail.1688.com'&&location.pathname.match(/^\/offer\/(\d+)\.html$/)?.[1];
 const target=url=>{try{return /\/mtop\.1688\.wosc\.queryofferskuselectormodel\//i.test(new URL(url,location.href).pathname);}catch{return false;}};
 const safeImage=u=>{if(typeof u!=='string'||!u)return null;try{const x=new URL(u,location.href);return x.protocol==='https:'&&/(^|\.)(alicdn\.com|1688\.com)$/.test(x.hostname)?x.href:null;}catch{return null;}};
 const sanitize=(response,offer)=>{
  if(!offer||offer!==pageOffer())return;
  if(!Array.isArray(response.ret)||!response.ret.some(x=>String(x).startsWith('SUCCESS'))){window.__ozonSkuSelectorInventory={status:'selector_response_not_successful',offer_id:offer};return;}
  const variants=[],properties=[],shapes=[],seen=new WeakSet();let nodes=0,limited=false;
  const walk=(o,path,depth)=>{
   if(!o||typeof o!=='object'||seen.has(o))return;if(depth>20||++nodes>25000){limited=true;return;}seen.add(o);
   if(/sku|spec|prop|model/i.test(path)){
    const images=[...new Set(['skuImageUrl','skuImgUrl','skuPicUrl','imageUrl','picUrl','image','imgUrl'].map(k=>safeImage(o[k])).filter(Boolean))];
    const labels=['skuName','specName','name','value','valueName','label'].map(k=>typeof o[k]==='string'?o[k].trim():'').filter(v=>v&&v.length<250);
    const sku=String(o.skuId||o.skuID||'');
    const propertyValues=['specAttrs','skuAttrs','skuPropIds','propPath','specPath'].map(k=>({name:k,value:typeof o[k]==='string'?o[k].slice(0,1000):null})).filter(x=>x.value);
    if(/^\d+$/.test(sku))variants.push({sku_id:sku,labels,images,specification_text:labels.join(' / '),property_paths:propertyValues,identity_verified:true,image_binding_verified:images.length>0,image_binding_source:images.length?'normal_page_sku_selector_record':null,extraction_status:images.length?'selector_sku_image':'selector_sku_image_missing'});
    else if(images.length)properties.push({labels,images,property_value_id:String(o.valueId||o.vid||o.propValueId||'').slice(0,100),binding_verified:false,source:'normal_page_selector_property'});
    if(shapes.length<100)shapes.push({path:path.slice(0,200),keys:Object.keys(o).filter(k=>!/user|buyer|seller|account|token|sign|secret|session|address|cookie|trace/i.test(k)).slice(0,40)});
   }
   for(const [k,v]of Object.entries(o))if(!/user|buyer|seller|member|account|token|sign|secret|session|address|cookie|trace|order|rating|review/i.test(k)&&v&&typeof v==='object')walk(v,path+'.'+k,depth+1);
  };
  walk(response.data,'selector_model',0);
  const unique=new Map();for(const v of variants){const old=unique.get(v.sku_id);if(!old||v.images.length>old.images.length)unique.set(v.sku_id,v);}
  window.__ozonSkuSelectorInventory={status:'selector_inventory_observed',offer_id:offer,variants:[...unique.values()].slice(0,2000),property_images:properties.slice(0,2000),schema_shapes:shapes,scan_limited:limited||unique.size>2000,all_variants_verified:false,observed_at:new Date().toISOString()};
 };
 const offerFrom=(url,body)=>{
  try{const u=new URL(url,location.href);let raw=u.searchParams.get('data');if(!raw&&typeof body==='string')raw=new URLSearchParams(body).get('data');if(!raw&&body instanceof URLSearchParams)raw=body.get('data');if(!raw&&body instanceof FormData)raw=body.get('data');const d=JSON.parse(raw||'{}');return /^\d+$/.test(String(d.offerId))?String(d.offerId):null;}catch{return null;}
 };
 const originalOpen=XMLHttpRequest.prototype.open,originalSend=XMLHttpRequest.prototype.send,meta=new WeakMap();
 XMLHttpRequest.prototype.open=function(method,url,...rest){meta.delete(this);if(target(url))meta.set(this,String(url));return originalOpen.call(this,method,url,...rest);};
 XMLHttpRequest.prototype.send=function(body){const url=meta.get(this);if(url){const offer=offerFrom(url,body);if(offer)this.addEventListener('load',()=>{try{sanitize(this.responseType==='json'?this.response:JSON.parse(this.responseText),offer);}catch{}},{once:true});}return originalSend.call(this,body);};
 const originalFetch=window.fetch;
 if(typeof originalFetch==='function')window.fetch=async function(input,init){
  const url=typeof input==='string'?input:input?.url;const response=await originalFetch.apply(this,arguments);
  if(target(url)){try{const offer=offerFrom(url,init?.body);if(offer)response.clone().json().then(r=>sanitize(r,offer)).catch(()=>{});}catch{}}
  return response;
 };
})();
