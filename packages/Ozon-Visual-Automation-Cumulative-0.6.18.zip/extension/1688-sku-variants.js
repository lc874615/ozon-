function supplierContentsQuantity(name,unitText=''){
 const text=String(name)+' '+String(unitText),found=[];
 for(const m of text.matchAll(/(?:^|[^\d.])(\d+)\s*(?:件|个|把|只|张|支|条|枚|双|对)(?:\s*(?:装|套装|组合|\/套|每套))?/g)){
  const n=Number(m[1]);if(Number.isSafeInteger(n)&&n>0)found.push(n);
 }
 const distinct=[...new Set(found)];
 return distinct.length>1?{value:null,basis:'conflicting_explicit_quantities'}:distinct.length?{value:distinct[0],basis:'sku_name_or_unit_explicit'}:{value:1,basis:'user_default_one'};
}
function collect1688SkuVariants(){
 const offer=location.hostname==='detail.1688.com'&&location.pathname.match(/^\/offer\/(\d+)\.html$/)?.[1];
 if(!offer)return {status:'detail_page_required'};
 const safeImage=u=>{if(typeof u!=='string'||!u.trim())return null;try{const x=new URL(u,location.href);return x.protocol==='https:'&&/(^|\.)(alicdn\.com|1688\.com)$/.test(x.hostname)?x.href:null;}catch{return null;}};
 const rows=[],diagnostics=[],sharedImageGroups=[];const seen=new Set();
 const selector='input.ant-input-number-input,input[role="spinbutton"]';
 const inputs=[...document.querySelectorAll(selector)].filter(e=>e.getClientRects().length);
 const imagesOf=node=>[...new Set([...node.querySelectorAll('img')].flatMap(i=>[i.currentSrc,i.getAttribute('src'),i.getAttribute('data-src'),i.getAttribute('data-lazy-src')]).map(safeImage).filter(Boolean))];
 const meaningful=t=>/[\u4e00-\u9fffA-Za-zА-Яа-я]/.test(t)&&!/^(?:库存|数量|起批|件|个|把|￥|¥|元|价格|单价|可售|剩余|\d|\s|[.,:+-])+$/.test(t);
 for(const input of inputs){
  let row=null,p=input.parentElement,group=null;const path=[];
  for(let depth=0;p&&depth<16;depth++,p=p.parentElement){
   if(p===document.body||p===document.documentElement)break;
   const controls=p.querySelectorAll(selector).length;
   const text=(p.innerText||'').trim();
   path.push({tag:p.tagName?.toLowerCase(),classes:typeof p.className==='string'?p.className.slice(0,250):'',quantity_controls:controls,image_count:p.querySelectorAll('img').length,text_length:text.length});
   if(controls>1){group=p;break;}
   if(controls===1&&text.length<=1500&&meaningful(text)&&!/ant-input-number(?:-|$)/.test(p.className||''))row=p;
  }
  // Preserve every control even when its surrounding labels/images are absent.
  const origin=row||input.parentElement;
  diagnostics.push({control_index:inputs.indexOf(input),row_found:!!row,path});
  if(seen.has(origin))continue;seen.add(origin);
  const ids=new Set();
  for(const e of [origin,...origin.querySelectorAll('[data-sku-id],[data-skuid],[data-sku]')])for(const a of ['data-sku-id','data-skuid','data-sku']){const v=e.getAttribute(a);if(/^\d+$/.test(v||''))ids.add(v);}
  const sku=ids.size===1?[...ids][0]:null;
  const labelNodes=[...origin.querySelectorAll('[title],img[alt],[class*="sku-name"],[class*="spec-name"],[class*="item-name"],[class*="prop-name"]')];
  const labels=[...new Set(labelNodes.map(e=>e.getAttribute('title')||e.getAttribute('alt')||e.innerText||'').map(s=>s.trim()).filter(s=>s&&s.length<=200&&meaningful(s)))];
  const images=imagesOf(origin);
  if(group&&group!==document.body&&(group.innerText||'').length<6000){const urls=imagesOf(group);if(urls.length)sharedImageGroups.push({control_indices:inputs.map((e,i)=>group.contains(e)?i:-1).filter(i=>i>=0),images:urls,binding_verified:false});}
  rows.push({sku_id:sku,control_index:inputs.indexOf(input),labels,specification_text:row?(row.innerText||'').trim().slice(0,1000):'',images,image_binding_verified:!!sku&&images.length>0,image_binding_source:sku&&images.length?'dom_explicit_sku_row':null,identity_conflict:ids.size>1,quantity_basis:'sku_name_or_explicit_unit_only_default_one',identity_verified:!!sku,match_verified:false,extraction_status:!row?'quantity_control_only':!images.length?'specification_read_image_binding_missing':!sku?'image_and_spec_read_sku_id_missing':'variant_observed_needs_visual_verification'});
 }
 return {status:'supplier_variants_observed',offer_id:offer,variants:rows,shared_image_groups:sharedImageGroups,control_diagnostics:diagnostics,quantity_control_count:inputs.length,all_variants_verified:false,completeness:'rendered_rows_only_hidden_or_unloaded_variants_not_verified',profit_eligible:false};
}
