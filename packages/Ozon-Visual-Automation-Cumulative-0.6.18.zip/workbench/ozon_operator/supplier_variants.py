"""Per-variant evidence and user-authorized default contents quantity."""
import re
from urllib.parse import urlsplit

def contents_quantity(name):
 values={int(m.group(1))for m in re.finditer(r'(?<![\d.])(\d+)\s*(?:件|个|把|只|张|支|条|枚|双|对)(?!起批)',name)if int(m.group(1))>0}
 if len(values)>1:return {'value':None,'basis':'conflicting_explicit_quantities'}
 return {'value':next(iter(values))if values else 1,'basis':'sku_name_explicit'if values else 'user_default_one'}

def purchase_quantity(sales_units,supplier_units=1):
 if type(sales_units)is not int or sales_units<1 or type(supplier_units)is not int or supplier_units<1:raise ValueError('invalid quantity')
 return (sales_units+supplier_units-1)//supplier_units

def normalize_variants(rows):
 if not isinstance(rows,list)or len(rows)>300:raise ValueError('invalid variants')
 clean=[]
 for r in rows:
  sku=str(r.get('sku_id')or'');labels=[x[:200]for x in r.get('labels',[])if isinstance(x,str)][:30]
  images=[]
  for url in r.get('images',[])[:20]:
   if not isinstance(url,str):continue
   u=urlsplit(url)
   if u.scheme=='https'and any(u.hostname==h or (u.hostname or'').endswith('.'+h)for h in ['alicdn.com','1688.com']):images.append(url)
  clean.append({'sku_id':sku if re.fullmatch(r'\d+',sku)else None,'labels':labels,'specification_text':str(r.get('specification_text',''))[:1000],'images':images,'sales_unit_quantity':contents_quantity(' '.join(labels)),'extraction_status':str(r.get('extraction_status','unknown'))[:100],'image_binding_verified':bool(re.fullmatch(r'\d+',sku)and images and r.get('image_binding_verified')is True and r.get('image_binding_source')=='dom_explicit_sku_row'),'match_verified':False,'identity_verified':bool(re.fullmatch(r'\d+',sku))})
 return clean
