"""Resumable visual stage. Review images first; never infer SKU identity from similarity."""
import hashlib,json
from .local_vision import compare_local,MODEL
REVISION='visual-three-criteria-evidence-v1'

def review_fingerprint(main_image,images,policy):
 return hashlib.sha256(json.dumps([REVISION,MODEL,main_image,images,policy],sort_keys=True,ensure_ascii=False).encode()).hexdigest()

def visual_batch(task,policy,compare=None,emit=None):
 compare=compare or compare_local
 main=(task.get('images')or[None])[0]
 if not main:return {'status':'blocked','reason':'ozon_main_image_missing','evaluated':0}
 if not task.get('supplier_offers'):return {'status':'blocked','reason':'supplier_candidates_missing','evaluated':0}
 counts={'inventory_incomplete':sum(o.get('all_variants_verified')is not True for o in task.get('supplier_offers',[])),'evaluated':0,'reused':0,'visual_pass':0,'visual_reject':0,'pending':0,'identity_pending':0};events=[]
 for offer in task.get('supplier_offers',[]):
  variants=offer.get('detail_variants')or[]
  if not variants:counts['pending']+=1;continue
  for index,v in enumerate(variants):
   images=v.get('images')or[]
   if not images:counts['pending']+=1;continue
   fp=review_fingerprint(main,images,policy);old=v.get('automatic_visual_review')or{}
   if old.get('fingerprint')==fp and old.get('assessment',{}).get('status')=='visual_assessment_read':
    result=old['assessment'];counts['reused']+=1
   else:
    result=compare(main,images,{},policy);counts['evaluated']+=1
   bound=bool(v.get('sku_id')and v.get('identity_verified')is True and v.get('image_binding_verified')is True)
   visual=result.get('visual',{})
   if result.get('status')!='visual_assessment_read':state='model_or_image_pending';counts['pending']+=1
   elif visual.get('visual_match_allowed')is True:
    counts['visual_pass']+=1
    if bound:state='visual_pass_sku_bound'
    else:state='visual_pass_sku_identity_pending';counts['identity_pending']+=1
   elif any(visual.get(k)=='mismatch'for k in ('structure','local_details','color')):
    state='visual_reject';counts['visual_reject']+=1
   else:state='visual_evidence_pending';counts['pending']+=1
   event={'offer_id':str(offer.get('offer_id')),'variant_index':index,'sku_id':v.get('sku_id'),'fingerprint':fp,'state':state,'assessment':result,'source_images':{'ozon_main_image':main,'supplier_sku_images':images},'profit_eligible':False}
   events.append(event)
   if emit:emit(event)
   if result.get('status')=='vision_busy':return {'status':'paused','reason':'vision_busy',**counts}
 return {'status':'visual_stage_finished_other_stages_pending',**counts,'profit_eligible':False}
