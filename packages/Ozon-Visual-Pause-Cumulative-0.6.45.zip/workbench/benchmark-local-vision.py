"""Compare 1/2/5 client concurrency on the same five candidates. Does not change decisions."""
import json,time,threading,subprocess,shutil,urllib.request
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
from ozon_operator.local_vision import compare_local,status,MODEL,IMAGE_MAX_EDGE,read_high_resolution_image,installed_model_digest
from ozon_operator.visual_prefilter import prefilter
from ozon_operator.dominant_axis import choose_axis,prepare_context
from ozon_operator.match_policy import current_policy

def main():
 if not status().get('automatic_vision_connected'):raise ValueError('Model or image resize component is not ready. Run switch-lightweight-vision.bat, then restart the workbench.')
 request=urllib.request.Request('http://127.0.0.1:8765/api/tasks')
 with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(request,timeout=10)as r:jobs=json.load(r)['jobs']
 if any(j.get('automatic_visual_stage',{}).get('status')=='running'for j in jobs):raise ValueError('A visual task is running. Click Pause visual queue in the workbench first, then rerun this test.')
 with urllib.request.build_opener(urllib.request.ProxyHandler({})).open('http://127.0.0.1:8765/api/vision-queue-state',timeout=10)as response:queue=json.load(response)
 if queue.get('model_request_busy')or queue.get('active_visual_skus')or any(j.get('automatic_visual_stage',{}).get('status')=='pausing'for j in jobs):
  print('Pause requested. Waiting for the current visual item to finish (up to 240 seconds)...',flush=True)
  deadline=time.monotonic()+240
  while True:
   with urllib.request.build_opener(urllib.request.ProxyHandler({})).open('http://127.0.0.1:8765/api/vision-queue-state',timeout=10)as response:queue=json.load(response)
   if not queue.get('model_request_busy')and not queue.get('active_visual_skus'):break
   if time.monotonic()>deadline:raise ValueError('The current visual item is still active. Benchmark did not start. Check the workbench status and retry.')
   time.sleep(2)
  with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(request,timeout=10)as response:jobs=json.load(response)['jobs']

 pairs=[];seen=set()
 for job in jobs:
  context=prepare_context(job);main_image=(job.get('images')or[None])[0]
  if not main_image:continue
  for offer in job.get('supplier_offers',[]):
   if offer.get('excluded_missing_sku_images'):continue
   axis=choose_axis(offer,job)
   for row in offer.get('detail_variants',[]):
    v={**row,'prefilter_axis':axis}
    if not v.get('images')or not v.get('image_binding_verified')or prefilter(job,v,context):continue
    key=(main_image,tuple(v['images']))
    if key in seen:continue
    seen.add(key);pairs.append({'ozon_sku':job['ozon_sku'],'offer_id':offer['offer_id'],'sku_id':v.get('sku_id'),'main':main_image,'images':v['images']})
    if len(pairs)==5:break
   if len(pairs)==5:break
  if len(pairs)==5:break
 if not pairs:raise ValueError('No eligible bound SKU images. Capture and screen candidates first.')
 print('Model:',MODEL,'inference max edge:',IMAGE_MAX_EDGE,'pixels; fixed sample:',len(pairs),flush=True)
 print('This runs real inference. Do not start another visual task. No task verdicts are changed.',flush=True)
 for url in dict.fromkeys(u for p in pairs for u in [p['main'],*p['images']]):read_high_resolution_image(url)
 installed_model_digest()
 # Untimed warm-up: cache is bypassed for every timed model request.
 print('Warming model once...',flush=True)
 warm=compare_local(pairs[0]['main'],pairs[0]['images'],{},current_policy(),force_inference=True,acquire_lock=False)
 if warm.get('status')!='visual_assessment_read':raise ValueError('Warm-up failed: '+str(warm.get('failure_reason',warm.get('status'))))
 report={'model':MODEL,'inference_max_edge':IMAGE_MAX_EDGE,'sample_size':len(pairs),'scope':'same_candidates_warm_model_cached_original_images_client_concurrency_not_guaranteed_server_parallelism','production_concurrency_changed':False,'runs':[]};baseline={}
 binary=shutil.which('nvidia-smi')
 for concurrency in (1,2,5):
  peak=[None];stop=threading.Event()
  def sample_memory():
   while not stop.is_set():
    if binary:
     try:
      p=subprocess.run([binary,'--query-gpu=memory.used','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=3)
      values=[int(x.strip())for x in p.stdout.splitlines()if x.strip().isdigit()]
      if values:peak[0]=max([x for x in [peak[0],*values]if x is not None])
     except (OSError,subprocess.TimeoutExpired):pass
    stop.wait(2)
  monitor=threading.Thread(target=sample_memory,daemon=True);monitor.start();started=time.monotonic();records=[]
  try:
   with ThreadPoolExecutor(max_workers=concurrency)as pool:
    futures={pool.submit(compare_local,pair['main'],pair['images'],{},current_policy(),force_inference=True,acquire_lock=False):i for i,pair in enumerate(pairs)}
    for future in as_completed(futures):
     index=futures[future]
     try:result=future.result()
     except Exception as e:result={'status':'benchmark_exception','failure_reason':type(e).__name__}
     visual=result.get('visual',{});decision={k:visual.get(k)for k in ('structure','local_details','color','overall','visual_match_allowed')}
     if concurrency==1:baseline[index]=decision
     records.append({'sample_index':index,'status':result.get('status'),'elapsed_ms':result.get('elapsed_ms'),'timing':result.get('timing'),'failure_reason':result.get('failure_reason'),'decision':decision,'differs_from_serial':decision!=baseline.get(index)})
     print('Concurrency',concurrency,'completed',len(records),'/',len(pairs),'status:',result.get('status'),flush=True)
  finally:stop.set();monitor.join(timeout=4)
  elapsed=time.monotonic()-started;good=sum(x['status']=='visual_assessment_read'for x in records)
  summary={'client_concurrency':concurrency,'elapsed_seconds':round(elapsed,2),'completed_assessments':good,'errors':len(records)-good,'assessments_per_second':round(good/elapsed,4),'sampled_peak_gpu_memory_mib':peak[0],'decision_differences_vs_serial':sum(x['differs_from_serial']for x in records),'records':records};report['runs'].append(summary)
  print('Summary:',json.dumps({k:v for k,v in summary.items()if k!='records'}),flush=True)
 output=Path(__file__).resolve().parent/'data'/'vision-concurrency-benchmark.json';output.parent.mkdir(exist_ok=True);output.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print('Saved:',output,flush=True)
 print('Production remains serial. Review errors and decision differences before enabling concurrency.',flush=True)
if __name__=='__main__':
 try:main()
 except (OSError,ValueError,KeyError)as error:print('Benchmark stopped:',error,flush=True);raise SystemExit(1)
