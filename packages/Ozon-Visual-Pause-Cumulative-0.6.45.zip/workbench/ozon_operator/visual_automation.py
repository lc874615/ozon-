"""Resumable visual stage. Review images first; never infer SKU identity from similarity."""
import hashlib,json
from .dominant_axis import choose_axis,prepare_context
from .visual_prefilter import prefilter,prefilter_key
from .local_vision import compare_local,MODEL,IMAGE_MAX_EDGE
REVISION='visual-evidence-queue-v8'

def review_fingerprint(main_image,images,policy):
 return hashlib.sha256(json.dumps([REVISION,MODEL,IMAGE_MAX_EDGE,main_image,images,policy],sort_keys=True,ensure_ascii=False).encode()).hexdigest()

def visual_inventory_signature(task):
 offers=[]
 for o in task.get('supplier_offers',[]):
  axis=choose_axis(o,task);collections=[]
  for key in ('detail_variants','detail_spec_options','unbound_detail_images'):
   rows=[]
   for v in o.get(key,[]):
    specs=v.get('specs')or{}
    if not specs and len(v.get('labels',[]))==1 and v['labels'][0]in axis.get('values',[]):specs={axis['name']:v['labels'][0]}
    rows.append((v.get('sku_id'),v.get('images'),specs,v.get('labels'),v.get('identity_verified'),v.get('image_binding_verified'),v.get('option_image_binding_verified')))
   collections.append((key,rows))
  offers.append((o.get('offer_id'),bool(o.get('excluded_missing_sku_images')),collections))
 payload=[(task.get('images')or[None])[0],task.get('attributes'),task.get('image_reference'),offers]
 return hashlib.sha256(json.dumps(payload,sort_keys=True,ensure_ascii=False).encode()).hexdigest()

def visual_batch(task,policy,compare=None,emit=None,progress=None,should_pause=None):
 compare=compare or compare_local
 main=(task.get('images')or[None])[0]
 if not main:return {'status':'blocked','reason':'ozon_main_image_missing','evaluated':0}
 if not task.get('supplier_offers'):return {'status':'blocked','reason':'supplier_candidates_missing','evaluated':0}
 counts={'missing_sku_images':0,'missing_detail_inventory':0,'inventory_incomplete':sum(o.get('all_variants_verified')is not True for o in task.get('supplier_offers',[])),'evaluated':0,'reused':0,'visual_pass':0,'visual_reject':0,'pending':0,'identity_pending':0,'prefilter_rejected':0};events=[];run_cache={}
 context=prepare_context(task)
 work=[]
 for offer in task.get('supplier_offers',[]):
  if offer.get('excluded_missing_sku_images'):continue
  bound_images={tuple(v.get('images')or[])for v in offer.get('detail_variants',[])if v.get('images')}
  variants=[('detail_variants',i,v)for i,v in enumerate(offer.get('detail_variants')or[])]+[(key,i,v)for key in ('detail_spec_options','unbound_detail_images')for i,v in enumerate(offer.get(key)or[])if tuple(v.get('images')or[])not in bound_images]
  if not variants:counts['pending']+=1;counts['missing_detail_inventory']+=1;continue
  axis=choose_axis(offer,task)
  for collection,index,v in variants:
   v={**v,'prefilter_axis':axis}
   if not v.get('specs')and len(v.get('labels',[]))==1 and v['labels'][0]in axis.get('values',[]):v['specs']={axis['name']:v['labels'][0]}
   work.append((offer,collection,index,v,prefilter(task,v,context)))
 # Finish and publish all deterministic rejections before any model request.
 work.sort(key=lambda entry:entry[4]is None)
 inventory_signature=visual_inventory_signature(task);prefilter_total=sum(quick is not None for *_,quick in work)
 queue_total=len(work);visual_total=sum(bool(v.get('images'))and quick is None for _,_,_,v,quick in work);visual_completed=0
 for position,(offer,collection,index,v,quick)in enumerate(work,1):
  snapshot={'inventory_signature':inventory_signature,'prefilter_total':prefilter_total,'total':queue_total,'completed':position-1,'visual_total':visual_total,'visual_completed':visual_completed,'current_offer_id':str(offer.get('offer_id')),'current_sku_id':v.get('sku_id'),'phase':'checking'}
  if should_pause and should_pause():return {'status':'paused_by_user','progress':snapshot,**counts,'profit_eligible':False}
  images=v.get('images')or[]
  if not images:
   counts['pending']+=1;counts['missing_sku_images']+=1
   if progress:progress({**snapshot,'completed':position,'phase':'missing_image'})
   continue
  fp=review_fingerprint(main,images,policy);old=v.get('automatic_visual_review')or{}
  if quick:
   result=quick;counts['prefilter_rejected']+=1
  elif old.get('fingerprint')==fp and old.get('assessment',{}).get('status')=='visual_assessment_read':
   result=old['assessment'];counts['reused']+=1;run_cache[fp]=result
  elif fp in run_cache:
   result=run_cache[fp];counts['reused']+=1
  else:
   if progress:progress({**snapshot,'phase':'model_inference'})
   if should_pause and should_pause():return {'status':'paused_by_user','progress':snapshot,**counts,'profit_eligible':False}
   result=compare(main,images,{},policy);counts['evaluated']+=1
   if result.get('status')=='visual_assessment_read':run_cache[fp]=result
  bound=bool(v.get('sku_id')and v.get('identity_verified')is True and v.get('image_binding_verified')is True)
  visual=result.get('visual',{})
  if result.get('status')=='prefilter_rejected':state='visual_reject';counts['visual_reject']+=1
  elif result.get('status')!='visual_assessment_read':state='model_or_image_pending';counts['pending']+=1
  elif visual.get('visual_match_allowed')is True:
   counts['visual_pass']+=1
   if bound:state='visual_pass_sku_bound'
   else:state='visual_pass_sku_identity_pending';counts['identity_pending']+=1
  elif any(visual.get(k)=='mismatch'for k in ('structure','local_details','color')):
   state='visual_reject';counts['visual_reject']+=1
  else:state='visual_reject';counts['visual_reject']+=1
  if not quick:visual_completed+=1
  snapshot.update(completed=position,visual_completed=visual_completed,phase='item_completed')
  event={'progress':snapshot,'offer_id':str(offer.get('offer_id')),'variant_index':index,'variant_collection':collection,'sku_id':v.get('sku_id'),'fingerprint':fp,'state':state,'assessment':result,'source_images':{'ozon_main_image':main,'supplier_sku_images':images},'profit_eligible':False}
  events.append(event)
  if emit:emit(event)
  if should_pause and should_pause():return {'status':'paused_by_user','progress':snapshot,**counts,'profit_eligible':False}
  if result.get('status')=='vision_busy':return {'status':'paused','reason':'vision_busy',**counts}
 if counts['evaluated']+counts['reused']+counts['prefilter_rejected']==0:return {'status':'waiting_for_detail_images','reason':'no_comparable_detail_images','next_action':'sync_open_candidate_detail_pages',**counts,'profit_eligible':False}
 return {'status':'visual_stage_finished_other_stages_pending',**counts,'profit_eligible':False}

def visual_result_view(task,variant,policy,context=None):
 """Binary exclusion result; never describe a technical failure as observed difference."""
 images=variant.get('images')or[]
 if not images:return {'result':'不符','reason':'缺少对应规格图片，本次不纳入备选；需补抓','retryable':True}
 review=variant.get('automatic_visual_review')or{}
 if review.get('fingerprint')!=review_fingerprint((task.get('images')or[None])[0],images,policy):return {'result':None,'reason':'尚未按当前规则完成比对','retryable':True}
 assessment=review.get('assessment')or{}
 if assessment.get('status')=='prefilter_rejected':
  if assessment.get('prefilter_key')!=prefilter_key(task,variant,context):return {'result':None,'reason':'预筛依据已变化，等待重新核验','retryable':True}
  return {'result':'不符','reason':'AI前预筛：'+assessment.get('reason','明确属性冲突'),'retryable':False}
 if assessment.get('failure_reason')=='image_resize_dependency_missing':return {'result':'不符','reason':'缺少推理图片缩放组件，请运行轻量视觉安装脚本；本次未完成模型核验','retryable':True}
 if assessment.get('failure_reason')=='high_resolution_image_required':return {'result':'不符','reason':'未取得对应清晰规格原图（短边至少600像素），需补抓；未使用缩略图作判断','retryable':True}
 if assessment.get('status')!='visual_assessment_read':return {'result':'不符','reason':'图片读取或模型核验失败，本次不纳入备选；非已证实外观不同','retryable':True}
 visual=assessment.get('visual')or{}
 if visual.get('visual_match_allowed')is True:return {'result':'通过','reason':visual.get('explanation',{}).get('overall','可见结构、细节及颜色符合视觉标准'),'retryable':False}
 different=any(visual.get(k)=='mismatch'for k in ('structure','local_details','color'))
 return {'result':'不符','reason':visual.get('explanation',{}).get('overall')or('可见外观存在差异'if different else'视觉证据未达到通过标准'),'retryable':not different}

def summarize_spec_visuals(task,policy,context=None):
 context=context or prepare_context(task)
 counts={'model_passed':0,'model_rejected':0,'model_technical_excluded':0,'parameter_rejected':0,'model_waiting':0,'named_specs':0,'passed':0,'rejected':0,'unknown':0,'waiting':0,'retryable_rejected':0,'excluded_missing_images':0,'offers_missing_named_specs':0,'all_specs_read_verified':False,'offers_inventory_unproven':sum(o.get('all_variants_verified')is not True for o in task.get('supplier_offers',[]))}
 for offer in task.get('supplier_offers',[]):
  if offer.get('excluded_missing_sku_images'):counts['excluded_missing_images']+=1;continue
  options=[v for v in offer.get('detail_variants',[])if v.get('image_binding_verified')and v.get('images')]or offer.get('detail_spec_options')or[]
  if not options:counts['offers_missing_named_specs']+=1;continue
  for v in options:
   counts['named_specs']+=1
   view=visual_result_view(task,v,policy,context)
   assessment=(v.get('automatic_visual_review')or{}).get('assessment',{})
   if assessment.get('status')=='prefilter_rejected'and view['result']=='不符':counts['parameter_rejected']+=1
   elif assessment.get('status')=='visual_assessment_read'and view['result']in ('通过','不符'):counts['model_passed'if view['result']=='通过'else'model_rejected']+=1
   elif view['result']=='不符':counts['model_technical_excluded']+=1
   else:counts['model_waiting']+=1
   if view['result']=='通过':counts['passed']+=1
   elif view['result']=='不符':
    counts['rejected']+=1
    if view['retryable']:counts['retryable_rejected']+=1
   else:counts['waiting']+=1
 return counts
